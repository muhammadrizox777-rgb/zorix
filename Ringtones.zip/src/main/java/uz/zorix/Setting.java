package uz.zorix;

import java.util.Locale;

public class Setting {
    public enum Kind { NUMBER, CYCLE, BOOL }

    public final String name;
    public final Kind kind;
    public double value, min, max, step;
    public String[] options;

    private Setting(String name, Kind kind) { this.name = name; this.kind = kind; }

    public static Setting number(String name, double def, double min, double max, double step) {
        Setting s = new Setting(name, Kind.NUMBER);
        s.value = def; s.min = min; s.max = max; s.step = step;
        return s;
    }

    public static Setting cycle(String name, int def, String... options) {
        Setting s = new Setting(name, Kind.CYCLE);
        s.value = def; s.options = options;
        return s;
    }

    public static Setting bool(String name, boolean def) {
        Setting s = new Setting(name, Kind.BOOL);
        s.value = def ? 1 : 0;
        return s;
    }

    public int index() {
        if (options == null) return (int) value;
        return Math.max(0, Math.min(options.length - 1, (int) value));
    }

    public boolean on() { return value >= 0.5; }

    public String display() {
        switch (kind) {
            case CYCLE: return options[index()];
            case BOOL: return on() ? "ON" : "OFF";
            default:
                return step >= 1 ? String.valueOf((int) value) : String.format(Locale.ROOT, "%.1f", value);
        }
    }

    public void inc(int dir) {
        switch (kind) {
            case NUMBER:
                value = Math.max(min, Math.min(max, Math.round((value + dir * step) * 100.0) / 100.0));
                break;
            case CYCLE:
                value = (index() + dir + options.length) % options.length;
                break;
            default:
                value = on() ? 0 : 1;
        }
    }
}

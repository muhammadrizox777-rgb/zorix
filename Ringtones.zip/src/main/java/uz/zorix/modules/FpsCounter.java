package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import uz.zorix.Draw;
import uz.zorix.ZModule;

public class FpsCounter extends ZModule {
    public FpsCounter() {
        super("FPS Counter", "Shows your frames per second.", true, 6, 6, true);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        Draw.labelValue(ctx, mc, this, "FPS", String.valueOf(mc.getCurrentFps()));
    }
}

package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import uz.zorix.Setting;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

public class Zoom extends ZModule {
    private static Zoom instance;
    private static float factor = 1f;
    private static long last = System.nanoTime();

    private final Setting level = add(Setting.number("Zoom level", 4, 2, 10, 0.5));
    private final Setting smooth = add(Setting.bool("Smooth zoom", true));

    public Zoom() {
        super("Zoom", "Hold C to zoom in (key can be changed in Controls).", false, 0, 0, false);
        instance = this;
    }

    /** FOV multiplier for this frame (1.0 = no zoom). Called by the GameRenderer mixin. */
    public static double multiplier() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;
        if (instance == null) return 1.0;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean zooming = instance.enabled && ZorixClient.zoomKey != null
                && ZorixClient.zoomKey.isPressed() && mc.currentScreen == null;
        float target = zooming ? (float) (1.0 / instance.level.value) : 1f;
        factor = instance.smooth.on() ? factor + (target - factor) * Math.min(1f, dt * 14f) : target;
        if (Math.abs(factor - target) < 0.002f) factor = target;
        return factor;
    }
}

package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

public class Freelook extends ZModule {
    public static boolean active;
    public static float yaw, pitch;
    private Perspective saved;

    public Freelook() {
        super("Freelook", "Hold LEFT ALT to look around without turning your player.", false, 0, 0, false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean want = ZorixClient.freelookKey.isPressed() && mc.currentScreen == null;
        if (want && !active) {
            active = true;
            yaw = mc.player.getYaw();
            pitch = mc.player.getPitch();
            saved = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!want && active) {
            stop(mc);
        }
    }

    @Override
    public void onDisable() {
        stop(MinecraftClient.getInstance());
    }

    private void stop(MinecraftClient mc) {
        if (!active) return;
        active = false;
        if (saved != null) mc.options.setPerspective(saved);
    }

    public static void rotate(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
    }
}

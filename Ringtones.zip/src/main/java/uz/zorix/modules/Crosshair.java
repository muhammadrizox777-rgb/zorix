package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import uz.zorix.Setting;
import uz.zorix.ZModule;

import java.util.ArrayList;
import java.util.List;

public class Crosshair extends ZModule {
    private static Crosshair instance;

    private final Setting style = add(Setting.cycle("Style", 0, "Cross", "Dot", "Circle", "Cross + Dot"));
    private final Setting size = add(Setting.number("Size", 5, 1, 20, 1));
    private final Setting gap = add(Setting.number("Gap", 3, 0, 12, 1));
    private final Setting thick = add(Setting.number("Thickness", 1, 1, 4, 1));
    private final Setting outline = add(Setting.bool("Outline", true));

    public Crosshair() {
        super("Crosshair", "Custom crosshair: style, size, gap, thickness and color.", false, 0, 0, false);
        instance = this;
    }

    public static boolean replacesVanilla() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return instance != null && instance.enabled && mc.options.getPerspective().isFirstPerson();
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        int t = (int) thick.value, s = (int) size.value, g = (int) gap.value;
        int a = cx - t / 2, b = a + t, c = cy - t / 2, d = c + t;
        int st = style.index();
        List<int[]> r = new ArrayList<>();

        if (st == 0 || st == 3) {
            r.add(new int[]{a - g - s, c, a - g, d});
            r.add(new int[]{b + g, c, b + g + s, d});
            r.add(new int[]{a, c - g - s, b, c - g});
            r.add(new int[]{a, d + g, b, d + g + s});
        }
        if (st == 1) {
            int side = Math.max(2, s / 2), half = side / 2;
            r.add(new int[]{cx - half, cy - half, cx - half + side, cy - half + side});
        }
        if (st == 3) r.add(new int[]{cx - 1, cy - 1, cx + 1, cy + 1});
        if (st == 2) {
            double rad = s + g;
            int steps = Math.max(24, (int) (rad * 6));
            for (int i = 0; i < steps; i++) {
                double ang = 2 * Math.PI * i / steps;
                int px = cx + (int) Math.round(Math.cos(ang) * rad) - t / 2;
                int py = cy + (int) Math.round(Math.sin(ang) * rad) - t / 2;
                r.add(new int[]{px, py, px + t, py + t});
            }
        }

        if (outline.on()) {
            for (int[] q : r) ctx.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, 0xFF000000);
        }
        int col = accent();
        for (int[] q : r) ctx.fill(q[0], q[1], q[2], q[3], col);
    }
}

package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import uz.zorix.Clicks;
import uz.zorix.Draw;
import uz.zorix.Setting;
import uz.zorix.ZModule;

public class CpsCounter extends ZModule {
    private final Setting showRight = add(Setting.bool("Show right click", true));

    public CpsCounter() {
        super("CPS Counter", "Shows your clicks per second (left | right).", true, 6, 26, true);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        String v = String.valueOf(Clicks.left());
        if (showRight.on()) v += " | " + Clicks.right();
        Draw.labelValue(ctx, mc, this, "CPS", v);
    }
}

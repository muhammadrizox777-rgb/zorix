package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import uz.zorix.Draw;
import uz.zorix.ZModule;

public class CoordinatesHud extends ZModule {
    public CoordinatesHud() {
        super("Coordinates", "Shows your X / Y / Z position and facing direction.", true, 6, 66, true);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        var p = mc.player;
        TextRenderer tr = mc.textRenderer;
        String xyz = p.getBlockX() + " / " + p.getBlockY() + " / " + p.getBlockZ();
        String dir = p.getHorizontalFacing().asString();
        dir = Character.toUpperCase(dir.charAt(0)) + dir.substring(1);
        int lw = tr.getWidth("XYZ");
        w = 7 + lw + 6 + tr.getWidth(xyz) + 6;
        h = 26;
        Draw.panel(ctx, x, y, w, h, accent());
        ctx.drawText(tr, "XYZ", x + 7, y + 4, Draw.MUTED, false);
        ctx.drawText(tr, xyz, x + 7 + lw + 6, y + 4, accent(), false);
        ctx.drawText(tr, "DIR", x + 7, y + 15, Draw.MUTED, false);
        ctx.drawText(tr, dir, x + 7 + lw + 6, y + 15, Draw.WHITE, false);
    }
}

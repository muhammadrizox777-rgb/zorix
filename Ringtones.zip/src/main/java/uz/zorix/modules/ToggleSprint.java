package uz.zorix.modules;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import uz.zorix.Draw;
import uz.zorix.ZModule;

public class ToggleSprint extends ZModule {
    private boolean forced;

    public ToggleSprint() {
        super("Toggle Sprint", "Sprints automatically while you hold forward. No need to double-tap W.", true, 6, 86, false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        boolean forward = mc.options.forwardKey.isPressed();
        boolean can = forward && !p.isSneaking() && !p.isUsingItem()
                && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying);
        if (can) {
            mc.options.sprintKey.setPressed(true);
            forced = true;
        } else if (forced) {
            release(mc);
        }
    }

    @Override
    public void onDisable() {
        release(MinecraftClient.getInstance());
    }

    private void release(MinecraftClient mc) {
        if (!forced) return;
        forced = false;
        var key = mc.options.sprintKey;
        boolean physical = InputUtil.isKeyPressed(mc.getWindow().getHandle(), KeyBindingHelper.getBoundKeyOf(key).getCode());
        key.setPressed(physical);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        boolean sprinting = mc.player != null && mc.player.isSprinting();
        Draw.labelValue(ctx, mc, this, "SPRINT", sprinting ? "TOGGLED" : "READY");
    }
}

package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import uz.zorix.ZModule;

public class Fullbright extends ZModule {
    private boolean applied;

    public Fullbright() {
        super("Fullbright", "Maximum brightness: see clearly in caves and at night.", false, 0, 0, false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, true, false, false));
            applied = true;
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (applied && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        applied = false;
    }
}

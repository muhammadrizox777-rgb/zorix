package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import uz.zorix.Draw;
import uz.zorix.ZModule;

public class PotionsHud extends ZModule {
    private static final String[] ROMAN = {"", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"};

    public PotionsHud() {
        super("Potions HUD", "Shows your active potion effects and time left.", true, 9999, 6, false);
    }

    private static String time(StatusEffectInstance e) {
        if (e.isInfinite()) return "**:**";
        int s = e.getDuration() / 20;
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private static String name(StatusEffectInstance e) {
        int a = e.getAmplifier();
        return e.getEffectType().value().getName().getString() + (a < ROMAN.length ? ROMAN[a] : " " + (a + 1));
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        var effects = mc.player.getStatusEffects();
        int count = 0, maxW = 0;
        for (StatusEffectInstance e : effects) {
            if (!e.shouldShowIcon()) continue;
            count++;
            maxW = Math.max(maxW, tr.getWidth(name(e)) + 14 + tr.getWidth(time(e)));
        }
        if (count == 0) {
            if (!preview) return;
            w = 90;
            h = 16;
            Draw.panel(ctx, x, y, w, h, accent());
            ctx.drawText(tr, "No effects", x + 7, y + 4, Draw.MUTED, false);
            return;
        }
        w = maxW + 14;
        h = count * 11 + 6;
        Draw.panel(ctx, x, y, w, h, accent());
        int yy = y + 4;
        for (StatusEffectInstance e : effects) {
            if (!e.shouldShowIcon()) continue;
            String t = time(e);
            ctx.drawText(tr, name(e), x + 7, yy, Draw.WHITE, false);
            int col = (!e.isInfinite() && e.getDuration() < 200) ? 0xFFFF5555 : accent();
            ctx.drawText(tr, t, x + w - 6 - tr.getWidth(t), yy, col, false);
            yy += 11;
        }
    }
}

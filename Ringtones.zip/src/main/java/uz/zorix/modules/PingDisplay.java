package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import uz.zorix.Draw;
import uz.zorix.ZModule;

public class PingDisplay extends ZModule {
    public PingDisplay() {
        super("Ping Display", "Shows your connection delay to the server.", true, 6, 46, false);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        int ping = 0;
        var nh = mc.getNetworkHandler();
        if (nh != null && mc.player != null) {
            var e = nh.getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        Draw.labelValue(ctx, mc, this, "PING", ping + " ms");
    }
}

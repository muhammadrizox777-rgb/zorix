package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import uz.zorix.Draw;
import uz.zorix.Setting;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

import java.util.Locale;

public class TargetHud extends ZModule {
    private LivingEntity target;
    private long lastSeen;
    private float shown = 20f;
    private final Setting seconds = add(Setting.number("Show time (s)", 3, 1, 10, 1));

    public TargetHud() {
        super("Target HUD", "Shows name, health and distance of the entity you are aiming at.", true, 170, 140, false);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player && le.isAlive()) {
            if (le != target) shown = le.getHealth();
            target = le;
            lastSeen = System.currentTimeMillis();
        }
        boolean has = target != null && target.isAlive() && !target.isRemoved()
                && System.currentTimeMillis() - lastSeen < seconds.value * 1000;
        w = 130;
        h = 36;
        if (!has && !preview) return;

        String name = has ? target.getName().getString() : "Target";
        float hp = has ? target.getHealth() : 20f;
        float max = has ? Math.max(1f, target.getMaxHealth()) : 20f;
        shown += (hp - shown) * Math.min(1f, ZorixClient.frameDt * 8f);

        TextRenderer tr = mc.textRenderer;
        Draw.panel(ctx, x, y, w, h, accent());
        ctx.drawText(tr, name, x + 7, y + 5, Draw.WHITE, false);
        int bx = x + 7, by = y + 17, bw = w - 14;
        Draw.rounded(ctx, bx, by, bw, 5, 2, 0xFF2A2A30);
        int fill = (int) (bw * Math.max(0f, Math.min(1f, shown / max)));
        if (fill > 1) Draw.rounded(ctx, bx, by, fill, 5, 2, accent());
        String hpText = String.format(Locale.ROOT, "%.1f / %.0f", hp, max);
        ctx.drawText(tr, hpText, x + 7, y + 25, Draw.MUTED, false);
        if (has && mc.player != null) {
            String d = String.format(Locale.ROOT, "%.1fm", mc.player.distanceTo(target));
            ctx.drawText(tr, d, x + w - 7 - tr.getWidth(d), y + 25, Draw.MUTED, false);
        }
    }
}

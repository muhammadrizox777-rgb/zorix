package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import uz.zorix.Draw;
import uz.zorix.Setting;
import uz.zorix.ZModule;

public class ArmorHud extends ZModule {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    private final Setting hand = add(Setting.bool("Show held item", true));

    public ArmorHud() {
        super("Armor HUD", "Shows your armor and its durability.", true, 9999, 90, true);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        var p = mc.player;
        int rows = 4 + (hand.on() ? 1 : 0);
        w = 52;
        h = rows * 18 + 4;
        Draw.panel(ctx, x, y, w, h, accent());
        for (int i = 0; i < rows; i++) {
            ItemStack st = i < 4 ? p.getEquippedStack(SLOTS[i]) : p.getMainHandStack();
            int ry = y + 2 + i * 18;
            if (st.isEmpty()) continue;
            ctx.drawItem(st, x + 5, ry + 1);
            String txt;
            int col = Draw.WHITE;
            if (st.isDamageable()) {
                int left = st.getMaxDamage() - st.getDamage();
                float f = Math.max(0f, Math.min(1f, left / (float) st.getMaxDamage()));
                int r = (int) (255 * Math.min(1f, 2f * (1f - f)));
                int g = (int) (255 * Math.min(1f, 2f * f));
                col = 0xFF000000 | (r << 16) | (g << 8) | 0x30;
                txt = String.valueOf(left);
            } else {
                txt = st.getCount() > 1 ? String.valueOf(st.getCount()) : "";
            }
            ctx.drawText(mc.textRenderer, txt, x + 24, ry + 5, col, false);
        }
    }
}

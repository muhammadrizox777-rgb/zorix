package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import uz.zorix.ZModule;

public class Hitbox extends ZModule {
    public Hitbox() {
        super("Hitbox", "Shows the hitboxes of players and mobs.", false, 0, 0, false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.getEntityRenderDispatcher().setRenderHitboxes(true);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().getEntityRenderDispatcher().setRenderHitboxes(false);
    }
}

package uz.zorix.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;
import uz.zorix.Draw;
import uz.zorix.Setting;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

public class Keystrokes extends ZModule {
    private final float[] a = new float[8];
    private final Setting mouse = add(Setting.bool("Mouse buttons", true));
    private final Setting space = add(Setting.bool("Space bar", true));

    public Keystrokes() {
        super("Keystrokes", "Shows your WASD, mouse and space keys with smooth animation.", true, 6, 80, true);
        w = 64;
        h = 64;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        GameOptions o = mc.options;
        key(ctx, mc, 0, x + 22, y, 20, 20, "W", o.forwardKey.isPressed());
        key(ctx, mc, 1, x, y + 22, 20, 20, "A", o.leftKey.isPressed());
        key(ctx, mc, 2, x + 22, y + 22, 20, 20, "S", o.backKey.isPressed());
        key(ctx, mc, 3, x + 44, y + 22, 20, 20, "D", o.rightKey.isPressed());
        int yy = y + 44;
        if (mouse.on()) {
            key(ctx, mc, 4, x, yy, 31, 20, "LMB", o.attackKey.isPressed());
            key(ctx, mc, 5, x + 33, yy, 31, 20, "RMB", o.useKey.isPressed());
            yy += 22;
        }
        if (space.on()) {
            key(ctx, mc, 6, x, yy, 64, 12, "SPACE", o.jumpKey.isPressed());
            yy += 14;
        }
        w = 64;
        h = Math.max(42, yy - y - 2);
    }

    private void key(DrawContext ctx, MinecraftClient mc, int i, int kx, int ky, int kw, int kh, String label, boolean down) {
        a[i] += ((down ? 1f : 0f) - a[i]) * Math.min(1f, ZorixClient.frameDt * 16f);
        int bg = Draw.lerpColor(0xB0121216, Draw.withAlpha(accent(), 0xE0), a[i]);
        Draw.rounded(ctx, kx, ky, kw, kh, 3, bg);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, kx + (kw - tw) / 2, ky + (kh - 8) / 2 + 1, Draw.WHITE, false);
    }
}

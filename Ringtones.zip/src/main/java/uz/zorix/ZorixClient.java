package uz.zorix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import uz.zorix.gui.HudEditScreen;
import uz.zorix.gui.ZorixScreen;
import uz.zorix.modules.*;

import java.util.ArrayList;
import java.util.List;

public class ZorixClient implements ClientModInitializer {
    public static final String NAME = "ZORIX CLIENT";
    public static final String TITLE = "ZORIX CLIENT 1.21.4";
    public static final List<ZModule> MODULES = new ArrayList<>();

    public static KeyBinding menuKey, zoomKey, freelookKey;
    public static float frameDt = 0.016f;

    private static long lastNano = System.nanoTime();
    private static int ticks;

    @Override
    public void onInitializeClient() {
        MODULES.add(new Fullbright());
        MODULES.add(new Hitbox());
        MODULES.add(new Keystrokes());
        MODULES.add(new FpsCounter());
        MODULES.add(new CpsCounter());
        MODULES.add(new ArmorHud());
        MODULES.add(new ToggleSprint());
        MODULES.add(new TargetHud());
        MODULES.add(new CoordinatesHud());
        MODULES.add(new PingDisplay());
        MODULES.add(new Zoom());
        MODULES.add(new Crosshair());
        MODULES.add(new PotionsHud());
        MODULES.add(new Freelook());

        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorix.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.zorix"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorix.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.zorix"));
        freelookKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorix.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "category.zorix"));

        ClientTickEvents.END_CLIENT_TICK.register(ZorixClient::tick);
        HudRenderCallback.EVENT.register(ZorixClient::renderHud);

        // ZORIX CLIENT branding on the title screen
        ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
                    ctx.drawText(client.textRenderer, NAME, 6, 6, Draw.RED, true);
                    ctx.drawText(client.textRenderer, "Fabric 1.21.4", 6, 17, Draw.MUTED, true);
                });
            }
        });
    }

    private static void tick(MinecraftClient mc) {
        if (++ticks % 40 == 0) mc.getWindow().setTitle(TITLE);

        while (menuKey.wasPressed()) {
            if (mc.player != null && mc.currentScreen == null) mc.setScreen(new ZorixScreen());
        }
        if (mc.player == null || mc.world == null) {
            Freelook.active = false;
            return;
        }
        for (ZModule m : MODULES) {
            if (m.enabled) m.onTick(mc);
        }
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        frameDt = Math.min(0.1f, (now - lastNano) / 1.0e9f);
        lastNano = now;

        Clicks.poll(mc);
        if (mc.player == null || mc.options.hudHidden) return;

        boolean editing = mc.currentScreen instanceof HudEditScreen;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (ZModule m : MODULES) {
            if (!m.enabled) continue;
            if (m.draggable) {
                if (editing) continue; // the editor draws them itself
                m.x = Math.max(0, Math.min(m.x, sw - m.w));
                m.y = Math.max(0, Math.min(m.y, sh - m.h));
            }
            m.render(ctx, mc, false);
        }
    }
}

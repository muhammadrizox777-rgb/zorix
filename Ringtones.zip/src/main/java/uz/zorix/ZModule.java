package uz.zorix;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class ZModule {
    public final String name;
    public final String description;
    public final boolean draggable;
    public boolean enabled;
    public int color = 0xE11D2E;
    public int x, y, w = 60, h = 16;
    public final List<Setting> settings = new ArrayList<>();
    public float anim;   // animated switch position (0..1)
    public float hover;  // animated hover (0..1)

    protected ZModule(String name, String description, boolean draggable, int x, int y, boolean enabled) {
        this.name = name;
        this.description = description;
        this.draggable = draggable;
        this.x = x;
        this.y = y;
        this.enabled = enabled;
        this.anim = enabled ? 1f : 0f;
    }

    protected Setting add(Setting s) { settings.add(s); return s; }

    public String id() { return name.toLowerCase().replace(' ', '_'); }
    public int accent() { return Draw.argb(color); }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}

    /** Called every game tick while enabled and in a world. */
    public void onTick(MinecraftClient mc) {}

    /** Called every frame while enabled. preview = HUD editor (draw placeholder even without data). */
    public void render(DrawContext ctx, MinecraftClient mc, boolean preview) {}
}

package uz.zorix;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class ModData {
        public boolean enabled;
        public int color;
        public int x, y;
        public Map<String, Double> s = new HashMap<>();
    }

    private Config() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("zorix-client.json"); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Map<String, ModData> map = GSON.fromJson(Files.readString(file()),
                    new TypeToken<Map<String, ModData>>() {}.getType());
            if (map == null) return;
            for (ZModule m : ZorixClient.MODULES) {
                ModData d = map.get(m.id());
                if (d == null) continue;
                if (d.color != 0) m.color = d.color & 0xFFFFFF;
                if (m.draggable) { m.x = d.x; m.y = d.y; }
                if (d.s != null) {
                    for (Setting s : m.settings) {
                        Double v = d.s.get(s.name);
                        if (v != null) s.value = v;
                    }
                }
                m.setEnabled(d.enabled);
                m.anim = m.enabled ? 1f : 0f;
            }
        } catch (Exception e) {
            System.err.println("[ZORIX CLIENT] Could not read config: " + e);
        }
    }

    public static void save() {
        try {
            Map<String, ModData> map = new HashMap<>();
            for (ZModule m : ZorixClient.MODULES) {
                ModData d = new ModData();
                d.enabled = m.enabled;
                d.color = m.color;
                d.x = m.x;
                d.y = m.y;
                for (Setting s : m.settings) d.s.put(s.name, s.value);
                map.put(m.id(), d);
            }
            Files.writeString(file(), GSON.toJson(map));
        } catch (Exception e) {
            System.err.println("[ZORIX CLIENT] Could not save config: " + e);
        }
    }
}

package uz.zorix.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import uz.zorix.Config;
import uz.zorix.Draw;
import uz.zorix.Setting;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

import java.util.List;

public class ZorixScreen extends Screen {
    private static final int[] PALETTE = {
            0xE11D2E, 0xFF5A36, 0xFF8A00, 0xFFD60A, 0x22C55E,
            0x06B6D4, 0x3B82F6, 0xA855F7, 0xEC4899, 0xFFFFFF };
    private static final int ROW = 22, LW = 148;

    private ZModule selected = ZorixClient.MODULES.get(0);
    private float scroll, scrollTarget, alpha, editHover;
    private final long openAt = System.nanoTime();
    private long lastNano = openAt;

    private int W, H, x0, y0, lx, ly, lh, px, py, pw;

    public ZorixScreen() {
        super(Text.literal(ZorixClient.NAME));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, Draw.fade(0xB0000000, alpha));
    }

    @Override
    public void close() {
        Config.save();
        super.close();
    }

    private int f(int color) { return Draw.fade(color, alpha); }

    private void layout() {
        W = Math.min(width - 24, 480);
        H = Math.min(height - 24, 300);
        x0 = (width - W) / 2;
        y0 = (height - H) / 2 + (int) ((1f - alpha) * 14);
        lx = x0 + 8;
        ly = y0 + 38;
        lh = H - 38 - 34;
        px = x0 + LW + 24;
        py = y0 + 40;
        pw = W - LW - 24 - 12;
    }

    private void drawSwitch(DrawContext ctx, int sx, int sy, float a) {
        int track = Draw.lerpColor(0xFF3A3A44, Draw.RED, a);
        Draw.rounded(ctx, sx, sy, 22, 10, 5, f(track));
        Draw.rounded(ctx, sx + 1 + (int) (a * 12), sy + 1, 8, 8, 4, f(Draw.WHITE));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNano) / 1.0e9f);
        lastNano = now;
        alpha = Draw.ease((now - openAt) / 2.5e8f);
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
        layout();
        renderBackground(ctx, mx, my, delta);

        TextRenderer tr = textRenderer;
        List<ZModule> mods = ZorixClient.MODULES;
        for (ZModule m : mods) m.anim += ((m.enabled ? 1f : 0f) - m.anim) * Math.min(1f, dt * 14f);

        // window
        Draw.rounded(ctx, x0 - 1, y0 - 1, W + 2, H + 2, 7, f(0x40E11D2E));
        Draw.rounded(ctx, x0, y0, W, H, 6, f(0xF2121216));
        ctx.fill(x0 + 6, y0, x0 + W - 6, y0 + 2, f(Draw.RED));

        // header
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x0 + 12, y0 + 10, 0);
        ctx.getMatrices().scale(1.4f, 1.4f, 1f);
        ctx.drawText(tr, ZorixClient.NAME, 0, 0, f(Draw.RED), true);
        ctx.getMatrices().pop();
        String ver = "1.21.4  |  RIGHT SHIFT";
        ctx.drawText(tr, ver, x0 + W - 12 - tr.getWidth(ver), y0 + 14, f(Draw.MUTED), false);
        ctx.fill(x0 + 8, y0 + 32, x0 + W - 8, y0 + 33, f(0x30FFFFFF));

        // module list
        ctx.enableScissor(lx, ly, lx + LW, ly + lh);
        for (int i = 0; i < mods.size(); i++) {
            ZModule m = mods.get(i);
            int ry = ly + i * ROW - (int) scroll;
            if (ry + ROW < ly || ry > ly + lh) continue;
            boolean hov = mx >= lx && mx < lx + LW && my >= Math.max(ry, ly) && my < Math.min(ry + ROW - 2, ly + lh);
            m.hover += ((hov ? 1f : 0f) - m.hover) * Math.min(1f, dt * 14f);
            int bg = (m == selected) ? Draw.withAlpha(Draw.RED, 0x50) : Draw.lerpColor(0x00FFFFFF, 0x18FFFFFF, m.hover);
            Draw.rounded(ctx, lx, ry, LW, ROW - 2, 3, f(bg));
            if (m == selected) ctx.fill(lx, ry + 4, lx + 2, ry + ROW - 6, f(Draw.RED));
            ctx.drawText(tr, m.name, lx + 8, ry + 6, f(Draw.WHITE), false);
            drawSwitch(ctx, lx + LW - 28, ry + 5, m.anim);
        }
        ctx.disableScissor();

        // HUD editor button
        int bx = lx, by = y0 + H - 26, bw = LW, bh = 18;
        boolean hovBtn = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        editHover += ((hovBtn ? 1f : 0f) - editHover) * Math.min(1f, dt * 14f);
        Draw.rounded(ctx, bx, by, bw, bh, 4, f(Draw.RED));
        Draw.rounded(ctx, bx + 1, by + 1, bw - 2, bh - 2, 3, f(Draw.lerpColor(0xFF121216, 0xFF3A0D12, editHover)));
        String bt = "HUD EDITOR";
        ctx.drawText(tr, bt, bx + (bw - tr.getWidth(bt)) / 2, by + 5, f(Draw.WHITE), false);

        // right pane
        ZModule s = selected;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(px, py, 0);
        ctx.getMatrices().scale(1.25f, 1.25f, 1f);
        ctx.drawText(tr, s.name, 0, 0, f(Draw.WHITE), true);
        ctx.getMatrices().pop();

        List<OrderedText> lines = tr.wrapLines(Text.literal(s.description), pw);
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            ctx.drawText(tr, lines.get(i), px, py + 15 + i * 10, f(Draw.MUTED), false);
        }

        ctx.drawText(tr, "Enabled", px, py + 41, f(Draw.WHITE), false);
        drawSwitch(ctx, px + pw - 22, py + 39, s.anim);

        ctx.drawText(tr, "Color", px, py + 58, f(Draw.WHITE), false);
        for (int i = 0; i < PALETTE.length; i++) {
            int sx = px + i * 18, sy = py + 68;
            if (s.color == PALETTE[i]) ctx.fill(sx - 1, sy - 1, sx + 15, sy + 15, f(Draw.WHITE));
            Draw.rounded(ctx, sx, sy, 14, 14, 3, f(Draw.argb(PALETTE[i])));
        }

        ctx.drawText(tr, "Settings", px, py + 88, f(Draw.RED), false);
        if (s.settings.isEmpty()) {
            ctx.drawText(tr, "No extra settings.", px, py + 100, f(Draw.MUTED), false);
        }
        for (int i = 0; i < s.settings.size(); i++) {
            Setting st = s.settings.get(i);
            int yy = py + 100 + i * 18;
            ctx.drawText(tr, st.name, px, yy + 3, f(Draw.WHITE), false);
            if (st.kind == Setting.Kind.BOOL) {
                drawSwitch(ctx, px + pw - 22, yy + 2, st.on() ? 1f : 0f);
            } else {
                int cx = px + pw - 90;
                Draw.rounded(ctx, cx, yy, 14, 14, 3, f(0xFF2A2A32));
                Draw.rounded(ctx, cx + 76, yy, 14, 14, 3, f(0xFF2A2A32));
                ctx.drawText(tr, "<", cx + 4, yy + 3, f(Draw.WHITE), false);
                ctx.drawText(tr, ">", cx + 80, yy + 3, f(Draw.WHITE), false);
                String v = st.display();
                ctx.drawText(tr, v, cx + 14 + (62 - tr.getWidth(v)) / 2, yy + 3, f(Draw.RED), false);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mxD, double myD, int button) {
        if (button != 0) return super.mouseClicked(mxD, myD, button);
        layout();
        int mx = (int) mxD, my = (int) myD;
        List<ZModule> mods = ZorixClient.MODULES;

        // module list
        if (mx >= lx && mx < lx + LW && my >= ly && my < ly + lh) {
            int idx = (int) ((my - ly + scroll) / ROW);
            if (idx >= 0 && idx < mods.size()) {
                if (mx >= lx + LW - 32) mods.get(idx).toggle(); else selected = mods.get(idx);
                return true;
            }
        }
        // HUD editor button
        int by = y0 + H - 26;
        if (mx >= lx && mx < lx + LW && my >= by && my < by + 18) {
            Config.save();
            client.setScreen(new HudEditScreen(this));
            return true;
        }
        // enabled row
        if (mx >= px && mx < px + pw && my >= py + 38 && my < py + 52) {
            selected.toggle();
            return true;
        }
        // color swatches
        for (int i = 0; i < PALETTE.length; i++) {
            int sx = px + i * 18, sy = py + 68;
            if (mx >= sx && mx < sx + 14 && my >= sy && my < sy + 14) {
                selected.color = PALETTE[i];
                return true;
            }
        }
        // settings
        for (int i = 0; i < selected.settings.size(); i++) {
            Setting st = selected.settings.get(i);
            int yy = py + 100 + i * 18;
            if (my < yy || my >= yy + 16) continue;
            if (st.kind == Setting.Kind.BOOL) {
                if (mx >= px + pw - 26) { st.inc(1); return true; }
            } else {
                int cx = px + pw - 90;
                if (mx >= cx && mx < cx + 14) { st.inc(-1); return true; }
                if (mx >= cx + 76 && mx < cx + 90) { st.inc(1); return true; }
            }
        }
        return super.mouseClicked(mxD, myD, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int max = Math.max(0, ZorixClient.MODULES.size() * ROW - lh);
        scrollTarget = Math.max(0, Math.min(max, scrollTarget - (float) vertical * ROW));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}

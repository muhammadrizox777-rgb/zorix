package uz.zorix.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import uz.zorix.Config;
import uz.zorix.Draw;
import uz.zorix.ZModule;
import uz.zorix.ZorixClient;

import java.util.List;

public class HudEditScreen extends Screen {
    private final Screen parent;
    private ZModule dragging;
    private int offX, offY;

    public HudEditScreen(Screen parent) {
        super(Text.literal("ZORIX CLIENT - HUD Editor"));
        this.parent = parent;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x60000000);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        String hint = "Drag elements to move them   |   Right-click: ON / OFF   |   ESC: back";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, 8, Draw.WHITE, true);

        for (ZModule m : ZorixClient.MODULES) {
            if (!m.draggable) continue;
            m.x = Math.max(0, Math.min(m.x, width - m.w));
            m.y = Math.max(0, Math.min(m.y, height - m.h));
            m.render(ctx, client, true);

            boolean hov = mx >= m.x && mx < m.x + m.w && my >= m.y && my < m.y + m.h;
            int col = (dragging == m || hov) ? 0xFFFFFFFF : (m.enabled ? Draw.RED : 0xFF77777F);
            ctx.fill(m.x - 1, m.y - 1, m.x + m.w + 1, m.y, col);
            ctx.fill(m.x - 1, m.y + m.h, m.x + m.w + 1, m.y + m.h + 1, col);
            ctx.fill(m.x - 1, m.y, m.x, m.y + m.h, col);
            ctx.fill(m.x + m.w, m.y, m.x + m.w + 1, m.y + m.h, col);
            String label = m.name + (m.enabled ? "" : " (OFF)");
            int ly = m.y >= 11 ? m.y - 10 : m.y + m.h + 2;
            ctx.drawText(textRenderer, label, m.x, ly, col, true);
        }
    }

    @Override
    public boolean mouseClicked(double mxD, double myD, int button) {
        int mx = (int) mxD, my = (int) myD;
        List<ZModule> mods = ZorixClient.MODULES;
        for (int i = mods.size() - 1; i >= 0; i--) {
            ZModule m = mods.get(i);
            if (!m.draggable) continue;
            if (mx >= m.x && mx < m.x + m.w && my >= m.y && my < m.y + m.h) {
                if (button == 1) {
                    m.toggle();
                } else if (button == 0) {
                    dragging = m;
                    offX = mx - m.x;
                    offY = my - m.y;
                }
                return true;
            }
        }
        return super.mouseClicked(mxD, myD, button);
    }

    @Override
    public boolean mouseDragged(double mxD, double myD, int button, double dx, double dy) {
        if (dragging != null && button == 0) {
            dragging.x = Math.max(0, Math.min((int) mxD - offX, width - dragging.w));
            dragging.y = Math.max(0, Math.min((int) myD - offY, height - dragging.h));
            return true;
        }
        return super.mouseDragged(mxD, myD, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }
}

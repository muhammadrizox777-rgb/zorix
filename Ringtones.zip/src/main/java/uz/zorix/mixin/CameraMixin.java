package uz.zorix.mixin;

import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import uz.zorix.modules.Freelook;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float zorix$yaw(float yaw) {
        return Freelook.active ? Freelook.yaw : yaw;
    }

    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private float zorix$pitch(float pitch) {
        return Freelook.active ? Freelook.pitch : pitch;
    }
}

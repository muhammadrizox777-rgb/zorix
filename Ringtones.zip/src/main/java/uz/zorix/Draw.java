package uz.zorix;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int RED = 0xFFE11D2E;
    public static final int BG = 0xC0121216;
    public static final int MUTED = 0xFF9A9AA5;
    public static final int WHITE = 0xFFFFFFFF;

    private Draw() {}

    public static int argb(int rgb) { return 0xFF000000 | (rgb & 0xFFFFFF); }

    public static int withAlpha(int color, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF);
    }

    public static int fade(int color, float k) {
        int a = (int) ((color >>> 24) * Math.max(0f, Math.min(1f, k)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float u = 1f - t;
        return 1f - u * u * u;
    }

    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) lerp(a >>> 24, b >>> 24, t);
        int ar = (int) lerp((a >> 16) & 255, (b >> 16) & 255, t);
        int ag = (int) lerp((a >> 8) & 255, (b >> 8) & 255, t);
        int ab = (int) lerp(a & 255, b & 255, t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    public static void rounded(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (r <= 0 || w < 2 * r || h < 2 * r) { c.fill(x, y, x + w, y + h, col); return; }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, col);
        }
    }

    public static void panel(DrawContext c, int x, int y, int w, int h, int accent) {
        rounded(c, x, y, w, h, 3, BG);
        c.fill(x, y + 2, x + 2, y + h - 2, accent);
    }

    public static void labelValue(DrawContext ctx, MinecraftClient mc, ZModule m, String label, String value) {
        TextRenderer tr = mc.textRenderer;
        int lw = tr.getWidth(label), vw = tr.getWidth(value);
        m.w = 7 + lw + 6 + vw + 6;
        m.h = 16;
        panel(ctx, m.x, m.y, m.w, m.h, m.accent());
        ctx.drawText(tr, label, m.x + 7, m.y + 4, MUTED, false);
        ctx.drawText(tr, value, m.x + 7 + lw + 6, m.y + 4, m.accent(), false);
    }
}

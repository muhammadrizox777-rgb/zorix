# Bundled fonts

All bundled fonts are from the Google Fonts repository and licensed under the SIL Open Font License 1.1
(see the *-OFL.txt files). They are used by the "Interface font" setting of the ClientColor module.

package uz.semvisuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;
import uz.semvisuals.core.Friends;
import uz.semvisuals.core.Markers;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Util;
import uz.semvisuals.gui.ClickGui;
import uz.semvisuals.module.Hud;
import uz.semvisuals.module.Utils;
import uz.semvisuals.module.Visuals;

public final class SemVisualsClient implements ClientModInitializer {
    private static KeyMapping openMenuKey;
    private boolean wasInWorld;

    @Override
    public void onInitializeClient() {
        Visuals.registerAll();
        Hud.registerAll();
        Utils.registerAll();
        Friends.load();
        Markers.load();
        ModuleManager.load("default");

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("semvisuals", "main")
        );
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.semvisuals.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        // Replace the vanilla crosshair when the Crosshair module is on.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, delta) -> {
            Visuals.Crosshair crosshair = ModuleManager.get(Visuals.Crosshair.class);
            if (crosshair != null && crosshair.isEnabled()) {
                crosshair.draw(graphics);
            } else {
                original.render(graphics, delta);
            }
        });

        // All module overlays are drawn after the vanilla HUD.
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("semvisuals", "overlay"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null) {
                return;
            }
            for (Module m : ModuleManager.MODULES) {
                if (m.isEnabled()) {
                    try {
                        m.renderHud(graphics, delta);
                    } catch (RuntimeException ignored) {
                        // a broken overlay must never crash the game
                    }
                }
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClientSide() && entity instanceof LivingEntity living) {
                Util.onAttack(living);
                for (Module m : ModuleManager.MODULES) {
                    if (m.isEnabled()) {
                        m.onAttack(living);
                    }
                }
            }
            return InteractionResult.PASS;
        });

        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
            Utils.ChatHelper chat = ModuleManager.get(Utils.ChatHelper.class);
            return chat != null && chat.isEnabled() && !overlay ? chat.modify(message) : message;
        });

        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> {
            Utils.CommandSafe safe = ModuleManager.get(Utils.CommandSafe.class);
            return safe == null || !safe.isEnabled() || safe.allows(command);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Utils.AutoReconnect reconnect = ModuleManager.get(Utils.AutoReconnect.class);
            if (reconnect != null && reconnect.isEnabled()) {
                reconnect.tickAlways();
            }

            boolean inWorld = client.player != null && client.level != null;
            if (inWorld && !wasInWorld) {
                for (Module m : ModuleManager.MODULES) {
                    if (m.isEnabled()) {
                        m.onJoin();
                    }
                }
            }
            wasInWorld = inWorld;
            if (!inWorld) {
                return;
            }

            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClickGui());
                }
            }

            for (Module m : ModuleManager.MODULES) {
                if (client.screen == null && m.key >= 0) {
                    boolean down = InputConstants.isKeyDown(client.getWindow(), m.key);
                    if (down && !m.keyWasDownPublic()) {
                        m.toggle();
                    }
                    m.setKeyWasDown(down);
                }
                if (m.isEnabled()) {
                    try {
                        m.onTick();
                    } catch (RuntimeException ignored) {
                        // keep the game running if one module misbehaves
                    }
                }
            }
        });
    }
}

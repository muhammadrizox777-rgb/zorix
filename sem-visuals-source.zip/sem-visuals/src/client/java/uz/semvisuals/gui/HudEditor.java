package uz.semvisuals.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Theme;

/** Drag enabled HUD modules around. Snaps to screen edges, the center lines and other elements. */
public final class HudEditor extends Screen {
    private static final int SNAP = 5;

    private final Screen parent;
    private Module dragged;
    private int grabX, grabY;
    private boolean snapV, snapH;
    private int guideX, guideY;

    public HudEditor(Screen parent) {
        super(Component.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        ModuleManager.save(ModuleManager.currentConfig);
        minecraft.setScreen(parent);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x55060A12);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int accent = Theme.accent();
        g.fill(width / 2, 0, width / 2 + 1, height, 0x22FFFFFF);
        g.fill(0, height / 2, width, height / 2 + 1, 0x22FFFFFF);
        boolean any = false;
        for (Module m : ModuleManager.MODULES) {
            if (!m.hudElement || !m.isEnabled()) {
                continue;
            }
            any = true;
            boolean active = m == dragged;
            boolean hover = mx >= m.hudX && mx < m.hudX + m.hudW && my >= m.hudY && my < m.hudY + m.hudH;
            int c = active ? accent : (hover ? Theme.withAlpha(accent, 0xCC) : 0x88FFFFFF);
            g.fill(m.hudX - 1, m.hudY - 1, m.hudX + m.hudW + 1, m.hudY, c);
            g.fill(m.hudX - 1, m.hudY + m.hudH, m.hudX + m.hudW + 1, m.hudY + m.hudH + 1, c);
            g.fill(m.hudX - 1, m.hudY, m.hudX, m.hudY + m.hudH, c);
            g.fill(m.hudX + m.hudW, m.hudY, m.hudX + m.hudW + 1, m.hudY + m.hudH, c);
            if (hover || active) {
                Theme.text(g, m.name, m.hudX, Math.max(0, m.hudY - 10), accent);
            }
        }
        if (dragged != null) {
            if (snapV) {
                g.fill(guideX, 0, guideX + 1, height, accent);
            }
            if (snapH) {
                g.fill(0, guideY, width, guideY + 1, accent);
            }
        }
        String hint = any ? "Drag elements. Esc to finish." : "Enable HUD modules in the menu first. Esc to go back.";
        Theme.text(g, hint, (width - Theme.width(hint)) / 2, height - 20, Theme.TEXT);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        for (int i = ModuleManager.MODULES.size() - 1; i >= 0; i--) {
            Module m = ModuleManager.MODULES.get(i);
            if (m.hudElement && m.isEnabled() && mx >= m.hudX && mx < m.hudX + m.hudW && my >= m.hudY && my < m.hudY + m.hudH) {
                dragged = m;
                grabX = (int) mx - m.hudX;
                grabY = (int) my - m.hudY;
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragged == null) {
            return super.mouseDragged(event, dx, dy);
        }
        int x = (int) event.x() - grabX;
        int y = (int) event.y() - grabY;
        snapV = false;
        snapH = false;
        int w = dragged.hudW, h = dragged.hudH;

        int[] xs = {0, (width - w) / 2, width - w};
        int[] guidesX = {0, width / 2, width};
        for (int i = 0; i < xs.length; i++) {
            if (Math.abs(x - xs[i]) <= SNAP) {
                x = xs[i];
                snapV = true;
                guideX = guidesX[i];
            }
        }
        int[] ys = {0, (height - h) / 2, height - h};
        int[] guidesY = {0, height / 2, height};
        for (int i = 0; i < ys.length; i++) {
            if (Math.abs(y - ys[i]) <= SNAP) {
                y = ys[i];
                snapH = true;
                guideY = guidesY[i];
            }
        }
        for (Module other : ModuleManager.MODULES) {
            if (other == dragged || !other.hudElement || !other.isEnabled()) {
                continue;
            }
            if (Math.abs(x - other.hudX) <= SNAP) {
                x = other.hudX;
                snapV = true;
                guideX = x;
            } else if (Math.abs(x - (other.hudX + other.hudW)) <= SNAP) {
                x = other.hudX + other.hudW;
                snapV = true;
                guideX = x;
            }
            if (Math.abs(y - other.hudY) <= SNAP) {
                y = other.hudY;
                snapH = true;
                guideY = y;
            } else if (Math.abs(y - (other.hudY + other.hudH)) <= SNAP) {
                y = other.hudY + other.hudH;
                snapH = true;
                guideY = y;
            }
        }
        dragged.hudX = Math.max(0, Math.min(width - w, x));
        dragged.hudY = Math.max(0, Math.min(height - h, y));
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragged = null;
        snapV = false;
        snapH = false;
        return super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }
}

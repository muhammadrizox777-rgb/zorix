package uz.semvisuals.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.glfw.GLFW;
import uz.semvisuals.core.Category;
import uz.semvisuals.core.Events;
import uz.semvisuals.core.Friends;
import uz.semvisuals.core.Markers;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Setting;
import uz.semvisuals.core.Theme;
import uz.semvisuals.core.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/** The Click GUI: Modules / Configs / Events / Friends / Markers tabs. Opened with Right Shift. */
public final class ClickGui extends Screen {
    private enum Tab {
        MODULES("Modules"), CONFIGS("Configs"), EVENTS("Events"), FRIENDS("Friends"), MARKERS("Markers");

        final String title;

        Tab(String title) {
            this.title = title;
        }
    }

    private record Hit(int x, int y, int w, int h, int clipTop, int clipBottom, IntConsumer click, DoubleConsumer drag) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= Math.max(y, clipTop) && my < Math.min(y + h, clipBottom);
        }
    }

    private static Tab rememberedTab = Tab.MODULES;
    private static Category rememberedCategory = Category.VISUALS;
    private static Module rememberedModule;

    private final List<Hit> hits = new ArrayList<>();
    private Hit dragging;
    private Tab tab = rememberedTab;
    private Category category = rememberedCategory;
    private Module selected = rememberedModule;
    private int scrollModules, scrollSettings, scrollList;
    private int mouseX, mouseY;
    private int px, py, pw, ph;
    private int settingsX, listX, listW, settingsW;
    private Module listeningModule;
    private Setting.Key listeningSetting;
    private String input = "";
    private boolean inputFocused;

    public ClickGui() {
        super(Component.literal("Sem Visuals"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        rememberedTab = tab;
        rememberedCategory = category;
        rememberedModule = selected;
        ModuleManager.save(ModuleManager.currentConfig);
        super.onClose();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x66060A12);
    }

    // ---------------------------------------------------------------- rendering

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        mouseX = mx;
        mouseY = my;
        hits.clear();
        pw = Math.min(600, width - 12);
        ph = Math.min(360, height - 12);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        int accent = Theme.accent();

        g.fill(px + 3, py + 4, px + pw + 3, py + ph + 4, 0x33000000);
        g.fill(px, py, px + pw, py + ph, Theme.BG);
        g.fill(px, py, px + pw, py + 2, accent);
        g.fill(px, py + 2, px + pw, py + 30, Theme.PANEL);
        g.fill(px, py + 30, px + pw, py + 31, Theme.LINE);

        Theme.text(g, "SEM VISUALS", px + 10, py + 11, accent);
        int tx = px + 100;
        for (Tab t : Tab.values()) {
            int w = Theme.width(t.title) + 16;
            boolean active = t == tab;
            boolean hover = inside(tx, py + 5, w, 20);
            if (active) {
                g.fill(tx, py + 5, tx + w, py + 25, Theme.withAlpha(accent, 0x44));
                g.fill(tx, py + 24, tx + w, py + 25, accent);
            } else if (hover) {
                g.fill(tx, py + 5, tx + w, py + 25, Theme.ROW_HOVER);
            }
            Theme.text(g, t.title, tx + 8, py + 11, active ? Theme.TEXT : Theme.MUTED);
            final Tab target = t;
            hit(tx, py + 5, w, 20, b -> switchTab(target));
            tx += w + 2;
        }
        int editorW = Theme.width("HUD Editor") + 14;
        int editorX = px + pw - editorW - 8;
        button(g, editorX, py + 6, editorW, 18, "HUD Editor", () -> minecraft.setScreen(new HudEditor(this)));

        int top = py + 36;
        int bottom = py + ph - 8;
        switch (tab) {
            case MODULES -> drawModules(g, top, bottom);
            case CONFIGS -> drawConfigs(g, top, bottom);
            case EVENTS -> drawEvents(g, top, bottom);
            case FRIENDS -> drawFriends(g, top, bottom);
            case MARKERS -> drawMarkers(g, top, bottom);
        }
        Theme.text(g, "Right Shift: close  |  Config: " + ModuleManager.currentConfig, px + 10, py + ph - 12, Theme.MUTED);
    }

    private void switchTab(Tab t) {
        tab = t;
        scrollList = 0;
        input = "";
        inputFocused = false;
        listeningModule = null;
        listeningSetting = null;
    }

    private boolean inside(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(int x, int y, int w, int h, IntConsumer click) {
        hits.add(new Hit(x, y, w, h, Integer.MIN_VALUE, Integer.MAX_VALUE, click, null));
    }

    private void hitClipped(int x, int y, int w, int h, int clipTop, int clipBottom, IntConsumer click, DoubleConsumer drag) {
        hits.add(new Hit(x, y, w, h, clipTop, clipBottom, click, drag));
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, Runnable action) {
        boolean hover = inside(x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? Theme.ROW_HOVER : Theme.ROW);
        g.fill(x, y + h - 1, x + w, y + h, hover ? Theme.accent() : Theme.LINE);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hit(x, y, w, h, b -> action.run());
    }

    private void pill(GuiGraphics g, int x, int y, boolean on) {
        g.fill(x, y, x + 24, y + 11, on ? Theme.withAlpha(Theme.accent(), 0xFF) : 0xFF2A3350);
        int knob = on ? x + 14 : x + 2;
        g.fill(knob, y + 2, knob + 8, y + 9, 0xFFFFFFFF);
    }

    // ---------------------------------------------------------------- modules tab

    private void drawModules(GuiGraphics g, int top, int bottom) {
        int catW = 96;
        settingsW = Math.min(210, pw / 3);
        listX = px + 8 + catW + 8;
        settingsX = px + pw - 8 - settingsW;
        listW = settingsX - 8 - listX;

        int cy = top;
        for (Category c : Category.values()) {
            boolean active = c == category;
            boolean hover = inside(px + 8, cy, catW, 22);
            g.fill(px + 8, cy, px + 8 + catW, cy + 22, active ? Theme.withAlpha(Theme.accent(), 0x40) : (hover ? Theme.ROW_HOVER : Theme.ROW));
            if (active) {
                g.fill(px + 8, cy, px + 11, cy + 22, Theme.accent());
            }
            Theme.text(g, c.title, px + 18, cy + 7, active ? Theme.TEXT : Theme.MUTED);
            String count = Integer.toString(ModuleManager.in(c).size());
            Theme.text(g, count, px + 8 + catW - Theme.width(count) - 6, cy + 7, Theme.MUTED);
            final Category target = c;
            hit(px + 8, cy, catW, 22, b -> {
                category = target;
                scrollModules = 0;
            });
            cy += 25;
        }

        // module list
        List<Module> list = ModuleManager.in(category);
        int rowH = 22;
        int content = list.size() * rowH;
        scrollModules = Math.max(0, Math.min(scrollModules, Math.max(0, content - (bottom - top))));
        g.enableScissor(listX, top, listX + listW, bottom);
        int y = top - scrollModules;
        for (Module m : list) {
            boolean hover = inside(listX, y, listW, rowH - 2) && mouseY >= top && mouseY < bottom;
            boolean sel = m == selected;
            g.fill(listX, y, listX + listW, y + rowH - 2, sel ? Theme.withAlpha(Theme.accent(), 0x30) : (hover ? Theme.ROW_HOVER : Theme.ROW));
            if (m.isEnabled()) {
                g.fill(listX, y, listX + 2, y + rowH - 2, Theme.accent());
            }
            Theme.text(g, m.name, listX + 9, y + 6, m.isEnabled() ? Theme.TEXT : Theme.MUTED);
            if (m.key >= 0) {
                String k = "[" + Util.keyName(m.key) + "]";
                Theme.text(g, k, listX + listW - 36 - Theme.width(k), y + 6, Theme.MUTED);
            }
            pill(g, listX + listW - 32, y + 5, m.isEnabled());
            final Module target = m;
            hitClipped(listX + listW - 34, y, 34, rowH - 2, top, bottom, b -> target.toggle(), null);
            hitClipped(listX, y, listW - 34, rowH - 2, top, bottom, b -> {
                if (b == 1) {
                    target.toggle();
                } else {
                    selected = target;
                    scrollSettings = 0;
                }
            }, null);
            y += rowH;
        }
        g.disableScissor();

        // settings panel
        g.fill(settingsX, top, settingsX + settingsW, bottom, Theme.PANEL);
        if (selected == null) {
            Theme.text(g, "Select a module", settingsX + 10, top + 10, Theme.MUTED);
            Theme.text(g, "Left click: settings", settingsX + 10, top + 26, Theme.MUTED);
            Theme.text(g, "Right click: toggle", settingsX + 10, top + 38, Theme.MUTED);
            return;
        }
        drawSettings(g, top, bottom);
    }

    private void drawSettings(GuiGraphics g, int top, int bottom) {
        Module m = selected;
        int x = settingsX + 8, w = settingsW - 16;
        Theme.text(g, m.name, x, top + 6, Theme.TEXT);
        List<String> desc = wrap(m.description, w);
        int dy = top + 18;
        for (String line : desc) {
            Theme.text(g, line, x, dy, Theme.MUTED);
            dy += 10;
        }
        int areaTop = dy + 4;
        g.fill(settingsX + 4, areaTop - 2, settingsX + settingsW - 4, areaTop - 1, Theme.LINE);

        int total = 0;
        total += 24 + 24; // enabled + key
        for (Setting<?> s : m.settings) {
            if (s.visible.getAsBoolean()) {
                total += rowHeight(s);
            }
        }
        scrollSettings = Math.max(0, Math.min(scrollSettings, Math.max(0, total - (bottom - areaTop))));
        g.enableScissor(settingsX, areaTop, settingsX + settingsW, bottom);
        int y = areaTop - scrollSettings;

        // enabled row
        rowBg(g, x, y, w, 20);
        Theme.text(g, "Enabled", x + 6, y + 6, Theme.TEXT);
        pill(g, x + w - 30, y + 4, m.isEnabled());
        hitClipped(x, y, w, 20, areaTop, bottom, b -> m.toggle(), null);
        y += 24;

        // keybind row
        rowBg(g, x, y, w, 20);
        Theme.text(g, "Keybind", x + 6, y + 6, Theme.TEXT);
        String key = listeningModule == m ? "press a key..." : Util.keyName(m.key);
        Theme.text(g, key, x + w - Theme.width(key) - 6, y + 6, listeningModule == m ? Theme.accent() : Theme.MUTED);
        hitClipped(x, y, w, 20, areaTop, bottom, b -> {
            if (b == 1) {
                m.key = -1;
            } else {
                listeningModule = m;
                listeningSetting = null;
            }
        }, null);
        y += 24;

        for (Setting<?> s : m.settings) {
            if (!s.visible.getAsBoolean()) {
                continue;
            }
            int h = rowHeight(s);
            drawSetting(g, s, x, y, w, h, areaTop, bottom);
            y += h;
        }
        g.disableScissor();
    }

    private int rowHeight(Setting<?> s) {
        if (s instanceof Setting.Num) {
            return 30;
        }
        if (s instanceof Setting.Color) {
            return 62;
        }
        return 24;
    }

    private void rowBg(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, Theme.ROW);
    }

    private void drawSetting(GuiGraphics g, Setting<?> s, int x, int y, int w, int h, int clipTop, int clipBottom) {
        rowBg(g, x, y, w, h - 4);
        if (s instanceof Setting.Bool b) {
            Theme.text(g, b.name, x + 6, y + 6, Theme.TEXT);
            pill(g, x + w - 30, y + 4, b.get());
            hitClipped(x, y, w, h - 4, clipTop, clipBottom, btn -> b.value = !b.value, null);
        } else if (s instanceof Setting.Num n) {
            String val = n.step >= 1 ? Integer.toString(n.asInt()) : String.format("%.2f", n.get());
            Theme.text(g, n.name, x + 6, y + 4, Theme.TEXT);
            Theme.text(g, val, x + w - Theme.width(val) - 6, y + 4, Theme.MUTED);
            int bx = x + 6, bw = w - 12, by = y + 18;
            g.fill(bx, by, bx + bw, by + 4, 0xFF2A3350);
            double frac = (n.get() - n.min) / (n.max - n.min);
            g.fill(bx, by, bx + (int) (bw * frac), by + 4, Theme.accent());
            g.fill(bx + (int) (bw * frac) - 2, by - 2, bx + (int) (bw * frac) + 2, by + 6, 0xFFFFFFFF);
            DoubleConsumer drag = mx -> n.set(n.min + Math.max(0, Math.min(1, (mx - bx) / (double) bw)) * (n.max - n.min));
            hitClipped(bx - 2, y + 12, bw + 4, 14, clipTop, clipBottom, btn -> drag.accept(mouseX), drag);
        } else if (s instanceof Setting.Mode mode) {
            Theme.text(g, mode.name, x + 6, y + 6, Theme.TEXT);
            Theme.text(g, mode.get(), x + w - Theme.width(mode.get()) - 6, y + 6, Theme.accent());
            hitClipped(x, y, w, h - 4, clipTop, clipBottom, btn -> mode.cycle(btn == 1 ? -1 : 1), null);
        } else if (s instanceof Setting.Key k) {
            Theme.text(g, k.name, x + 6, y + 6, Theme.TEXT);
            String label = listeningSetting == k ? "press a key..." : Util.keyName(k.get());
            Theme.text(g, label, x + w - Theme.width(label) - 6, y + 6, listeningSetting == k ? Theme.accent() : Theme.MUTED);
            hitClipped(x, y, w, h - 4, clipTop, clipBottom, btn -> {
                if (btn == 1) {
                    k.value = -1;
                } else {
                    listeningSetting = k;
                    listeningModule = null;
                }
            }, null);
        } else if (s instanceof Setting.Color c) {
            drawColor(g, c, x, y, w, clipTop, clipBottom);
        }
    }

    private void drawColor(GuiGraphics g, Setting.Color c, int x, int y, int w, int clipTop, int clipBottom) {
        Theme.text(g, c.name, x + 6, y + 4, Theme.TEXT);
        g.fill(x + w - 26, y + 3, x + w - 6, y + 13, c.get() | 0xFF000000);
        float[] hsb = java.awt.Color.RGBtoHSB((c.get() >> 16) & 0xFF, (c.get() >> 8) & 0xFF, c.get() & 0xFF, null);
        int bx = x + 6, bw = w - 12;
        // hue
        int hy = y + 18;
        int segments = 24;
        for (int i = 0; i < segments; i++) {
            int x1 = bx + bw * i / segments, x2 = bx + bw * (i + 1) / segments;
            g.fill(x1, hy, x2, hy + 8, Theme.hsb(i / (float) segments, 1f, 1f));
        }
        g.fill(bx + (int) (bw * hsb[0]) - 1, hy - 1, bx + (int) (bw * hsb[0]) + 1, hy + 9, 0xFFFFFFFF);
        DoubleConsumer hue = mx -> c.value = Theme.hsb((float) Math.max(0, Math.min(0.999, (mx - bx) / (double) bw)), hsb[1], hsb[2]);
        hitClipped(bx, hy - 2, bw, 12, clipTop, clipBottom, b -> hue.accept(mouseX), hue);
        // saturation
        int sy = y + 30;
        g.fillGradient(bx, sy, bx + bw, sy + 8, 0xFFFFFFFF, 0xFFFFFFFF);
        for (int i = 0; i < segments; i++) {
            int x1 = bx + bw * i / segments, x2 = bx + bw * (i + 1) / segments;
            g.fill(x1, sy, x2, sy + 8, Theme.hsb(hsb[0], i / (float) (segments - 1), hsb[2]));
        }
        g.fill(bx + (int) (bw * hsb[1]) - 1, sy - 1, bx + (int) (bw * hsb[1]) + 1, sy + 9, 0xFFFFFFFF);
        DoubleConsumer sat = mx -> c.value = Theme.hsb(hsb[0], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)), hsb[2]);
        hitClipped(bx, sy - 2, bw, 12, clipTop, clipBottom, b -> sat.accept(mouseX), sat);
        // brightness
        int vy = y + 42;
        for (int i = 0; i < segments; i++) {
            int x1 = bx + bw * i / segments, x2 = bx + bw * (i + 1) / segments;
            g.fill(x1, vy, x2, vy + 8, Theme.hsb(hsb[0], hsb[1], i / (float) (segments - 1)));
        }
        g.fill(bx + (int) (bw * hsb[2]) - 1, vy - 1, bx + (int) (bw * hsb[2]) + 1, vy + 9, 0xFFFFFFFF);
        DoubleConsumer val = mx -> c.value = Theme.hsb(hsb[0], hsb[1], (float) Math.max(0, Math.min(1, (mx - bx) / (double) bw)));
        hitClipped(bx, vy - 2, bw, 12, clipTop, clipBottom, b -> val.accept(mouseX), val);
    }

    private List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            if (Theme.width(line + word) > width && line.length() > 0) {
                lines.add(line.toString().trim());
                line.setLength(0);
            }
            line.append(word).append(' ');
        }
        if (line.length() > 0) {
            lines.add(line.toString().trim());
        }
        return lines;
    }

    // ---------------------------------------------------------------- configs tab

    private void drawInputRow(GuiGraphics g, int top, String placeholder, String buttonLabel, Runnable submit) {
        int x = px + 8;
        int bw = Theme.width(buttonLabel) + 16;
        int fw = pw - 16 - bw - 6;
        boolean focus = inputFocused;
        g.fill(x, top, x + fw, top + 20, Theme.ROW);
        g.fill(x, top + 19, x + fw, top + 20, focus ? Theme.accent() : Theme.LINE);
        String shown = input.isEmpty() && !focus ? placeholder : input + (focus && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Theme.text(g, shown, x + 6, top + 6, input.isEmpty() && !focus ? Theme.MUTED : Theme.TEXT);
        hit(x, top, fw, 20, b -> inputFocused = true);
        button(g, x + fw + 6, top, bw, 20, buttonLabel, submit);
    }

    private void drawConfigs(GuiGraphics g, int top, int bottom) {
        drawInputRow(g, top, "New config name", "Save", () -> {
            if (!input.isBlank()) {
                String name = ModuleManager.sanitize(input);
                ModuleManager.save(name);
                ModuleManager.currentConfig = name;
                Events.info("Config", "Saved " + name);
                input = "";
            }
        });
        List<String> names = ModuleManager.configNames();
        int listTop = top + 28;
        drawScrollableList(g, listTop, bottom, names.size(), 22, (i, y) -> {
            String name = names.get(i);
            boolean current = name.equals(ModuleManager.currentConfig);
            g.fill(px + 8, y, px + pw - 8, y + 20, Theme.ROW);
            if (current) {
                g.fill(px + 8, y, px + 10, y + 20, Theme.accent());
            }
            Theme.text(g, name + (current ? "  (active)" : ""), px + 16, y + 6, Theme.TEXT);
            int bx = px + pw - 8;
            bx -= 52;
            smallButton(g, bx, y + 2, 50, 16, "Delete", listTop, bottom, () -> ModuleManager.delete(name));
            bx -= 52;
            smallButton(g, bx, y + 2, 50, 16, "Save", listTop, bottom, () -> {
                ModuleManager.save(name);
                ModuleManager.currentConfig = name;
                Events.info("Config", "Saved " + name);
            });
            bx -= 52;
            smallButton(g, bx, y + 2, 50, 16, "Load", listTop, bottom, () -> {
                if (ModuleManager.load(name)) {
                    Events.info("Config", "Loaded " + name);
                }
            });
        });
        if (names.isEmpty()) {
            Theme.text(g, "No saved configs yet. Type a name and press Save.", px + 10, listTop + 6, Theme.MUTED);
        }
    }

    private void smallButton(GuiGraphics g, int x, int y, int w, int h, String label, int clipTop, int clipBottom, Runnable action) {
        boolean hover = inside(x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? Theme.ROW_HOVER : 0xFF222B44);
        Theme.text(g, label, x + (w - Theme.width(label)) / 2, y + 4, Theme.TEXT);
        hitClipped(x, y, w, h, clipTop, clipBottom, b -> action.run(), null);
    }

    private interface RowDrawer {
        void draw(int index, int y);
    }

    private void drawScrollableList(GuiGraphics g, int top, int bottom, int count, int rowH, RowDrawer drawer) {
        int content = count * rowH;
        scrollList = Math.max(0, Math.min(scrollList, Math.max(0, content - (bottom - top))));
        g.enableScissor(px + 4, top, px + pw - 4, bottom);
        for (int i = 0; i < count; i++) {
            int y = top + i * rowH - scrollList;
            if (y + rowH < top || y > bottom) {
                continue;
            }
            drawer.draw(i, y);
        }
        g.disableScissor();
    }

    // ---------------------------------------------------------------- events tab

    private void drawEvents(GuiGraphics g, int top, int bottom) {
        List<String> log = Events.LOG;
        if (log.isEmpty()) {
            Theme.text(g, "No events yet. Toggles, alerts and pickups show up here.", px + 10, top + 6, Theme.MUTED);
            return;
        }
        drawScrollableList(g, top, bottom, log.size(), 13, (i, y) -> {
            String line = log.get(log.size() - 1 - i);
            Theme.text(g, line, px + 12, y + 2, i == 0 ? Theme.TEXT : Theme.MUTED);
        });
    }

    // ---------------------------------------------------------------- friends tab

    private void drawFriends(GuiGraphics g, int top, int bottom) {
        drawInputRow(g, top, "Player name", "Add", () -> {
            Friends.add(input);
            input = "";
        });
        int addX = px + 8;
        int y0 = top + 26;
        button(g, addX, y0, 150, 18, "Add player I'm looking at", () -> {
            var t = Util.target();
            if (t instanceof Player p) {
                Friends.add(p.getName().getString());
                Events.info("Friends", "Added " + p.getName().getString());
            }
        });
        List<String> names = new ArrayList<>(Friends.all());
        int listTop = y0 + 24;
        drawScrollableList(g, listTop, bottom, names.size(), 22, (i, y) -> {
            String name = names.get(i);
            g.fill(px + 8, y, px + pw - 8, y + 20, Theme.ROW);
            Theme.text(g, name, px + 16, y + 6, Theme.GOOD);
            smallButton(g, px + pw - 8 - 60, y + 2, 58, 16, "Remove", listTop, bottom, () -> Friends.remove(name));
        });
        if (names.isEmpty()) {
            Theme.text(g, "Friends are highlighted green by ArrowNametag.", px + 10, listTop + 6, Theme.MUTED);
        }
    }

    // ---------------------------------------------------------------- markers tab

    private void drawMarkers(GuiGraphics g, int top, int bottom) {
        drawInputRow(g, top, "Marker name (saved at your position)", "Add here", () -> {
            if (minecraft.player != null && !input.isBlank()) {
                Markers.add(input.trim(), minecraft.player.getX(), minecraft.player.getY(), minecraft.player.getZ(), Util.dimensionName());
                input = "";
            }
        });
        List<Markers.Marker> list = new ArrayList<>(Markers.LIST);
        int listTop = top + 28;
        drawScrollableList(g, listTop, bottom, list.size(), 22, (i, y) -> {
            Markers.Marker m = list.get(i);
            g.fill(px + 8, y, px + pw - 8, y + 20, Theme.ROW);
            Theme.text(g, m.name(), px + 16, y + 6, Theme.TEXT);
            String pos = String.format("%.0f %.0f %.0f  %s", m.x(), m.y(), m.z(), m.dimension().replace("minecraft:", ""));
            Theme.text(g, pos, px + 140, y + 6, Theme.MUTED);
            smallButton(g, px + pw - 8 - 60, y + 2, 58, 16, "Remove", listTop, bottom, () -> Markers.remove(m));
        });
        if (list.isEmpty()) {
            Theme.text(g, "Enable MarkerOverlay (HUD) to see markers in the world.", px + 10, listTop + 6, Theme.MUTED);
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        inputFocused = false;
        listeningModule = listeningModule != null && event.button() >= 0 ? listeningModule : null;
        double mx = event.x(), my = event.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                mouseX = (int) mx;
                mouseY = (int) my;
                h.click().accept(event.button());
                if (h.drag() != null) {
                    dragging = h;
                }
                return true;
            }
        }
        listeningModule = null;
        listeningSetting = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging != null && dragging.drag() != null) {
            dragging.drag().accept(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        int amount = (int) (-vertical * 22);
        if (tab == Tab.MODULES) {
            if (x >= settingsX) {
                scrollSettings = Math.max(0, scrollSettings + amount);
            } else if (x >= listX) {
                scrollModules = Math.max(0, scrollModules + amount);
            }
        } else {
            scrollList = Math.max(0, scrollList + amount);
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listeningModule != null || listeningSetting != null) {
            int value = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            if (listeningModule != null) {
                listeningModule.key = value;
            } else {
                listeningSetting.value = value;
            }
            listeningModule = null;
            listeningSetting = null;
            return true;
        }
        if (inputFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) {
                input = input.substring(0, input.length() - 1);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                inputFocused = false;
                return true;
            }
            if (key == 257 || key == 335) { // enter / keypad enter
                for (int i = hits.size() - 1; i >= 0; i--) {
                    // the submit button is the last hit registered by drawInputRow; trigger via the first matching button area
                }
                submitInput();
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    private void submitInput() {
        switch (tab) {
            case CONFIGS -> {
                if (!input.isBlank()) {
                    String name = ModuleManager.sanitize(input);
                    ModuleManager.save(name);
                    ModuleManager.currentConfig = name;
                    input = "";
                }
            }
            case FRIENDS -> {
                Friends.add(input);
                input = "";
            }
            case MARKERS -> {
                if (minecraft.player != null && !input.isBlank()) {
                    Markers.add(input.trim(), minecraft.player.getX(), minecraft.player.getY(), minecraft.player.getZ(), Util.dimensionName());
                    input = "";
                }
            }
            default -> {
            }
        }
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (inputFocused && input.length() < 32 && event.codepoint() >= 32 && event.codepoint() != 127) {
            input += event.codepointAsString();
            return true;
        }
        return super.charTyped(event);
    }
}

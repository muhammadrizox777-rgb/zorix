package uz.semvisuals.core;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getInstance();

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    private boolean enabled;
    public int key = -1;
    private boolean keyWasDown;

    public boolean keyWasDownPublic() {
        return keyWasDown;
    }

    public void setKeyWasDown(boolean value) {
        keyWasDown = value;
    }

    /** HUD elements: position in GUI-scaled pixels and last rendered size. */
    public final boolean hudElement;
    public int hudX, hudY, hudW = 60, hudH = 12;

    protected Module(String name, String description, Category category) {
        this(name, description, category, false, 0, 0);
    }

    protected Module(String name, String description, Category category, boolean hud, int x, int y) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.hudElement = hud;
        this.hudX = x;
        this.hudY = y;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        if (enabled == value) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
        if (mc.player != null) {
            Events.toast(name, value ? "Enabled" : "Disabled", value);
        }
    }

    /** Used when loading a config: no toast and no callbacks if state is unchanged. */
    public void setEnabledSilently(boolean value) {
        if (enabled != value) {
            enabled = value;
            if (value) {
                onEnable();
            } else {
                onDisable();
            }
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    /** Called every client tick while enabled and in a world. */
    public void onTick() {
    }

    /** Called when the local player attacks a living entity. */
    public void onAttack(net.minecraft.world.entity.LivingEntity target) {
    }

    /** Called when a world is joined. */
    public void onJoin() {
    }

    /** Called every frame while enabled and the HUD is visible. */
    public void renderHud(GuiGraphics graphics, DeltaTracker delta) {
    }

    protected final void size(int w, int h) {
        hudW = w;
        hudH = h;
    }
}

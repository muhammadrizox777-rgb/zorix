package uz.semvisuals.core;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** In-memory event log (Events tab) and on-screen toast queue. */
public final class Events {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    public static final List<String> LOG = new ArrayList<>();
    public static final List<Toast> TOASTS = new ArrayList<>();

    private Events() {
    }

    public static void log(String text) {
        LOG.add(LocalTime.now().format(TIME) + "  " + text);
        while (LOG.size() > 200) {
            LOG.remove(0);
        }
    }

    public static void toast(String title, String message, boolean positive) {
        TOASTS.add(new Toast(title, message, positive, System.currentTimeMillis()));
        while (TOASTS.size() > 5) {
            TOASTS.remove(0);
        }
        log(title + ": " + message);
    }

    public static void info(String title, String message) {
        toast(title, message, true);
    }

    public record Toast(String title, String message, boolean positive, long created) {
    }
}

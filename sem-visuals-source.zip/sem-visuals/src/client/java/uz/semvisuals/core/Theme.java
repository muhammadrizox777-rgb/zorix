package uz.semvisuals.core;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Shared colors and small drawing helpers. */
public final class Theme {
    public static final int BG = 0xF00D1220;
    public static final int PANEL = 0xF4101626;
    public static final int ROW = 0xFF161D30;
    public static final int ROW_HOVER = 0xFF1E2740;
    public static final int LINE = 0xFF20283A;
    public static final int TEXT = 0xFFF0F3FA;
    public static final int MUTED = 0xFF8A96AD;
    public static final int GOOD = 0xFF6FD98A;
    public static final int BAD = 0xFFE86A6A;

    private Theme() {
    }

    /** Set by the ClientColor module; null means the default accent. */
    public static java.util.function.IntSupplier accentSource = null;

    public static int accent() {
        return accentSource == null ? 0xFF9B7BFF : accentSource.getAsInt();
    }

    public static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int hsb(float h, float s, float b) {
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(h, s, b) & 0xFFFFFF);
    }

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xCC0D1220);
        g.fill(x, y, x + 2, y + h, accent());
    }

    /** Names of the bundled fonts (assets/semvisuals/font/<lowercase name>.json). */
    public static final String[] FONTS = {"Default", "Barlow", "Comfortaa", "DMSans", "FiraSans", "IBMPlexSans", "Inter", "JetBrainsMono", "JosefinSans", "Karla", "Lato", "Lexend", "Manrope", "Merriweather", "Montserrat", "NotoSans", "NotoSansMono", "NotoSerif", "Nunito", "OpenSans", "Oswald", "Outfit", "PlayfairDisplay", "Poppins", "Quicksand", "Raleway", "Roboto", "RobotoMono", "Rubik", "Sora", "SourceSans3", "SpaceGrotesk", "Urbanist", "WorkSans"};

    /** Set by the ClientColor module; null or "Default" means the vanilla font. */
    public static java.util.function.Supplier<String> fontSource = null;

    private static net.minecraft.network.chat.Component styled(String s) {
        String font = fontSource == null ? "Default" : fontSource.get();
        var text = net.minecraft.network.chat.Component.literal(s);
        if (font == null || font.equals("Default")) {
            return text;
        }
        var id = net.minecraft.resources.Identifier.fromNamespaceAndPath("semvisuals", font.toLowerCase(java.util.Locale.ROOT));
        return text.withStyle(style -> style.withFont(new net.minecraft.network.chat.FontDescription.Resource(id)));
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(Minecraft.getInstance().font, styled(s), x, y, color, true);
    }

    public static int width(String s) {
        return Minecraft.getInstance().font.width(styled(s));
    }
}

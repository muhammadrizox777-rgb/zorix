package uz.semvisuals.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Markers {
    public static final List<Marker> LIST = new ArrayList<>();

    private Markers() {
    }

    public record Marker(String name, double x, double y, double z, String dimension) {
    }

    public static void add(String name, double x, double y, double z, String dimension) {
        LIST.add(new Marker(name, x, y, z, dimension));
        save();
    }

    public static void remove(Marker marker) {
        LIST.remove(marker);
        save();
    }

    private static Path file() {
        return ModuleManager.dir().resolve("markers.txt");
    }

    public static void load() {
        LIST.clear();
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file())) {
                    String[] p = line.split("\t");
                    if (p.length == 5) {
                        LIST.add(new Marker(p[0], Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                                Double.parseDouble(p[3]), p[4]));
                    }
                }
            }
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    private static void save() {
        List<String> lines = new ArrayList<>();
        for (Marker m : LIST) {
            lines.add(m.name() + "\t" + m.x() + "\t" + m.y() + "\t" + m.z() + "\t" + m.dimension());
        }
        try {
            Files.createDirectories(file().getParent());
            Files.write(file(), lines);
        } catch (IOException ignored) {
        }
    }
}

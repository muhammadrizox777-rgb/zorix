package uz.semvisuals.core;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Stream;

public final class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static String currentConfig = "default";

    private ModuleManager() {
    }

    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("sem-visuals");
    }

    private static Path configDir() {
        return dir().resolve("configs");
    }

    public static void register(Module module) {
        MODULES.add(module);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) {
            if (m.getClass() == type) {
                return (T) m;
            }
        }
        return null;
    }

    public static boolean on(Class<? extends Module> type) {
        Module m = get(type);
        return m != null && m.isEnabled();
    }

    public static List<Module> in(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == category) {
                result.add(m);
            }
        }
        return result;
    }

    public static List<String> configNames() {
        List<String> names = new ArrayList<>();
        try {
            Files.createDirectories(configDir());
            try (Stream<Path> files = Files.list(configDir())) {
                files.map(p -> p.getFileName().toString())
                        .filter(n -> n.endsWith(".properties"))
                        .map(n -> n.substring(0, n.length() - ".properties".length()))
                        .sorted()
                        .forEach(names::add);
            }
        } catch (IOException ignored) {
        }
        return names;
    }

    public static String sanitize(String name) {
        String clean = name.trim().replaceAll("[^A-Za-z0-9_\\- ]", "");
        return clean.isEmpty() ? "config" : clean;
    }

    public static void save(String name) {
        Properties p = new Properties();
        for (Module m : MODULES) {
            String base = m.name + ".";
            p.setProperty(base + "enabled", Boolean.toString(m.isEnabled()));
            p.setProperty(base + "key", Integer.toString(m.key));
            if (m.hudElement) {
                p.setProperty(base + "hud", m.hudX + "," + m.hudY);
            }
            for (Setting<?> s : m.settings) {
                p.setProperty(base + "s." + s.name, s.serialize());
            }
        }
        try {
            Files.createDirectories(configDir());
            try (OutputStream out = Files.newOutputStream(configDir().resolve(sanitize(name) + ".properties"))) {
                p.store(out, "Sem Visuals config");
            }
        } catch (IOException ignored) {
        }
    }

    public static boolean load(String name) {
        Path file = configDir().resolve(sanitize(name) + ".properties");
        if (!Files.exists(file)) {
            return false;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException e) {
            return false;
        }
        for (Module m : MODULES) {
            String base = m.name + ".";
            for (Setting<?> s : m.settings) {
                String v = p.getProperty(base + "s." + s.name);
                if (v != null) {
                    s.deserialize(v);
                }
            }
            String key = p.getProperty(base + "key");
            if (key != null) {
                try {
                    m.key = Integer.parseInt(key);
                } catch (NumberFormatException ignored) {
                }
            }
            String hud = p.getProperty(base + "hud");
            if (hud != null && hud.contains(",")) {
                try {
                    String[] xy = hud.split(",");
                    m.hudX = Integer.parseInt(xy[0]);
                    m.hudY = Integer.parseInt(xy[1]);
                } catch (NumberFormatException ignored) {
                }
            }
            String enabled = p.getProperty(base + "enabled");
            if (enabled != null) {
                m.setEnabledSilently(Boolean.parseBoolean(enabled));
            }
        }
        currentConfig = sanitize(name);
        return true;
    }

    public static void delete(String name) {
        try {
            Files.deleteIfExists(configDir().resolve(sanitize(name) + ".properties"));
        } catch (IOException ignored) {
        }
    }
}

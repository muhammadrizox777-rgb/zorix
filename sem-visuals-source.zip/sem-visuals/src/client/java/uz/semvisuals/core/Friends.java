package uz.semvisuals.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Friends {
    private static final List<String> NAMES = new ArrayList<>();

    private Friends() {
    }

    public static List<String> all() {
        return NAMES;
    }

    public static boolean isFriend(String name) {
        return name != null && NAMES.contains(name.toLowerCase(Locale.ROOT));
    }

    public static void add(String name) {
        String key = name.trim().toLowerCase(Locale.ROOT);
        if (!key.isEmpty() && !NAMES.contains(key)) {
            NAMES.add(key);
            save();
        }
    }

    public static void remove(String name) {
        NAMES.remove(name.toLowerCase(Locale.ROOT));
        save();
    }

    private static Path file() {
        return ModuleManager.dir().resolve("friends.txt");
    }

    public static void load() {
        NAMES.clear();
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file())) {
                    if (!line.isBlank()) {
                        NAMES.add(line.trim().toLowerCase(Locale.ROOT));
                    }
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void save() {
        try {
            Files.createDirectories(file().getParent());
            Files.write(file(), NAMES);
        } catch (IOException ignored) {
        }
    }
}

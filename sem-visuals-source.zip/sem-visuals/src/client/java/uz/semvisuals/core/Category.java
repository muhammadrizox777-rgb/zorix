package uz.semvisuals.core;

public enum Category {
    VISUALS("Visuals"),
    HUD("HUD"),
    UTILITIES("Utilities");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}

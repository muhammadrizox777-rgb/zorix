package uz.semvisuals.core;

import java.util.function.BooleanSupplier;

/** A persisted module option. Subclasses define how the value is stored as text. */
public abstract class Setting<T> {
    public final String name;
    public T value;
    public BooleanSupplier visible = () -> true;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S showIf(BooleanSupplier supplier) {
        this.visible = supplier;
        return (S) this;
    }

    public abstract String serialize();

    public abstract void deserialize(String text);

    public static final class Bool extends Setting<Boolean> {
        public Bool(String name, boolean def) {
            super(name, def);
        }

        public boolean get() {
            return value;
        }

        @Override
        public String serialize() {
            return Boolean.toString(value);
        }

        @Override
        public void deserialize(String text) {
            value = Boolean.parseBoolean(text);
        }
    }

    public static final class Num extends Setting<Double> {
        public final double min, max, step;

        public Num(String name, double def, double min, double max, double step) {
            super(name, def);
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public double get() {
            return value;
        }

        public int asInt() {
            return (int) Math.round(value);
        }

        public float asFloat() {
            return value.floatValue();
        }

        public void set(double v) {
            double snapped = step > 0 ? Math.round(v / step) * step : v;
            value = Math.max(min, Math.min(max, snapped));
        }

        @Override
        public String serialize() {
            return Double.toString(value);
        }

        @Override
        public void deserialize(String text) {
            try {
                set(Double.parseDouble(text));
            } catch (NumberFormatException ignored) {
            }
        }
    }

    public static final class Mode extends Setting<Integer> {
        public final String[] modes;

        public Mode(String name, String def, String... modes) {
            super(name, 0);
            this.modes = modes;
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equalsIgnoreCase(def)) {
                    value = i;
                }
            }
        }

        public String get() {
            return modes[value];
        }

        public boolean is(String mode) {
            return modes[value].equalsIgnoreCase(mode);
        }

        public void cycle(int dir) {
            value = Math.floorMod(value + dir, modes.length);
        }

        @Override
        public String serialize() {
            return modes[value];
        }

        @Override
        public void deserialize(String text) {
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equalsIgnoreCase(text)) {
                    value = i;
                }
            }
        }
    }

    public static final class Color extends Setting<Integer> {
        public Color(String name, int argb) {
            super(name, argb);
        }

        public int get() {
            return value;
        }

        @Override
        public String serialize() {
            return Integer.toHexString(value);
        }

        @Override
        public void deserialize(String text) {
            try {
                value = (int) Long.parseLong(text, 16);
            } catch (NumberFormatException ignored) {
            }
        }
    }

    public static final class Key extends Setting<Integer> {
        public Key(String name, int key) {
            super(name, key);
        }

        public int get() {
            return value;
        }

        @Override
        public String serialize() {
            return Integer.toString(value);
        }

        @Override
        public void deserialize(String text) {
            try {
                value = Integer.parseInt(text);
            } catch (NumberFormatException ignored) {
            }
        }
    }
}

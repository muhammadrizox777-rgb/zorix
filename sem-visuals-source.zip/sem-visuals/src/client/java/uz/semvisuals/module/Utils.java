package uz.semvisuals.module;

import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import uz.semvisuals.core.Category;
import uz.semvisuals.core.Events;
import uz.semvisuals.core.Markers;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Setting;
import uz.semvisuals.core.Util;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Quality-of-life utilities. None of them send anything the vanilla client would not send. */
public final class Utils {
    private Utils() {
    }

    public static void registerAll() {
        ModuleManager.register(new Sprint());
        ModuleManager.register(new AutoRespawn());
        ModuleManager.register(new AutoReconnect());
        ModuleManager.register(new ArmorNotifier());
        ModuleManager.register(new DeathMarker());
        ModuleManager.register(new ChatHelper());
        ModuleManager.register(new CommandSafe());
        ModuleManager.register(new ItemPickupLogger());
        ModuleManager.register(new AutoEat());
        ModuleManager.register(new StreamerMode());
    }

    public static final class Sprint extends Module {
        public Sprint() {
            super("Sprint", "Keeps you sprinting while you walk forward", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player != null && mc.screen == null && mc.options.keyUp.isDown() && !mc.options.keyShift.isDown()) {
                mc.options.keySprint.setDown(true);
            }
        }
    }

    public static final class AutoRespawn extends Module {
        private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 0, 100, 1));
        private int waited;

        public AutoRespawn() {
            super("AutoRespawn", "Respawns automatically after dying", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player != null && mc.screen instanceof DeathScreen) {
                if (++waited >= delay.asInt()) {
                    mc.player.respawn();
                    waited = 0;
                }
            } else {
                waited = 0;
            }
        }
    }

    public static final class AutoReconnect extends Module {
        private final Setting.Num delay = add(new Setting.Num("Delay (s)", 5, 1, 60, 1));
        private final Setting.Num attempts = add(new Setting.Num("Max attempts", 5, 1, 30, 1));
        private ServerData lastServer;
        private int countdown = -1;
        private int tries;

        public AutoReconnect() {
            super("AutoReconnect", "Reconnects after being disconnected", Category.UTILITIES);
        }

        @Override
        public void onJoin() {
            tries = 0;
            countdown = -1;
        }

        /** Runs every tick, also when no world is loaded. */
        public void tickAlways() {
            if (mc.getCurrentServer() != null) {
                lastServer = mc.getCurrentServer();
            }
            if (!(mc.screen instanceof DisconnectedScreen) || lastServer == null || tries >= attempts.asInt()) {
                countdown = -1;
                return;
            }
            if (countdown < 0) {
                countdown = delay.asInt() * 20;
            }
            if (--countdown == 0) {
                tries++;
                Events.info("AutoReconnect", "Attempt " + tries + " of " + attempts.asInt());
                ConnectScreen.startConnecting(new JoinMultiplayerScreen(new TitleScreen()), mc,
                        ServerAddress.parseString(lastServer.ip), lastServer, false, null);
            }
        }
    }

    public static final class ArmorNotifier extends Module {
        private final Setting.Num threshold = add(new Setting.Num("Warn below %", 15, 5, 50, 1));
        private final boolean[] warned = new boolean[4];

        public ArmorNotifier() {
            super("ArmorNotifier", "Warns when armor durability is low", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.player.tickCount % 10 != 0) {
                return;
            }
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getItemBySlot(slots[i]);
                if (s.isEmpty() || !s.isDamageableItem()) {
                    warned[i] = false;
                    continue;
                }
                int pct = 100 - s.getDamageValue() * 100 / Math.max(1, s.getMaxDamage());
                if (pct < threshold.asInt() && !warned[i]) {
                    warned[i] = true;
                    Events.toast("Armor low", s.getHoverName().getString() + " " + pct + "%", false);
                } else if (pct >= threshold.asInt() + 5) {
                    warned[i] = false;
                }
            }
        }
    }

    public static final class DeathMarker extends Module {
        private boolean wasDead;

        public DeathMarker() {
            super("DeathMarker", "Saves a marker where you died", Category.UTILITIES);
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            boolean dead = mc.player.isDeadOrDying();
            if (dead && !wasDead) {
                Markers.LIST.removeIf(m -> m.name().equals("Death"));
                Markers.add("Death", mc.player.getX(), mc.player.getY(), mc.player.getZ(), Util.dimensionName());
                Events.toast("Death marker", String.format("%.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()), false);
            }
            wasDead = dead;
        }
    }

    public static final class ChatHelper extends Module {
        private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
        private final Setting.Bool timestamps = add(new Setting.Bool("Timestamps", true));

        public ChatHelper() {
            super("ChatHelper", "Adds timestamps to chat messages", Category.UTILITIES);
        }

        public Component modify(Component message) {
            if (!timestamps.get()) {
                return message;
            }
            return Component.literal("[" + LocalTime.now().format(TIME) + "] ")
                    .withStyle(net.minecraft.ChatFormatting.GRAY).append(message);
        }
    }

    public static final class CommandSafe extends Module {
        private static final List<String> RISKY = List.of("op", "deop", "stop", "ban", "ban-ip", "pardon", "kill",
                "clear", "reload", "whitelist", "execute", "setblock", "fill", "gamerule");

        public CommandSafe() {
            super("CommandSafe", "Blocks risky commands you might type by mistake", Category.UTILITIES);
        }

        public boolean allows(String command) {
            String first = command.trim().split(" ")[0].toLowerCase(Locale.ROOT);
            if (RISKY.contains(first)) {
                Events.toast("CommandSafe", "Blocked /" + first + " (disable the module to allow)", false);
                return false;
            }
            return true;
        }
    }

    public static final class ItemPickupLogger extends Module {
        private final Setting.Bool toast = add(new Setting.Bool("Show toast", false));
        private final Map<Item, Integer> last = new HashMap<>();
        private boolean primed;

        public ItemPickupLogger() {
            super("ItemPickupLogger", "Logs picked up items in the Events tab", Category.UTILITIES);
        }

        @Override
        public void onEnable() {
            primed = false;
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.player.tickCount % 5 != 0) {
                return;
            }
            Map<Item, Integer> now = new HashMap<>();
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (!s.isEmpty()) {
                    now.merge(s.getItem(), s.getCount(), Integer::sum);
                }
            }
            if (primed && mc.screen == null) {
                for (Map.Entry<Item, Integer> e : now.entrySet()) {
                    int gained = e.getValue() - last.getOrDefault(e.getKey(), 0);
                    if (gained > 0) {
                        String text = "+" + gained + " " + new ItemStack(e.getKey()).getHoverName().getString();
                        if (toast.get()) {
                            Events.toast("Picked up", text, true);
                        } else {
                            Events.log("Picked up " + text);
                        }
                    }
                }
            }
            last.clear();
            last.putAll(now);
            primed = true;
        }
    }

    public static final class AutoEat extends Module {
        private final Setting.Num hunger = add(new Setting.Num("Eat at food level", 14, 2, 19, 1));
        private boolean eating;

        public AutoEat() {
            super("AutoEat", "Eats food from your hand when you are hungry", Category.UTILITIES);
        }

        private boolean holdingFood() {
            return mc.player.getMainHandItem().has(DataComponents.FOOD) || mc.player.getOffhandItem().has(DataComponents.FOOD);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.screen != null) {
                return;
            }
            boolean need = mc.player.getFoodData().getFoodLevel() <= hunger.asInt() && holdingFood();
            if (need) {
                eating = true;
                mc.options.keyUse.setDown(true);
            } else if (eating) {
                if (!mc.player.isUsingItem()) {
                    eating = false;
                    mc.options.keyUse.setDown(false);
                }
            }
        }

        @Override
        public void onDisable() {
            if (eating) {
                mc.options.keyUse.setDown(false);
                eating = false;
            }
        }
    }

    public static final class StreamerMode extends Module {
        public StreamerMode() {
            super("StreamerMode", "Hides your name, coordinates and server address on the HUD", Category.UTILITIES);
        }
    }
}

package uz.semvisuals.module;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import uz.semvisuals.core.Category;
import uz.semvisuals.core.Events;
import uz.semvisuals.core.Markers;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Setting;
import uz.semvisuals.core.Theme;
import uz.semvisuals.core.Util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** HUD modules. Positions are editable in the HUD editor. */
public final class Hud {
    private Hud() {
    }

    public static void registerAll() {
        ModuleManager.register(new ClientColor());
        ModuleManager.register(new Watermark());
        ModuleManager.register(new Notifications());
        ModuleManager.register(new ArmorHud());
        ModuleManager.register(new PotionsHud());
        ModuleManager.register(new SaturationHud());
        ModuleManager.register(new TotemsHud());
        ModuleManager.register(new CooldownsHud());
        ModuleManager.register(new InventoryHud());
        ModuleManager.register(new HotkeysHud());
        ModuleManager.register(new TargetHud());
        ModuleManager.register(new Coordinates());
        ModuleManager.register(new TntTimer());
        ModuleManager.register(new MarkerOverlay());
        ModuleManager.register(new EffectNotify());
    }

    private static boolean streamer() {
        return ModuleManager.on(Utils.StreamerMode.class);
    }

    public static final class ClientColor extends Module {
        private final Setting.Mode mode = add(new Setting.Mode("Mode", "Static", "Static", "Pulse", "Rainbow"));
        private final Setting.Color color = add(new Setting.Color("Color", 0xFF9B7BFF));
        private final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.2, 4.0, 0.1));
        private final Setting.Mode font = add(new Setting.Mode("Interface font", "Default", Theme.FONTS));

        public ClientColor() {
            super("ClientColor", "Accent color and interface font used by the menu and HUD", Category.HUD);
            setEnabledSilently(true);
        }

        @Override
        public void onEnable() {
            Theme.accentSource = this::current;
            Theme.fontSource = font::get;
        }

        @Override
        public void onDisable() {
            Theme.accentSource = null;
            Theme.fontSource = null;
        }

        private int current() {
            double t = System.currentTimeMillis() / 1000.0 * speed.get();
            return switch (mode.get()) {
                case "Pulse" -> Theme.mix(color.get(), 0xFFFFFFFF, (float) ((Math.sin(t * 2) + 1) * 0.2));
                case "Rainbow" -> Theme.hsb((float) (t * 0.15 % 1.0), 0.55f, 1.0f);
                default -> color.get() | 0xFF000000;
            };
        }
    }

    public static final class Watermark extends Module {
        private final Setting.Bool fps = add(new Setting.Bool("FPS", true));
        private final Setting.Bool ping = add(new Setting.Bool("Ping", true));
        private final Setting.Bool name = add(new Setting.Bool("Name", true));
        private final Setting.Bool server = add(new Setting.Bool("Server", false));

        public Watermark() {
            super("Watermark", "Client name, FPS and ping", Category.HUD, true, 6, 6);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            StringBuilder sb = new StringBuilder("Sem Visuals");
            if (name.get() && mc.player != null && !streamer()) {
                sb.append("  |  ").append(mc.player.getName().getString());
            }
            if (fps.get()) {
                sb.append("  |  ").append(mc.getFps()).append(" fps");
            }
            if (ping.get() && mc.player != null && mc.getConnection() != null) {
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) {
                    sb.append("  |  ").append(info.getLatency()).append(" ms");
                }
            }
            if (server.get() && !streamer() && mc.getCurrentServer() != null) {
                sb.append("  |  ").append(mc.getCurrentServer().ip);
            }
            String text = sb.toString();
            int w = Theme.width(text) + 12;
            size(w, 16);
            Theme.panel(g, hudX, hudY, w, 16);
            Theme.text(g, text, hudX + 7, hudY + 4, Theme.TEXT);
        }
    }

    public static final class Notifications extends Module {
        private final Setting.Num seconds = add(new Setting.Num("Duration (s)", 3, 1, 10, 1));

        public Notifications() {
            super("Notifications", "Toasts for module toggles and alerts", Category.HUD, true, 6, 200);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            size(150, 34);
            long now = System.currentTimeMillis();
            long life = (long) (seconds.get() * 1000);
            Events.TOASTS.removeIf(t -> now - t.created() > life);
            int y = hudY;
            for (int i = Events.TOASTS.size() - 1; i >= 0; i--) {
                Events.Toast t = Events.TOASTS.get(i);
                long age = now - t.created();
                float slide = age < 220 ? 1f - age / 220f : (life - age < 220 ? 1f - (life - age) / 220f : 0f);
                int x = hudX - (int) (slide * 170);
                int w = Math.max(Theme.width(t.title()), Theme.width(t.message())) + 16;
                g.fill(x, y, x + w, y + 26, 0xCC0D1220);
                g.fill(x, y, x + 2, y + 26, t.positive() ? Theme.GOOD : Theme.BAD);
                Theme.text(g, t.title(), x + 8, y + 4, Theme.TEXT);
                Theme.text(g, t.message(), x + 8, y + 14, Theme.MUTED);
                y += 30;
            }
        }
    }

    public static final class ArmorHud extends Module {
        private final Setting.Mode layout = add(new Setting.Mode("Layout", "Horizontal", "Horizontal", "Vertical"));
        private final Setting.Bool percent = add(new Setting.Bool("Durability %", true));

        public ArmorHud() {
            super("ArmorHud", "Armor pieces with durability", Category.HUD, true, 6, 120);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            boolean horizontal = layout.is("Horizontal");
            int cell = percent.get() ? 30 : 20;
            size(horizontal ? cell * 4 + 4 : 56, horizontal ? 36 : 20 * 4 + 4);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            for (int i = 0; i < 4; i++) {
                ItemStack stack = mc.player.getItemBySlot(slots[i]);
                int x = horizontal ? hudX + 6 + i * cell : hudX + 6;
                int y = horizontal ? hudY + 3 : hudY + 2 + i * 20;
                if (stack.isEmpty()) {
                    continue;
                }
                g.renderItem(stack, x, y);
                g.renderItemDecorations(mc.font, stack, x, y);
                if (percent.get() && stack.isDamageableItem()) {
                    int pct = 100 - stack.getDamageValue() * 100 / Math.max(1, stack.getMaxDamage());
                    String s = pct + "%";
                    int c = Theme.mix(Theme.BAD, Theme.GOOD, pct / 100f);
                    if (horizontal) {
                        Theme.text(g, s, x + 8 - Theme.width(s) / 2, y + 19, c);
                    } else {
                        Theme.text(g, s, x + 20, y + 4, c);
                    }
                }
            }
        }
    }

    public static final class PotionsHud extends Module {
        public PotionsHud() {
            super("PotionsHud", "Active potion effects with timers", Category.HUD, true, 6, 170);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            List<String> lines = new ArrayList<>();
            List<Integer> colors = new ArrayList<>();
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                String n = e.getEffect().value().getDisplayName().getString() + " " + (e.getAmplifier() + 1);
                String t = e.isInfiniteDuration() ? "inf" : Util.formatTicks(e.getDuration());
                lines.add(n + "  " + t);
                colors.add(e.getDuration() < 200 && !e.isInfiniteDuration() ? Theme.BAD : Theme.TEXT);
            }
            if (lines.isEmpty()) {
                lines.add("No effects");
                colors.add(Theme.MUTED);
            }
            int w = 70;
            for (String l : lines) {
                w = Math.max(w, Theme.width(l) + 14);
            }
            size(w, lines.size() * 11 + 6);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            for (int i = 0; i < lines.size(); i++) {
                Theme.text(g, lines.get(i), hudX + 7, hudY + 4 + i * 11, colors.get(i));
            }
        }
    }

    public static final class SaturationHud extends Module {
        public SaturationHud() {
            super("SaturationHud", "Hunger and saturation values", Category.HUD, true, 6, 100);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            var food = mc.player.getFoodData();
            size(110, 28);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, "Food " + food.getFoodLevel() + "/20", hudX + 7, hudY + 3, Theme.TEXT);
            Theme.text(g, String.format("Saturation %.1f", food.getSaturationLevel()), hudX + 7, hudY + 14, Theme.MUTED);
            int bar = (int) ((hudW - 8) * Math.min(1f, food.getSaturationLevel() / 20f));
            g.fill(hudX + 4, hudY + hudH - 3, hudX + hudW - 4, hudY + hudH - 1, 0xFF20283A);
            g.fill(hudX + 4, hudY + hudH - 3, hudX + 4 + bar, hudY + hudH - 1, Theme.accent());
        }
    }

    public static final class TotemsHud extends Module {
        public TotemsHud() {
            super("TotemsHud", "Totems of Undying in your inventory", Category.HUD, true, 6, 70);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            int count = 0;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.is(Items.TOTEM_OF_UNDYING)) {
                    count += s.getCount();
                }
            }
            size(48, 24);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            g.renderItem(new ItemStack(Items.TOTEM_OF_UNDYING), hudX + 6, hudY + 4);
            Theme.text(g, "x" + count, hudX + 26, hudY + 8, count == 0 ? Theme.BAD : Theme.TEXT);
        }
    }

    public static final class CooldownsHud extends Module {
        private static final Item[] TRACKED = {Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE,
                Items.CHORUS_FRUIT, Items.SHIELD, Items.WIND_CHARGE, Items.TRIDENT, Items.MACE};

        public CooldownsHud() {
            super("CooldownsHud", "Item cooldowns (pearl, apples, shield...)", Category.HUD, true, 6, 40);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            List<ItemStack> active = new ArrayList<>();
            for (Item item : TRACKED) {
                ItemStack s = new ItemStack(item);
                if (mc.player.getCooldowns().isOnCooldown(s)) {
                    active.add(s);
                }
            }
            size(70, Math.max(1, active.size()) * 18 + 4);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            if (active.isEmpty()) {
                Theme.text(g, "Ready", hudX + 7, hudY + 6, Theme.MUTED);
                return;
            }
            for (int i = 0; i < active.size(); i++) {
                ItemStack s = active.get(i);
                int y = hudY + 2 + i * 18;
                g.renderItem(s, hudX + 5, y);
                float left = mc.player.getCooldowns().getCooldownPercent(s, 0f);
                g.fill(hudX + 26, y + 6, hudX + 66, y + 10, 0xFF20283A);
                g.fill(hudX + 26, y + 6, hudX + 26 + (int) (40 * (1f - left)), y + 10, Theme.accent());
            }
        }
    }

    public static final class InventoryHud extends Module {
        public InventoryHud() {
            super("InventoryHud", "Your inventory on screen", Category.HUD, true, 200, 6);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            size(9 * 18 + 8, 3 * 18 + 8);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            var inv = mc.player.getInventory();
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 9; col++) {
                    ItemStack s = inv.getItem(9 + row * 9 + col);
                    int x = hudX + 5 + col * 18, y = hudY + 4 + row * 18;
                    g.fill(x, y, x + 17, y + 17, 0x55000000);
                    if (!s.isEmpty()) {
                        g.renderItem(s, x + 1, y + 1);
                        g.renderItemDecorations(mc.font, s, x + 1, y + 1);
                    }
                }
            }
        }
    }

    public static final class HotkeysHud extends Module {
        public HotkeysHud() {
            super("HotkeysHud", "Modules that have a key bound", Category.HUD, true, 6, 230);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            List<Module> bound = new ArrayList<>();
            for (Module m : ModuleManager.MODULES) {
                if (m.key >= 0) {
                    bound.add(m);
                }
            }
            int w = 90;
            for (Module m : bound) {
                w = Math.max(w, Theme.width(m.name + "  [" + Util.keyName(m.key) + "]") + 14);
            }
            size(w, Math.max(1, bound.size()) * 11 + 6);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            if (bound.isEmpty()) {
                Theme.text(g, "No keybinds", hudX + 7, hudY + 4, Theme.MUTED);
            }
            for (int i = 0; i < bound.size(); i++) {
                Module m = bound.get(i);
                Theme.text(g, m.name + "  [" + Util.keyName(m.key) + "]", hudX + 7, hudY + 4 + i * 11,
                        m.isEnabled() ? Theme.GOOD : Theme.MUTED);
            }
        }
    }

    public static final class TargetHud extends Module {
        public TargetHud() {
            super("TargetHud", "Health of the entity you are fighting", Category.HUD, true, 300, 160);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            LivingEntity t = Util.target();
            size(130, 36);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            if (t == null || mc.player == null) {
                Theme.text(g, "No target", hudX + 7, hudY + 13, Theme.MUTED);
                return;
            }
            float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
            Theme.text(g, t.getName().getString(), hudX + 7, hudY + 4, Theme.TEXT);
            String info = String.format("%.1f hp  %dm  armor %d", hp, (int) t.distanceTo(mc.player), t.getArmorValue());
            Theme.text(g, info, hudX + 7, hudY + 15, Theme.MUTED);
            g.fill(hudX + 7, hudY + 28, hudX + hudW - 7, hudY + 31, 0xFF20283A);
            g.fill(hudX + 7, hudY + 28, hudX + 7 + (int) ((hudW - 14) * Math.min(1f, hp / max)), hudY + 31,
                    Theme.mix(Theme.BAD, Theme.GOOD, Math.min(1f, hp / max)));
        }
    }

    public static final class Coordinates extends Module {
        public Coordinates() {
            super("Coordinates", "XYZ, facing and dimension", Category.HUD, true, 6, 270);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            String dim = Util.dimensionName().replace("minecraft:", "");
            String xyz = streamer() ? "XYZ hidden" : String.format("XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            String facing = mc.player.getDirection().getName() + "  |  " + dim;
            size(Math.max(Theme.width(xyz), Theme.width(facing)) + 14, 28);
            Theme.panel(g, hudX, hudY, hudW, hudH);
            Theme.text(g, xyz, hudX + 7, hudY + 3, Theme.TEXT);
            Theme.text(g, facing, hudX + 7, hudY + 15, Theme.MUTED);
        }
    }

    public static final class TntTimer extends Module {
        public TntTimer() {
            super("TntTimer", "Countdown above lit TNT", Category.HUD);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.level == null) {
                return;
            }
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof PrimedTnt tnt && tnt.distanceTo(mc.player) < 48) {
                    double[] p = Util.project(tnt.position().add(0, 1.2, 0));
                    if (p[2] <= 0.05) {
                        continue;
                    }
                    String s = String.format("%.1fs", tnt.getFuse() / 20.0);
                    int x = (int) p[0] - Theme.width(s) / 2, y = (int) p[1];
                    g.fill(x - 3, y - 2, x + Theme.width(s) + 3, y + 10, 0x99000000);
                    Theme.text(g, s, x, y, tnt.getFuse() < 20 ? Theme.BAD : Theme.TEXT);
                }
            }
        }
    }

    public static final class MarkerOverlay extends Module {
        private final Setting.Bool showDistance = add(new Setting.Bool("Show distance", true));

        public MarkerOverlay() {
            super("MarkerOverlay", "Shows your saved markers in the world", Category.HUD);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null) {
                return;
            }
            int w = mc.getWindow().getGuiScaledWidth();
            int h = mc.getWindow().getGuiScaledHeight();
            String dim = Util.dimensionName();
            for (Markers.Marker m : Markers.LIST) {
                if (!m.dimension().equals(dim)) {
                    continue;
                }
                var pos = new net.minecraft.world.phys.Vec3(m.x(), m.y() + 0.5, m.z());
                double[] p = Util.project(pos);
                double dist = pos.distanceTo(mc.player.position());
                String s = m.name() + (showDistance.get() ? "  " + (int) dist + "m" : "");
                int x = (int) Math.max(8, Math.min(w - Theme.width(s) - 8, p[0] - Theme.width(s) / 2.0));
                int y = (int) Math.max(8, Math.min(h - 20, p[1]));
                if (p[2] <= 0.05) {
                    y = h - 20;
                }
                g.fill(x - 3, y - 2, x + Theme.width(s) + 3, y + 10, 0x99000000);
                g.fill(x - 3, y + 10, x + Theme.width(s) + 3, y + 11, Theme.accent());
                Theme.text(g, s, x, y, Theme.TEXT);
            }
        }
    }

    public static final class EffectNotify extends Module {
        private final Set<String> known = new HashSet<>();

        public EffectNotify() {
            super("EffectNotify", "Toast when a potion effect starts or ends", Category.HUD);
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            Set<String> now = new HashSet<>();
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                now.add(e.getEffect().value().getDisplayName().getString());
            }
            for (String s : now) {
                if (!known.contains(s)) {
                    Events.toast("Effect gained", s, true);
                }
            }
            for (String s : known) {
                if (!now.contains(s)) {
                    Events.toast("Effect ended", s, false);
                }
            }
            known.clear();
            known.addAll(now);
        }
    }
}

package uz.semvisuals.module;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;
import uz.semvisuals.core.Category;
import uz.semvisuals.core.Friends;
import uz.semvisuals.core.Module;
import uz.semvisuals.core.ModuleManager;
import uz.semvisuals.core.Setting;
import uz.semvisuals.core.Theme;
import uz.semvisuals.core.Util;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/** Visual modules. Everything here is client-side rendering or particles; nothing is sent to the server. */
public final class Visuals {
    private static final Random RANDOM = new Random();

    private Visuals() {
    }

    public static void registerAll() {
        ModuleManager.register(new FullBright());
        ModuleManager.register(new Zoom());
        ModuleManager.register(new Crosshair());
        ModuleManager.register(new TargetEsp());
        ModuleManager.register(new ArrowNametag());
        ModuleManager.register(new Trails());
        ModuleManager.register(new JumpCircles());
        ModuleManager.register(new KillEffect());
        ModuleManager.register(new Halo());
        ModuleManager.register(new ChinaHat());
        ModuleManager.register(new HitBubble());
        ModuleManager.register(new HitSounds());
        ModuleManager.register(new Particles());
        ModuleManager.register(new WorldParticles());
        ModuleManager.register(new WorldCustomizer());
    }

    private static ParticleOptions particle(String mode) {
        return switch (mode) {
            case "Flame" -> ParticleTypes.FLAME;
            case "Soul" -> ParticleTypes.SOUL_FIRE_FLAME;
            case "Hearts" -> ParticleTypes.HEART;
            case "Magic" -> ParticleTypes.ENCHANT;
            case "Cloud" -> ParticleTypes.CLOUD;
            case "Crit" -> ParticleTypes.CRIT;
            case "Snow" -> ParticleTypes.SNOWFLAKE;
            case "Ash" -> ParticleTypes.WHITE_ASH;
            default -> ParticleTypes.END_ROD;
        };
    }

    private static final String[] PARTICLES = {"Glow", "Flame", "Soul", "Hearts", "Magic", "Cloud", "Crit"};

    public static final class FullBright extends Module {
        public FullBright() {
            super("FullBright", "Makes dark areas fully visible", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null) {
                return;
            }
            MobEffectInstance current = mc.player.getEffect(MobEffects.NIGHT_VISION);
            if (current == null || current.getDuration() < 400) {
                mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false));
            }
        }

        @Override
        public void onDisable() {
            if (mc.player != null) {
                mc.player.removeEffect(MobEffects.NIGHT_VISION);
            }
        }
    }

    public static final class Zoom extends Module {
        private final Setting.Num fov = add(new Setting.Num("Zoom FOV", 30, 30, 90, 1));
        private final Setting.Key hold = add(new Setting.Key("Hold key", GLFW.GLFW_KEY_C));
        private boolean zooming;
        private int previous;

        public Zoom() {
            super("Zoom", "Hold a key to zoom in", Category.VISUALS);
        }

        @Override
        public void onTick() {
            boolean down = mc.screen == null && hold.get() > 0 && InputConstants.isKeyDown(mc.getWindow(), hold.get());
            if (down && !zooming) {
                previous = mc.options.fov().get();
                zooming = true;
            }
            if (down) {
                mc.options.fov().set(fov.asInt());
            } else if (zooming) {
                mc.options.fov().set(previous);
                zooming = false;
            }
        }

        @Override
        public void onDisable() {
            if (zooming) {
                mc.options.fov().set(previous);
                zooming = false;
            }
        }
    }

    public static final class Crosshair extends Module {
        private final Setting.Mode style = add(new Setting.Mode("Style", "Cross", "Cross", "Dot", "Square", "Plus"));
        private final Setting.Num size = add(new Setting.Num("Size", 5, 1, 16, 1));
        private final Setting.Num gap = add(new Setting.Num("Gap", 2, 0, 10, 1));
        private final Setting.Num thickness = add(new Setting.Num("Thickness", 1, 1, 4, 1));
        private final Setting.Color color = add(new Setting.Color("Color", 0xFFFFFFFF));
        private final Setting.Bool dynamic = add(new Setting.Bool("Dynamic gap", true));
        private final Setting.Bool outline = add(new Setting.Bool("Outline", true));

        public Crosshair() {
            super("Crosshair", "Replaces the vanilla crosshair", Category.VISUALS);
        }

        /** Called from the replaced vanilla crosshair HUD element. */
        public void draw(GuiGraphics g) {
            int cx = mc.getWindow().getGuiScaledWidth() / 2;
            int cy = mc.getWindow().getGuiScaledHeight() / 2;
            int t = thickness.asInt();
            int s = size.asInt();
            int gp = gap.asInt();
            if (dynamic.get() && mc.player != null) {
                double speed = mc.player.getDeltaMovement().horizontalDistance();
                gp += (int) Math.min(6, speed * 18);
            }
            int c = color.get();
            switch (style.get()) {
                case "Dot" -> rect(g, cx - t, cy - t, cx + t, cy + t, c);
                case "Square" -> {
                    int r = s + gp;
                    rect(g, cx - r, cy - r, cx + r, cy - r + t, c);
                    rect(g, cx - r, cy + r - t, cx + r, cy + r, c);
                    rect(g, cx - r, cy - r, cx - r + t, cy + r, c);
                    rect(g, cx + r - t, cy - r, cx + r, cy + r, c);
                }
                case "Plus" -> {
                    rect(g, cx - s, cy - t / 2, cx + s + 1, cy - t / 2 + t, c);
                    rect(g, cx - t / 2, cy - s, cx - t / 2 + t, cy + s + 1, c);
                }
                default -> {
                    rect(g, cx - gp - s, cy - t / 2, cx - gp, cy - t / 2 + t, c);
                    rect(g, cx + gp, cy - t / 2, cx + gp + s, cy - t / 2 + t, c);
                    rect(g, cx - t / 2, cy - gp - s, cx - t / 2 + t, cy - gp, c);
                    rect(g, cx - t / 2, cy + gp, cx - t / 2 + t, cy + gp + s, c);
                }
            }
        }

        private void rect(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
            if (outline.get()) {
                g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xAA000000);
            }
            g.fill(x1, y1, x2, y2, c);
        }
    }

    public static final class TargetEsp extends Module {
        private final Setting.Mode shape = add(new Setting.Mode("Shape", "Ring", "Ring", "Diamond", "Brackets"));
        private final Setting.Num radius = add(new Setting.Num("Size", 16, 6, 40, 1));
        private final Setting.Bool tint = add(new Setting.Bool("Health tint", true));

        public TargetEsp() {
            super("TargetEsp", "Marker around the entity you are targeting", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            LivingEntity target = Util.target();
            if (target == null || mc.player == null) {
                return;
            }
            double[] p = Util.project(target.position().add(0, target.getBbHeight() / 2.0, 0));
            if (p[2] <= 0.05) {
                return;
            }
            int x = (int) p[0], y = (int) p[1];
            int r = Math.max(6, (int) (radius.get() * Math.min(2.0, 6.0 / Math.max(3.0, p[2]) + 0.4)));
            int c = Theme.accent();
            if (tint.get()) {
                float ratio = Math.max(0f, Math.min(1f, target.getHealth() / Math.max(1f, target.getMaxHealth())));
                c = Theme.mix(0xFFE86A6A, 0xFF6FD98A, ratio);
            }
            double spin = System.currentTimeMillis() / 600.0;
            switch (shape.get()) {
                case "Diamond" -> {
                    for (int i = 0; i < r; i++) {
                        g.fill(x - i, y - r + i, x - i + 2, y - r + i + 2, c);
                        g.fill(x + i - 1, y - r + i, x + i + 1, y - r + i + 2, c);
                        g.fill(x - i, y + r - i - 1, x - i + 2, y + r - i + 1, c);
                        g.fill(x + i - 1, y + r - i - 1, x + i + 1, y + r - i + 1, c);
                    }
                }
                case "Brackets" -> {
                    int l = Math.max(3, r / 2);
                    g.fill(x - r, y - r, x - r + l, y - r + 1, c);
                    g.fill(x - r, y - r, x - r + 1, y - r + l, c);
                    g.fill(x + r - l, y - r, x + r, y - r + 1, c);
                    g.fill(x + r - 1, y - r, x + r, y - r + l, c);
                    g.fill(x - r, y + r - 1, x - r + l, y + r, c);
                    g.fill(x - r, y + r - l, x - r + 1, y + r, c);
                    g.fill(x + r - l, y + r - 1, x + r, y + r, c);
                    g.fill(x + r - 1, y + r - l, x + r, y + r, c);
                }
                default -> {
                    for (int i = 0; i < 16; i++) {
                        double a = spin + i * Math.PI / 8.0;
                        int dx = (int) Math.round(Math.cos(a) * r);
                        int dy = (int) Math.round(Math.sin(a) * r);
                        int alpha = 90 + (i * 165 / 16);
                        g.fill(x + dx - 1, y + dy - 1, x + dx + 1, y + dy + 1, Theme.withAlpha(c, alpha));
                    }
                }
            }
        }
    }

    public static final class ArrowNametag extends Module {
        private final Setting.Num range = add(new Setting.Num("Range", 64, 8, 128, 1));
        private final Setting.Bool health = add(new Setting.Bool("Show health", true));
        private final Setting.Bool distance = add(new Setting.Bool("Show distance", true));
        private final Setting.Bool edge = add(new Setting.Bool("Off-screen arrows", true));
        private final Setting.Bool friends = add(new Setting.Bool("Highlight friends", true));

        public ArrowNametag() {
            super("ArrowNametag", "Name, health and edge arrows for nearby players", Category.VISUALS);
        }

        @Override
        public void renderHud(GuiGraphics g, DeltaTracker delta) {
            if (mc.player == null || mc.level == null) {
                return;
            }
            int w = mc.getWindow().getGuiScaledWidth();
            int h = mc.getWindow().getGuiScaledHeight();
            for (Player other : mc.level.players()) {
                if (other == mc.player || other.isSpectator()) {
                    continue;
                }
                double dist = other.distanceTo(mc.player);
                if (dist > range.get()) {
                    continue;
                }
                boolean friend = friends.get() && Friends.isFriend(other.getName().getString());
                int color = friend ? Theme.GOOD : 0xFFFFFFFF;
                StringBuilder label = new StringBuilder(other.getName().getString());
                if (health.get()) {
                    label.append("  ").append(Math.round(other.getHealth() + other.getAbsorptionAmount()));
                }
                if (distance.get()) {
                    label.append("  ").append((int) dist).append("m");
                }
                double[] p = Util.project(other.position().add(0, other.getBbHeight() + 0.45, 0));
                String text = label.toString();
                int tw = Theme.width(text);
                boolean onScreen = p[2] > 0.05 && p[0] > 0 && p[0] < w && p[1] > 0 && p[1] < h;
                if (onScreen) {
                    int x = (int) p[0] - tw / 2, y = (int) p[1] - 10;
                    g.fill(x - 3, y - 2, x + tw + 3, y + 10, 0x99000000);
                    g.fill(x - 3, y + 10, x + tw + 3, y + 11, friend ? Theme.GOOD : Theme.accent());
                    Theme.text(g, text, x, y, color);
                } else if (edge.get()) {
                    double angle = Math.atan2(-p[4], p[3]);
                    if (p[2] < 0) {
                        angle = Math.atan2(p[4], -p[3]);
                    }
                    double rad = Math.min(w, h) / 2.0 - 24;
                    int ex = (int) (w / 2.0 + Math.cos(angle) * rad);
                    int ey = (int) (h / 2.0 + Math.sin(angle) * rad);
                    for (int i = 0; i < 6; i++) {
                        int bx = (int) (ex - Math.cos(angle) * i * 1.5);
                        int by = (int) (ey - Math.sin(angle) * i * 1.5);
                        int half = 5 - i;
                        g.fill(bx - half / 2 - 1, by - half / 2 - 1, bx + half / 2 + 1, by + half / 2 + 1,
                                friend ? Theme.GOOD : Theme.accent());
                    }
                    Theme.text(g, other.getName().getString(), ex - Theme.width(other.getName().getString()) / 2,
                            ey + 8, color);
                }
            }
        }
    }

    public static final class Trails extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Glow", PARTICLES));
        private final Setting.Num amount = add(new Setting.Num("Amount", 2, 1, 8, 1));
        private final Setting.Bool thirdPersonOnly = add(new Setting.Bool("Third person only", false));

        public Trails() {
            super("Trails", "Leaves a particle trail behind you", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null) {
                return;
            }
            if (thirdPersonOnly.get() && mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            if (mc.player.getDeltaMovement().horizontalDistanceSqr() < 0.0004) {
                return;
            }
            ParticleOptions p = particle(type.get());
            for (int i = 0; i < amount.asInt(); i++) {
                mc.level.addParticle(p, mc.player.getX() + (RANDOM.nextDouble() - 0.5) * 0.4,
                        mc.player.getY() + 0.1 + RANDOM.nextDouble() * 0.3,
                        mc.player.getZ() + (RANDOM.nextDouble() - 0.5) * 0.4, 0, 0.01, 0);
            }
        }
    }

    public static final class JumpCircles extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Glow", PARTICLES));
        private final Setting.Num points = add(new Setting.Num("Points", 24, 8, 48, 1));
        private boolean wasOnGround = true;

        public JumpCircles() {
            super("JumpCircles", "A ring of particles when you jump", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null) {
                return;
            }
            boolean ground = mc.player.onGround();
            if (wasOnGround && !ground && mc.player.getDeltaMovement().y > 0.2) {
                ParticleOptions p = particle(type.get());
                int n = points.asInt();
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n;
                    mc.level.addParticle(p, mc.player.getX(), mc.player.getY() + 0.05, mc.player.getZ(),
                            Math.cos(a) * 0.12, 0.0, Math.sin(a) * 0.12);
                }
            }
            wasOnGround = ground;
        }
    }

    public static final class KillEffect extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Soul", PARTICLES));
        private final Setting.Num amount = add(new Setting.Num("Amount", 24, 6, 80, 1));
        private final Setting.Bool sound = add(new Setting.Bool("Sound", false));
        private final Set<Integer> done = new HashSet<>();

        public KillEffect() {
            super("KillEffect", "Burst of particles when your target dies", Category.VISUALS);
        }

        @Override
        public void onTick() {
            LivingEntity last = Util.lastAttacked();
            if (last == null || mc.level == null) {
                return;
            }
            if (last.isDeadOrDying() && done.add(last.getId())) {
                ParticleOptions p = particle(type.get());
                for (int i = 0; i < amount.asInt(); i++) {
                    mc.level.addParticle(p, last.getX(), last.getY() + last.getBbHeight() / 2, last.getZ(),
                            (RANDOM.nextDouble() - 0.5) * 0.3, RANDOM.nextDouble() * 0.25,
                            (RANDOM.nextDouble() - 0.5) * 0.3);
                }
                if (sound.get()) {
                    mc.level.playLocalSound(last.getX(), last.getY(), last.getZ(),
                            SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0f, 0.8f, false);
                }
            }
            if (done.size() > 64) {
                done.clear();
            }
        }
    }

    public static final class Halo extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Glow", PARTICLES));
        private final Setting.Num radius = add(new Setting.Num("Radius", 0.35, 0.2, 0.8, 0.05));
        private final Setting.Num height = add(new Setting.Num("Height", 0.35, 0.0, 1.0, 0.05));
        private int tick;

        public Halo() {
            super("Halo", "A ring of light above your head (third person)", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null || mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            tick++;
            ParticleOptions p = particle(type.get());
            for (int k = 0; k < 3; k++) {
                double a = (tick * 0.35) + k * Math.PI * 2 / 3;
                mc.level.addParticle(p, mc.player.getX() + Math.cos(a) * radius.get(),
                        mc.player.getY() + mc.player.getBbHeight() + height.get(),
                        mc.player.getZ() + Math.sin(a) * radius.get(), 0, 0, 0);
            }
        }
    }

    public static final class ChinaHat extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Flame", PARTICLES));
        private int tick;

        public ChinaHat() {
            super("ChinaHat", "A cone of particles over your head (third person)", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null || mc.options.getCameraType().isFirstPerson()) {
                return;
            }
            tick++;
            ParticleOptions p = particle(type.get());
            for (int ring = 0; ring < 3; ring++) {
                double r = 0.55 - ring * 0.18;
                double a = tick * 0.4 + ring * 1.1;
                mc.level.addParticle(p, mc.player.getX() + Math.cos(a) * r,
                        mc.player.getY() + mc.player.getBbHeight() + 0.05 + ring * 0.12,
                        mc.player.getZ() + Math.sin(a) * r, 0, 0, 0);
            }
        }
    }

    public static final class HitBubble extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Magic", PARTICLES));
        private final Setting.Num radius = add(new Setting.Num("Radius", 0.9, 0.4, 2.0, 0.1));
        private final Setting.Num amount = add(new Setting.Num("Amount", 28, 8, 80, 1));

        public HitBubble() {
            super("HitBubble", "A bubble of particles around hit entities", Category.VISUALS);
        }

        @Override
        public void onAttack(LivingEntity target) {
            if (mc.level == null) {
                return;
            }
            ParticleOptions p = particle(type.get());
            Vec3 c = target.position().add(0, target.getBbHeight() / 2, 0);
            for (int i = 0; i < amount.asInt(); i++) {
                double u = RANDOM.nextDouble() * 2 - 1;
                double a = RANDOM.nextDouble() * Math.PI * 2;
                double s = Math.sqrt(1 - u * u);
                mc.level.addParticle(p, c.x + s * Math.cos(a) * radius.get(), c.y + u * radius.get(),
                        c.z + s * Math.sin(a) * radius.get(), 0, 0, 0);
            }
        }
    }

    public static final class HitSounds extends Module {
        private final Setting.Mode sound = add(new Setting.Mode("Sound", "Pling", "Pling", "Bell", "Orb", "Hat", "Bass"));
        private final Setting.Num volume = add(new Setting.Num("Volume", 1.0, 0.1, 2.0, 0.1));
        private final Setting.Num pitch = add(new Setting.Num("Pitch", 1.2, 0.5, 2.0, 0.1));

        public HitSounds() {
            super("HitSounds", "Plays a sound when you hit something", Category.VISUALS);
        }

        @Override
        public void onAttack(LivingEntity target) {
            if (mc.level == null) {
                return;
            }
            SoundEvent event = switch (sound.get()) {
                case "Bell" -> SoundEvents.NOTE_BLOCK_BELL.value();
                case "Orb" -> SoundEvents.EXPERIENCE_ORB_PICKUP;
                case "Hat" -> SoundEvents.NOTE_BLOCK_HAT.value();
                case "Bass" -> SoundEvents.NOTE_BLOCK_BASS.value();
                default -> SoundEvents.NOTE_BLOCK_PLING.value();
            };
            mc.level.playLocalSound(target.getX(), target.getY(), target.getZ(), event, SoundSource.PLAYERS,
                    volume.asFloat(), pitch.asFloat(), false);
        }
    }

    public static final class Particles extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Crit", PARTICLES));
        private final Setting.Num amount = add(new Setting.Num("Amount", 12, 1, 60, 1));

        public Particles() {
            super("Particles", "Extra particles when you hit something", Category.VISUALS);
        }

        @Override
        public void onAttack(LivingEntity target) {
            if (mc.level == null) {
                return;
            }
            ParticleOptions p = particle(type.get());
            for (int i = 0; i < amount.asInt(); i++) {
                mc.level.addParticle(p, target.getX() + (RANDOM.nextDouble() - 0.5) * target.getBbWidth(),
                        target.getY() + RANDOM.nextDouble() * target.getBbHeight(),
                        target.getZ() + (RANDOM.nextDouble() - 0.5) * target.getBbWidth(),
                        (RANDOM.nextDouble() - 0.5) * 0.2, RANDOM.nextDouble() * 0.2, (RANDOM.nextDouble() - 0.5) * 0.2);
            }
        }
    }

    public static final class WorldParticles extends Module {
        private final Setting.Mode type = add(new Setting.Mode("Particle", "Snow", "Snow", "Ash", "Glow", "Hearts", "Magic"));
        private final Setting.Num amount = add(new Setting.Num("Amount", 4, 1, 20, 1));
        private final Setting.Num range = add(new Setting.Num("Range", 10, 4, 24, 1));

        public WorldParticles() {
            super("WorldParticles", "Ambient particles around you", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.player == null || mc.level == null) {
                return;
            }
            ParticleOptions p = particle(type.get());
            for (int i = 0; i < amount.asInt(); i++) {
                double r = range.get();
                mc.level.addParticle(p, mc.player.getX() + (RANDOM.nextDouble() * 2 - 1) * r,
                        mc.player.getY() + RANDOM.nextDouble() * r * 0.6,
                        mc.player.getZ() + (RANDOM.nextDouble() * 2 - 1) * r, 0, -0.02, 0);
            }
        }
    }

    public static final class WorldCustomizer extends Module {
        private final Setting.Mode time = add(new Setting.Mode("Time", "Server", "Server", "Day", "Noon", "Sunset", "Night", "Midnight"));
        private final Setting.Bool clearWeather = add(new Setting.Bool("Clear weather", true));

        public WorldCustomizer() {
            super("WorldCustomizer", "Client-side time of day and weather", Category.VISUALS);
        }

        @Override
        public void onTick() {
            if (mc.level == null) {
                return;
            }
            long fixed = switch (time.get()) {
                case "Day" -> 1000L;
                case "Noon" -> 6000L;
                case "Sunset" -> 12500L;
                case "Night" -> 14500L;
                case "Midnight" -> 18000L;
                default -> -1L;
            };
            if (fixed >= 0) {
                mc.level.setTimeFromServer(mc.level.getGameTime(), fixed, false);
            }
            if (clearWeather.get()) {
                mc.level.setRainLevel(0f);
                mc.level.setThunderLevel(0f);
            }
        }
    }
}

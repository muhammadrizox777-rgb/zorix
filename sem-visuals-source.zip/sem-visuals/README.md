# Sem Visuals (Fabric, Minecraft 1.21.11)

Client-side Fabric mod: Click GUI (Right Shift), HUD editor, configs, friends, markers, event log.

Build: `./gradlew build` -> `build/libs/`.

## Modules (40)
- Visuals (15): FullBright, Zoom, Crosshair, TargetEsp, ArrowNametag, Trails, JumpCircles, KillEffect, Halo, ChinaHat, HitBubble, HitSounds, Particles, WorldParticles, WorldCustomizer
- HUD (15): ClientColor, Watermark, Notifications, ArmorHud, PotionsHud, SaturationHud, TotemsHud, CooldownsHud, InventoryHud, HotkeysHud, TargetHud, Coordinates, TntTimer, MarkerOverlay, EffectNotify
- Utilities (10): Sprint, AutoRespawn, AutoReconnect, ArmorNotifier, DeathMarker, ChatHelper, CommandSafe, ItemPickupLogger, AutoEat, StreamerMode

Written independently; no code from the PulseVisuals jar is used.

## Fonts
33 bundled OFL fonts (see `LICENSES-FONTS/`). Pick one in ClientColor > "Interface font"; it is applied to the menu and HUD.

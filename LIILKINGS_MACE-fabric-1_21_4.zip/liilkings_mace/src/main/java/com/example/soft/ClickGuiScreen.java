package com.example.soft;

import com.example.soft.modules.MaceAura;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int W = 110, H = 14, GAP = 10, TOP = 20;

    public ClickGuiScreen() { super(Text.literal("LIILKINGS_MACE")); }

    private int startX(int cats) {
        int totalW = cats * W + (cats - 1) * GAP;
        return (width - totalW) / 2;
    }

    private Module moduleAt(double mx, double my) {
        List<String> cats = SoftClient.modules.categories();
        int x = startX(cats.size());
        for (String cat : cats) {
            int y = TOP + H;
            for (Module m : SoftClient.modules.modules) {
                if (!m.category.equals(cat)) continue;
                if (mx >= x && mx < x + W && my >= y && my < y + H) return m;
                y += H;
            }
            x += W + GAP;
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        ctx.drawCenteredTextWithShadow(textRenderer, "LIILKINGS_MACE", width / 2, 6, 0xFFFFAA00);
        List<String> cats = SoftClient.modules.categories();
        int x = startX(cats.size());
        String hover = null;

        for (String cat : cats) {
            ctx.fill(x, TOP, x + W, TOP + H, 0xFF2B2B8F);
            ctx.drawCenteredTextWithShadow(textRenderer, cat, x + W / 2, TOP + 3, 0xFFFFFFFF);
            int y = TOP + H;
            for (Module m : SoftClient.modules.modules) {
                if (!m.category.equals(cat)) continue;
                boolean over = mouseX >= x && mouseX < x + W && mouseY >= y && mouseY < y + H;
                int bg = m.isEnabled() ? 0xFF1E8F3E : (over ? 0xFF444444 : 0xFF222222);
                ctx.fill(x, y, x + W, y + H, bg);
                ctx.drawTextWithShadow(textRenderer, m.name, x + 4, y + 3, 0xFFFFFFFF);
                if (over) hover = m.getDescription();
                y += H;
            }
            x += W + GAP;
        }
        if (hover != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, hover, width / 2, height - 20, 0xFFFFFF55);
        }
        ctx.drawCenteredTextWithShadow(textRenderer, "Bosish: yoqish/o'chirish | Esc: yopish",
                width / 2, height - 10, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        Module m = moduleAt(mx, my);
        if (m != null) { m.toggle(); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (moduleAt(mx, my) instanceof MaceAura) {
            Config.maceRange = Config.clamp(Config.maceRange + Math.signum(vertical) * 0.5);
            Config.save();
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean shouldPause() { return false; }
}

package com.example.soft;

import com.example.soft.modules.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new AutoMine());
        modules.add(new KillAura());
        modules.add(new MaceAura());
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new Fullbright());
        modules.add(new ESP());
        modules.add(new AutoSprint());
    }

    public void tick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public void disableAll() {
        for (Module m : modules) m.setEnabled(false);
    }

    public List<String> categories() {
        List<String> out = new ArrayList<>();
        for (Module m : modules) if (!out.contains(m.category)) out.add(m.category);
        return out;
    }
}

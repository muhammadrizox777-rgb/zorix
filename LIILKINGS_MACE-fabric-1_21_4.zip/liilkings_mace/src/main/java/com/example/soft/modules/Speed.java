package com.example.soft.modules;

import com.example.soft.Module;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private static final double SPEED = 0.35;

    public Speed() { super("Speed", "Harakat", "Yerda tezroq yugurish (W bosilganda)"); }

    @Override public void onTick() {
        var p = mc.player;
        if (!p.isOnGround() || !mc.options.forwardKey.isPressed()) return;
        double yaw = Math.toRadians(p.getYaw());
        Vec3d v = p.getVelocity();
        p.setVelocity(-Math.sin(yaw) * SPEED, v.y, Math.cos(yaw) * SPEED);
    }
}

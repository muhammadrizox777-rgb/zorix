package com.example.soft.modules;

import com.example.soft.Config;
import com.example.soft.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public class MaceAura extends Module {
    private int windTicks = 0;

    public MaceAura() { super("MaceAura", "Jang", "Wind bilan uchganda mace uradi"); }

    @Override public String getDescription() {
        return "MaceAura: radius " + Config.maceRange + " blok (g'ildirak bilan o'zgartiring)";
    }

    @Override public void onDisable() { windTicks = 0; }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        // Wind charge ishlatilganini aniqlash (5 soniyalik oyna)
        if (p.getItemCooldownManager().isCoolingDown(new ItemStack(Items.WIND_CHARGE))) windTicks = 100;
        else if (windTicks > 0) windTicks--;

        if (Config.windOnly && (windTicks <= 0 || p.isOnGround())) return;
        if (p.getAttackCooldownProgress(0f) < 1f) return;

        if (!equipMace(p)) return;

        double r = Config.maceRange;
        Entity best = null;
        double bestDist = r * r;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || e instanceof PlayerEntity || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best == null) return;

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }

    private boolean equipMace(net.minecraft.client.network.ClientPlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.MACE)) { inv.selectedSlot = i; return true; }
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.MACE)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, inv.selectedSlot,
                        SlotActionType.SWAP, p);
                return p.getInventory().getStack(inv.selectedSlot).isOf(Items.MACE);
            }
        }
        return false;
    }
}

package com.example.soft.modules;

import com.example.soft.Module;

public class AutoMine extends Module {
    public AutoMine() { super("AutoMine", "Dunyo", "Qaragan blokni avtomatik qazadi"); }

    @Override public void onTick() {
        if (mc.currentScreen == null) mc.options.attackKey.setPressed(true);
    }
    @Override public void onDisable() { mc.options.attackKey.setPressed(false); }
}

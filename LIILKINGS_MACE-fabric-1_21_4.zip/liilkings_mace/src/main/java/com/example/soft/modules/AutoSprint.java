package com.example.soft.modules;

import com.example.soft.Module;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint", "Harakat", "W bosilganda o'zi yuguradi"); }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.options.forwardKey.isPressed() && !p.horizontalCollision && !p.isSneaking()) p.setSprinting(true);
    }
}

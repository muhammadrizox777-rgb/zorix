package com.example.soft.modules;

import com.example.soft.Module;

public class Fly extends Module {
    public Fly() { super("Fly", "Harakat", "Havoda uchish (Space - yuqoriga, Shift - pastga)"); }

    @Override public void onTick() {
        var a = mc.player.getAbilities();
        a.allowFlying = true;
        a.setFlySpeed(0.08f);
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        var a = mc.player.getAbilities();
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
        a.setFlySpeed(0.05f);
    }
}

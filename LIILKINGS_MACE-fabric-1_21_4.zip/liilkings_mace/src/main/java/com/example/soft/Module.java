package com.example.soft;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public final String description;
    public final String category;
    private boolean enabled;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name, String category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    public String getDescription() { return description; }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}

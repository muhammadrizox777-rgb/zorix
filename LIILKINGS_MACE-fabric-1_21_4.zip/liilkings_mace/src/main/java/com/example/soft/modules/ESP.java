package com.example.soft.modules;

import com.example.soft.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ESP extends Module {
    private static final double RANGE = 64.0;
    private static final int MAX_LINES = 8;
    private final Set<Entity> marked = new HashSet<>();
    public volatile List<String> lines = new ArrayList<>();

    public ESP() { super("ESP", "Ko'rinish", "Mavjudot va qo'lidagi narsani ko'rsatadi"); }

    @Override public void onTick() {
        if (mc.world == null || mc.player == null) return;
        marked.removeIf(e -> e.isRemoved());
        List<LivingEntity> near = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity le)) continue;
            if (mc.player.squaredDistanceTo(e) <= RANGE * RANGE) {
                if (!e.isGlowing()) { e.setGlowing(true); marked.add(e); }
                near.add(le);
            } else if (marked.remove(e)) {
                e.setGlowing(false);
            }
        }
        near.sort(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)));
        List<String> out = new ArrayList<>();
        for (LivingEntity le : near) {
            if (out.size() >= MAX_LINES) break;
            String held = describe(le.getMainHandStack());
            String off = describe(le.getOffHandStack());
            StringBuilder sb = new StringBuilder(le.getName().getString());
            sb.append(" (").append(Math.round(mc.player.distanceTo(le))).append("m)");
            if (!held.isEmpty()) sb.append(": ").append(held);
            if (!off.isEmpty()) sb.append(" + ").append(off);
            out.add(sb.toString());
        }
        lines = out;
    }

    private static String describe(ItemStack s) {
        return s.isEmpty() ? "" : s.getName().getString();
    }

    @Override public void onDisable() {
        for (Entity e : marked) if (!e.isRemoved()) e.setGlowing(false);
        marked.clear();
        lines = new ArrayList<>();
    }
}

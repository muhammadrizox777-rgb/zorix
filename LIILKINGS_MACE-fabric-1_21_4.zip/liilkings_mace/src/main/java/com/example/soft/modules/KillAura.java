package com.example.soft.modules;

import com.example.soft.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private static final double RANGE = 4.0;

    public KillAura() { super("KillAura", "Jang", "Yaqin atrofdagi mavjudotlarga uradi"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.getAttackCooldownProgress(0f) < 1f) return;

        Entity best = null;
        double bestDist = RANGE * RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}

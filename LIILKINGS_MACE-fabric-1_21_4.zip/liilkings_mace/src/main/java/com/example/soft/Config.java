package com.example.soft;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Config {
    public static double maceRange = 6.0;
    public static boolean windOnly = true;
    private static final double MIN = 1.0, MAX = 6.0;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("liilkings_mace.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) { save(); return; }
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            maceRange = clamp(Double.parseDouble(p.getProperty("maceRange", "6.0")));
            windOnly = Boolean.parseBoolean(p.getProperty("windOnly", "true"));
        } catch (IOException | NumberFormatException e) {
            maceRange = 6.0;
        }
        save();
    }

    public static void save() {
        maceRange = clamp(maceRange);
        Properties p = new Properties();
        p.setProperty("maceRange", String.valueOf(maceRange));
        p.setProperty("windOnly", String.valueOf(windOnly));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "LIILKINGS_MACE config. maceRange: " + MIN + " - " + MAX + " blok");
        } catch (IOException ignored) {}
    }

    public static double clamp(double v) {
        if (Double.isNaN(v)) return 6.0;
        return Math.max(MIN, Math.min(MAX, Math.round(v * 2.0) / 2.0));
    }
}

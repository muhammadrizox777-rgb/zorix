package com.example.soft;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class SoftClient implements ClientModInitializer {
    public static ModuleManager modules;
    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        Config.load();
        modules = new ModuleManager();
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.soft.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.soft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Faqat yakka o'yin: boshqa joyda hamma modul o'chadi
            if (client.player == null || client.world == null || !client.isInSingleplayer()) {
                modules.disableAll();
                return;
            }
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            modules.tick();
        });

        // Yoqilgan modullar ro'yxati (ekran chetida)
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            ctx.drawText(mc.textRenderer, "LIILKINGS_MACE", 4, 4, 0xFFFFAA00, true);
            int y = 16;
            for (Module m : modules.modules) {
                if (!m.isEnabled()) continue;
                ctx.drawText(mc.textRenderer, m.name, 4, y, 0xFF55FF55, true);
                y += 10;
            }
            for (Module m : modules.modules) {
                if (m instanceof com.example.soft.modules.ESP esp && esp.isEnabled()) {
                    int ey = 4;
                    for (String line : esp.lines) {
                        ctx.drawText(mc.textRenderer, line,
                                ctx.getScaledWindowWidth() - mc.textRenderer.getWidth(line) - 4, ey, 0xFFFFFFFF, true);
                        ey += 10;
                    }
                }
            }
        });
    }
}

#!/usr/bin/env python3
"""Replaces leftover intermediary names (field_123, method_456, comp_789) in the
decompiled sources with their Yarn names, using the official Yarn v2 mappings jar.
String literals (e.g. mixin targets) are left untouched.

usage: remap_leftovers.py <yarn-v2.jar> <src-dir>
"""
import re
import sys
import zipfile
from pathlib import Path

jar, src = sys.argv[1], Path(sys.argv[2])

with zipfile.ZipFile(jar) as z:
    tiny = z.read("mappings/mappings.tiny").decode("utf-8").splitlines()

# header: tiny <major> <minor> <ns1> <ns2> ...
ns = tiny[0].split("\t")[3:]
i_inter, i_named = ns.index("intermediary"), ns.index("named")

mapping = {}
for line in tiny[1:]:
    t = line.lstrip("\t")
    depth = len(line) - len(t)
    parts = t.split("\t")
    # members are at depth 1: "m <desc> <ns...>" / "f <desc> <ns...>"
    if depth == 1 and parts[0] in ("m", "f"):
        names = parts[2:]
        inter = names[i_inter]
        named = names[i_named] if i_named < len(names) and names[i_named] else inter
        if re.fullmatch(r"(field|method|comp)_\d+", inter) and named != inter:
            mapping[inter] = named

TOKEN = re.compile(r'"(?:\\.|[^"\\\n])*"|\b(?:field|method|comp)_\d+\b')
missing = set()
changed = 0


def repl(m):
    s = m.group(0)
    if s.startswith('"'):
        return s
    if s in mapping:
        return mapping[s]
    missing.add(s)
    return s


for f in src.rglob("*.java"):
    text = f.read_text(encoding="utf-8")
    new = TOKEN.sub(repl, text)
    if new != text:
        f.write_text(new, encoding="utf-8")
        changed += 1

print(f"remapped {changed} files; {len(mapping)} mappings loaded")
if missing:
    print("UNRESOLVED:", ", ".join(sorted(missing)))
    sys.exit(1)

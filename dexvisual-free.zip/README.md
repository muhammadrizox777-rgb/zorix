# DEX VISUAL 2.0.5

Free version - license/activation system removed.

Build: push to GitHub, the workflow in `.github/workflows/build.yml` builds the jar
(Actions tab -> latest run -> Artifacts -> dexvisual).

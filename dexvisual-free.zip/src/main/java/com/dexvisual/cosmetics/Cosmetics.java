package com.dexvisual.cosmetics;

import com.dexvisual.config.DexConfig;
import com.dexvisual.net.SyncNet;
import com.google.gson.Gson;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Cosmetics {
   public static final String[] CATS = new String[]{
      "capes", "wings", "hats", "pets", "petacc", "particles", "skins", "killfx", "swords", "crowns", "colors", "backpacks"
   };
   public static final String[] LABELS = new String[]{
      "Capes (Paxta)",
      "Wings (Qanotlar)",
      "Hats & Masks (Bosh kiyimlar)",
      "Pets (Uy hayvonlar)",
      "Pet Accessories",
      "Particles (Maxsus efektlar)",
      "Skin Presets (Tayyor skinlar)",
      "Kill Effects (O'ldirish efektlari)",
      "Sword Skins (Qilich skinlari)",
      "Crowns / Halo / Taj",
      "Color Variants (Rang variantlari)",
      "Backpacks (Ryukzak)"
   };
   private static List<Cosmetic> items;

   private Cosmetics() {
   }

   public static synchronized List<Cosmetic> all() {
      if (items == null) {
         items = new ArrayList<>();

         try (InputStream in = Cosmetics.class.getResourceAsStream("/assets/dexvisual/cosmetics.json")) {
            if (in != null) {
               Cosmetics.Root r = (Cosmetics.Root)new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), Cosmetics.Root.class);
               if (r != null && r.items != null) {
                  items.addAll(r.items);
               }
            }
         } catch (Throwable var5) {
            System.err.println("[DexVisual] cosmetics load failed: " + var5);
         }
      }

      return items;
   }

   public static List<Cosmetic> byCat(String cat) {
      List<Cosmetic> out = new ArrayList<>();

      for (Cosmetic c : all()) {
         if (c.cat.equals(cat)) {
            out.add(c);
         }
      }

      return out;
   }

   public static Cosmetic find(String cat, String id) {
      if (id == null) {
         return null;
      } else {
         for (Cosmetic c : all()) {
            if (c.cat.equals(cat) && c.id.equals(id)) {
               return c;
            }
         }

         return null;
      }
   }

   public static Cosmetic selected(String cat) {
      DexConfig cfg = DexConfig.get();
      if (cfg.cosmetics == null) {
         return null;
      } else {
         String id = cfg.cosmetics.get(cat);
         if (id == null) {
            return null;
         } else {
            for (Cosmetic c : all()) {
               if (c.cat.equals(cat) && c.id.equals(id)) {
                  return c;
               }
            }

            return null;
         }
      }
   }

   public static boolean isSelected(Cosmetic c) {
      DexConfig cfg = DexConfig.get();
      return cfg.cosmetics != null && c.id.equals(cfg.cosmetics.get(c.cat));
   }

   public static void toggle(Cosmetic c) {
      DexConfig cfg = DexConfig.get();
      if (cfg.cosmetics == null) {
         cfg.cosmetics = new LinkedHashMap<>();
      }

      if (isSelected(c)) {
         cfg.cosmetics.remove(c.cat);
      } else {
         cfg.cosmetics.put(c.cat, c.id);
         if (c.cat.equals("colors")) {
            cfg.cosmetics.remove("crowns");
         } else if (c.cat.equals("crowns")) {
            cfg.cosmetics.remove("colors");
         }
      }

      DexConfig.markDirty();
      SyncNet.changed();
   }

   public static void clear() {
      DexConfig cfg = DexConfig.get();
      if (cfg.cosmetics != null) {
         cfg.cosmetics.clear();
      }

      DexConfig.markDirty();
      SyncNet.changed();
   }

   public static String selectedId(String cat) {
      DexConfig cfg = DexConfig.get();
      return cfg.cosmeticsOn && cfg.cosmetics != null ? cfg.cosmetics.get(cat) : null;
   }

   public static boolean active() {
      DexConfig cfg = DexConfig.get();
      return cfg.cosmeticsOn && cfg.cosmetics != null && !cfg.cosmetics.isEmpty();
   }

   private static final class Root {
      List<Cosmetic> items;

      private Root() {
      }
   }
}

package com.dexvisual.cosmetics;

import com.dexvisual.config.DexConfig;
import com.dexvisual.net.SyncNet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.EntityPose;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import org.joml.Matrix4f;

public final class CosmeticRenderer {
   private static final float PX = 0.05859375F;
   private static final Random RND = new Random();
   private static long lastNs = 0L;
   private static float time = 0.0F;
   private static final Map<UUID, CosmeticRenderer.Rig> RIGS = new HashMap<>();
   private static final float[] SHADE = new float[]{0.86F, 0.72F, 0.78F, 0.78F, 1.0F, 0.58F};
   private static final String[] HEART = new String[]{".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};

   private CosmeticRenderer() {
   }

   public static boolean active() {
      return Cosmetics.active() || DexConfig.get().showOthers && !SyncNet.REMOTE.isEmpty();
   }

   public static void render(Immediate imm, MatrixStack ms, MinecraftClient mc, Camera cam) {
      DexConfig cfg = DexConfig.get();
      PlayerEntity me = mc.player;
      if (me != null && mc.world != null) {
         float td = mc.getRenderTickCounter().getTickDelta(false);
         long now = System.nanoTime();
         float dt = lastNs == 0L ? 0.016F : Math.min(0.05F, (float)(now - lastNs) / 1.0E9F);
         lastNs = now;
         time = (time + dt) % 100000.0F;
         boolean first = mc.options.getPerspective().isFirstPerson();
         List<CosmeticRenderer.Wing> wings = new ArrayList<>();
         VertexConsumer solid = imm.getBuffer(RenderLayer.getDebugQuads());
         if (cfg.cosmeticsOn && Cosmetics.active()) {
            one(imm, solid, ms, mc, cam, me, cfg.cosmetics, true, first, td, dt, wings);
         }

         if (cfg.showOthers) {
            Vec3d cp = cam.getPos();

            for (PlayerEntity pl : mc.world.getPlayers()) {
               if (pl != me) {
                  Map<String, String> sel = SyncNet.REMOTE.get(pl.getUuid());
                  if (sel != null && !sel.isEmpty() && !(pl.squaredDistanceTo(cp) > 3136.0)) {
                     one(imm, solid, ms, mc, cam, pl, sel, false, false, td, dt, wings);
                  }
               }
            }
         }

         imm.draw(RenderLayer.getDebugQuads());

         for (CosmeticRenderer.Wing w : wings) {
            drawWings(imm, ms, w);
         }

         long ms2 = System.currentTimeMillis();
         RIGS.values().removeIf(r -> ms2 - r.seen > 5000L);
      }
   }

   private static void one(
      Immediate imm,
      VertexConsumer solid,
      MatrixStack ms,
      MinecraftClient mc,
      Camera cam,
      PlayerEntity p,
      Map<String, String> sel,
      boolean self,
      boolean first,
      float td,
      float dt,
      List<CosmeticRenderer.Wing> wings
   ) {
      CosmeticRenderer.Rig rig = RIGS.computeIfAbsent(p.getUuid(), k -> new CosmeticRenderer.Rig());
      rig.seen = System.currentTimeMillis();
      Cosmetic wing = Cosmetics.find("wings", sel.get("wings"));
      Cosmetic hat = Cosmetics.find("hats", sel.get("hats"));
      Cosmetic crown = Cosmetics.find("crowns", sel.get("crowns"));
      Cosmetic pack = Cosmetics.find("backpacks", sel.get("backpacks"));
      Cosmetic pet = Cosmetics.find("pets", sel.get("pets"));
      Cosmetic fx = Cosmetics.find("particles", sel.get("particles"));
      Cosmetic cape = Cosmetics.find("capes", sel.get("capes"));
      Cosmetic sword = Cosmetics.find("swords", sel.get("swords"));
      Cosmetic petAcc = Cosmetics.find("petacc", sel.get("petacc"));
      if (crown == null) {
         crown = Cosmetics.find("colors", sel.get("colors"));
      }

      double dd = p.squaredDistanceTo(cam.getPos());
      Vec3d pos = p.getLerpedPos(td);
      int lvl = mc.world.getLightLevel(BlockPos.ofFloored(pos.x, pos.y + 1.0, pos.z));
      rig.lightSmooth = rig.lightSmooth + (0.34F + 0.66F * lvl / 15.0F - rig.lightSmooth) * Math.min(1.0F, dt * 6.0F);
      CosmeticRenderer.Ctx c = new CosmeticRenderer.Ctx();
      c.t = time;
      c.bright = rig.lightSmooth;
      Vec3d vel = p.getVelocity();
      float hv = (float)Math.sqrt(vel.x * vel.x + vel.z * vel.z);
      c.air = !p.isOnGround() && !p.isTouchingWater();
      c.move = MathHelper.clamp(hv * 5.5F, 0.0F, 1.0F);
      c.sprint = p.isSprinting();
      EntityPose pose = p.getPose();
      boolean poseOk = pose == EntityPose.field_18076 || pose == EntityPose.field_18081;
      boolean showBody = !first && poseOk && !p.isSpectator() && !p.isSleeping();
      if (showBody && (hat != null || crown != null || pack != null || wing != null || cape != null || sword != null)) {
         ms.push();
         ms.translate(pos.x, pos.y, pos.z);
         float by = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-by));
         ms.scale(0.05859375F, 0.05859375F, 0.05859375F);
         boolean sneak = pose == EntityPose.field_18081;
         boolean helmet = !p.getEquippedStack(EquipmentSlot.field_6169).isEmpty();
         boolean chest = !p.getEquippedStack(EquipmentSlot.field_6174).isEmpty();
         if (hat != null || crown != null) {
            float hy = MathHelper.wrapDegrees(MathHelper.lerpAngleDegrees(td, p.prevHeadYaw, p.headYaw) - by);
            float pitch = p.getPitch(td);
            ms.push();
            ms.translate(0.0F, sneak ? 19.8F : 24.0F, 0.0F);
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-hy));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
            if (helmet) {
               ms.translate(0.0F, 3.5F, 0.0F);
               ms.scale(1.12F, 1.08F, 1.12F);
               ms.translate(0.0F, -3.5F, 0.0F);
            }

            if (hat != null) {
               drawParts(solid, ms, hat.parts, c, 1.0F);
            }

            if (crown != null) {
               drawParts(solid, ms, crown.parts, c, 1.0F);
            }

            ms.pop();
         }

         if (pack != null || wing != null || cape != null || sword != null) {
            ms.push();
            ms.translate(0.0F, sneak ? 20.8F : 24.0F, 0.0F);
            if (sneak) {
               ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(28.65F));
            }

            ms.translate(0.0F, -6.0F, 0.0F);
            if (pack != null) {
               ms.push();
               if (chest) {
                  ms.translate(0.0F, 0.0F, -1.2F);
               }

               drawParts(solid, ms, pack.parts, c, 1.0F);
               ms.pop();
            }

            if (cape != null) {
               ms.push();
               if (chest) {
                  ms.translate(0.0F, 0.0F, -0.6F);
               }

               drawCape(imm, solid, ms, cape, c);
               ms.pop();
            }

            if (sword != null) {
               ms.push();
               if (chest) {
                  ms.translate(0.0F, 0.0F, -0.6F);
               }

               drawParts(solid, ms, sword.parts, c, 1.0F);
               ms.pop();
            }

            if (wing != null) {
               CosmeticRenderer.Wing j = new CosmeticRenderer.Wing();
               j.w = wing;
               j.m = new Matrix4f(ms.peek().getPositionMatrix());
               j.sneak = sneak;
               j.chest = chest;
               j.c = c;
               wings.add(j);
            }

            ms.pop();
         }

         ms.pop();
      }

      if (pet != null && (self || dd < 1600.0)) {
         pet(solid, ms, mc, p, pet, petAcc, td, dt, c, cam, first && self, rig);
      }

      if (fx != null && (!self || !first) && (self || dd < 576.0)) {
         particles(solid, ms, mc, p, cam, fx, pos, dt, td, rig, self ? 1.0F : 0.6F);
      } else if (!rig.pts.isEmpty()) {
         rig.pts.clear();
      }
   }

   private static void drawParts(VertexConsumer vc, MatrixStack ms, List<Cosmetic.Part> parts, CosmeticRenderer.Ctx c, float alphaMul) {
      for (Cosmetic.Part pt : parts) {
         boolean xf = pt.an != null && !pt.an.equals("none");
         if (xf) {
            ms.push();
            animate(ms, pt, c);
         }

         int n = pt.b.length;

         for (int i = 0; i < n; i++) {
            boxRot(vc, ms, pt.b[i], c, i, n, alphaMul);
         }

         if (xf) {
            ms.pop();
         }
      }
   }

   private static void drawCape(Immediate imm, VertexConsumer solid, MatrixStack ms, Cosmetic cape, CosmeticRenderer.Ctx c) {
      float py = 6.0F;
      float pz = -2.0F;
      float lift = c.move * (c.sprint ? 34.0F : 17.0F) + (c.air ? 14.0F : 0.0F);
      float wave = (float)Math.sin(c.t * (c.sprint ? 11.0F : 7.0F) - 4.0F);
      float idle = 2.5F * (float)Math.sin(c.t * 1.7F - 1.5F);
      float ax = idle + lift * (1.0F + 0.22F * wave * Math.max(c.move, c.air ? 1.0F : 0.0F));
      float az = (float)Math.sin(c.t * 3.1F + 3.0F) * (1.2F + 5.0F * c.move);
      ms.push();
      ms.translate(0.0F, 6.0F, -2.0F);
      ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(ax));
      ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(az));
      ms.translate(0.0F, -6.0F, 2.0F);
      if (cape.tex != null) {
         Identifier tex = Identifier.of("dexvisual", "textures/cosmetics/" + cape.tex + ".png");
         VertexConsumer vc = imm.getBuffer(RenderLayer.getEntityTranslucentEmissive(tex));
         Matrix4f m = ms.peek().getPositionMatrix();
         float x0 = -5.0F;
         float x1 = 5.0F;
         float y0 = -11.5F;
         float y1 = 6.2F;
         float zc = -3.7F;
         wq(vc, m, x1, y1, zc, x0, y1, zc, x0, y0, zc, x1, y0, zc, 0.0F, 1.0F);
         wq(vc, m, x0, y1, zc, x1, y1, zc, x1, y0, zc, x0, y0, zc, 1.0F, 0.0F);
      }

      if (cape.parts != null) {
         for (Cosmetic.Part pt : cape.parts) {
            int n = pt.b.length;

            for (int i = 0; i < n; i++) {
               float[] b = pt.b[i];
               ms.push();
               if (pt.an != null && !pt.an.equals("none")) {
                  animate(ms, pt, c);
               }

               boxRot(solid, ms, b, c, i, n, 1.0F);
               ms.pop();
            }
         }
      }

      ms.pop();
   }

   private static void animate(MatrixStack ms, Cosmetic.Part pt, CosmeticRenderer.Ctx c) {
      float fq = pt.fq == 0.0F ? 1.0F : pt.fq;
      float px = pt.p != null ? pt.p[0] : 0.0F;
      float py = pt.p != null ? pt.p[1] : 0.0F;
      float pz = pt.p != null ? pt.p[2] : 0.0F;
      String var7 = pt.an;
      switch (var7) {
         case "walk":
            rot(ms, pt.ax, (float)Math.sin(c.walk) * pt.amp * c.move, px, py, pz);
            break;
         case "walk2":
            rot(ms, pt.ax, -((float)Math.sin(c.walk)) * pt.amp * c.move, px, py, pz);
            break;
         case "sin":
         case "wing":
            float k = pt.an.equals("sin") ? (c.air ? 1.7F : 1.0F) : 1.0F;
            rot(ms, pt.ax, (float)Math.sin(c.t * fq * (c.air ? 1.5F : 1.0F) + pt.ph) * pt.amp * k, px, py, pz);
            break;
         case "bobY":
            ms.translate(0.0F, (float)Math.sin(c.t * fq) * pt.amp, 0.0F);
            break;
         case "spin":
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(c.t * pt.amp * fq));
            break;
         case "bounce":
            float s = (float)Math.sin(c.t * fq * (1.0F + c.move));
            float hop = Math.max(0.0F, s) * 2.2F;
            ms.translate(px, py + hop, pz);
            ms.scale(1.0F - pt.amp * 0.55F * s, 1.0F + pt.amp * s, 1.0F - pt.amp * 0.55F * s);
            ms.translate(-px, -py, -pz);
      }
   }

   private static void rot(MatrixStack ms, int ax, float deg, float px, float py, float pz) {
      ms.translate(px, py, pz);
      RotationAxis a = ax == 0 ? RotationAxis.POSITIVE_X : (ax == 1 ? RotationAxis.POSITIVE_Y : RotationAxis.POSITIVE_Z);
      ms.multiply(a.rotationDegrees(deg));
      ms.translate(-px, -py, -pz);
   }

   private static void boxRot(VertexConsumer vc, MatrixStack ms, float[] b, CosmeticRenderer.Ctx c, int idx, int n, float alphaMul) {
      float rx = b[9];
      float ry = b[10];
      float rz = b[11];
      boolean rotd = rx != 0.0F || ry != 0.0F || rz != 0.0F;
      float x0 = b[0];
      float y0 = b[1];
      float z0 = b[2];
      float x1 = b[3];
      float y1 = b[4];
      float z1 = b[5];
      if (rotd) {
         float cx = (x0 + x1) / 2.0F;
         float cy = (y0 + y1) / 2.0F;
         float cz = (z0 + z1) / 2.0F;
         ms.push();
         ms.translate(cx, cy, cz);
         if (rz != 0.0F) {
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
         }

         if (ry != 0.0F) {
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
         }

         if (rx != 0.0F) {
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
         }

         x0 -= cx;
         x1 -= cx;
         y0 -= cy;
         y1 -= cy;
         z0 -= cz;
         z1 -= cz;
      }

      int rgb = (int)b[6];
      int flag = (int)b[8];
      float a = b[7] * alphaMul;
      float lm = c.bright;
      if (flag == 2) {
         rgb = MathHelper.hsvToRgb((c.t * 0.22F + (float)idx / Math.max(1, n)) % 1.0F, 0.72F, 1.0F);
         lm = 1.0F;
      } else if (flag == 1) {
         lm = 1.0F;
      }

      box(vc, ms.peek().getPositionMatrix(), x0, y0, z0, x1, y1, z1, rgb, a, lm, flag != 0);
      if (rotd) {
         ms.pop();
      }
   }

   private static void box(VertexConsumer vc, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, int rgb, float a, float lm, boolean glow) {
      int r = rgb >> 16 & 0xFF;
      int g = rgb >> 8 & 0xFF;
      int bl = rgb & 0xFF;
      int al = MathHelper.clamp((int)(a * 255.0F), 0, 255);
      q(vc, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, bl, al, SHADE[0] * (glow ? 1.08F : 1.0F) * lm);
      q(vc, m, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, bl, al, SHADE[1] * (glow ? 1.08F : 1.0F) * lm);
      q(vc, m, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, r, g, bl, al, SHADE[2] * (glow ? 1.08F : 1.0F) * lm);
      q(vc, m, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, bl, al, SHADE[3] * (glow ? 1.08F : 1.0F) * lm);
      q(vc, m, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, r, g, bl, al, SHADE[4] * lm);
      q(vc, m, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, bl, al, SHADE[5] * (glow ? 1.2F : 1.0F) * lm);
   }

   private static void q(
      VertexConsumer vc,
      Matrix4f m,
      float ax,
      float ay,
      float az,
      float bx,
      float by,
      float bz,
      float cx,
      float cy,
      float cz,
      float dx,
      float dy,
      float dz,
      int r,
      int g,
      int b,
      int a,
      float sh
   ) {
      int rr = Math.min(255, (int)(r * sh));
      int gg = Math.min(255, (int)(g * sh));
      int bb = Math.min(255, (int)(b * sh));
      vc.vertex(m, ax, ay, az).color(rr, gg, bb, a);
      vc.vertex(m, bx, by, bz).color(rr, gg, bb, a);
      vc.vertex(m, cx, cy, cz).color(rr, gg, bb, a);
      vc.vertex(m, dx, dy, dz).color(rr, gg, bb, a);
   }

   private static void drawWings(Immediate imm, MatrixStack ms, CosmeticRenderer.Wing job) {
      Cosmetic w = job.w;
      CosmeticRenderer.Ctx c = job.c;
      boolean sneak = job.sneak;
      boolean chest = job.chest;
      Matrix4f wingMatrix = job.m;
      Identifier tex = Identifier.of("dexvisual", "textures/cosmetics/" + w.tex + ".png");
      RenderLayer layer = RenderLayer.getEntityTranslucentEmissive(tex);
      VertexConsumer vc = imm.getBuffer(layer);
      float size = DexConfig.get().wingSize;
      float tw = w.tw * size;
      float phi;
      float amp;
      if (sneak) {
         phi = 10.0F;
         amp = 2.0F;
      } else if (c.air) {
         phi = 30.0F;
         amp = 24.0F;
      } else {
         phi = 26.0F + 6.0F * c.move;
         amp = 5.0F + 5.0F * c.move;
      }

      float flapRate = c.air ? 9.0F : 2.0F + 2.0F * c.move;
      float ph = c.t * flapRate;
      int N = 5;

      for (int side = -1; side <= 1; side += 2) {
         ms.push();
         ms.peek().getPositionMatrix().set(wingMatrix);
         Matrix4f m = ms.peek().getPositionMatrix();
         float rootX = side * 2.4F;
         float rootY = 5.2F;
         float rootZ = chest ? -3.5F : -2.4F;
         float yTop = rootY + w.ry * tw;
         float yBot = rootY - (1.0F - w.ry) * tw;
         float seg = tw / N;
         float baseAng = phi + amp * (float)Math.sin(ph);
         double a0 = Math.toRadians(baseAng);
         float qx = rootX - side * (float)Math.cos(a0) * w.rx * tw;
         float qz = rootZ + (float)Math.sin(a0) * w.rx * tw;
         float qy = 0.0F;

         for (int k = 0; k < N; k++) {
            float ang = baseAng + k * 5.5F + (c.air ? 7.0F * (float)Math.sin(ph - k * 0.5F) * k / N : 0.0F);
            double ar = Math.toRadians(ang);
            float dx = side * (float)Math.cos(ar);
            float dz = -((float)Math.sin(ar));
            float lift = (float)Math.sin(ph - (k + 1) * 0.45F) * (k + 1) * (c.air ? 1.4F : 0.55F) * 0.5F;
            float nx = qx + dx * seg;
            float nz = qz + dz * seg;
            float u0 = (float)k / N;
            float u1 = (float)(k + 1) / N;
            wq(vc, m, qx, yTop + qy, qz, nx, yTop + lift, nz, nx, yBot + lift, nz, qx, yBot + qy, qz, u0, u1);
            wq(vc, m, nx, yTop + lift, nz, qx, yTop + qy, qz, qx, yBot + qy, qz, nx, yBot + lift, nz, u1, u0);
            qx = nx;
            qz = nz;
            qy = lift;
         }

         ms.pop();
      }

      imm.draw(layer);
   }

   private static void wq(
      VertexConsumer vc,
      Matrix4f m,
      float ax,
      float ay,
      float az,
      float bx,
      float by,
      float bz,
      float cx,
      float cy,
      float cz,
      float dx,
      float dy,
      float dz,
      float u0,
      float u1
   ) {
      int ov = OverlayTexture.DEFAULT_UV;
      int lt = 15728880;
      vc.vertex(m, ax, ay, az).color(255, 255, 255, 255).texture(u0, 0.0F).overlay(ov).light(lt).normal(0.0F, 1.0F, 0.0F);
      vc.vertex(m, bx, by, bz).color(255, 255, 255, 255).texture(u1, 0.0F).overlay(ov).light(lt).normal(0.0F, 1.0F, 0.0F);
      vc.vertex(m, cx, cy, cz).color(255, 255, 255, 255).texture(u1, 1.0F).overlay(ov).light(lt).normal(0.0F, 1.0F, 0.0F);
      vc.vertex(m, dx, dy, dz).color(255, 255, 255, 255).texture(u0, 1.0F).overlay(ov).light(lt).normal(0.0F, 1.0F, 0.0F);
   }

   private static double groundY(World w, double x, double y0, double z) {
      Mutable mp = new Mutable();
      int bx = MathHelper.floor(x);
      int bz = MathHelper.floor(z);
      int top = MathHelper.floor(y0 + 1.2);

      for (int i = 0; i < 12; i++) {
         mp.set(bx, top - i, bz);
         BlockState bs = w.getBlockState(mp);
         VoxelShape sh = bs.getCollisionShape(w, mp);
         if (!sh.isEmpty()) {
            return mp.getY() + sh.getMax(Axis.field_11052);
         }
      }

      return Double.NaN;
   }

   private static void pet(
      VertexConsumer vc,
      MatrixStack ms,
      MinecraftClient mc,
      PlayerEntity p,
      Cosmetic pet,
      Cosmetic acc,
      float td,
      float dt,
      CosmeticRenderer.Ctx base,
      Camera cam,
      boolean first,
      CosmeticRenderer.Rig r
   ) {
      World w = mc.world;
      Vec3d o = p.getLerpedPos(td);
      float oy = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
      double yr = Math.toRadians(oy);
      double lx = Math.cos(yr);
      double lz = Math.sin(yr);
      double fx = -Math.sin(yr);
      double fz = Math.cos(yr);
      Vec3d tgt = new Vec3d(o.x + lx * -1.15 + fx * -1.15, o.y, o.z + lz * -1.15 + fz * -1.15);
      if (r.petPos == null || r.petWorld != w || r.petPos.squaredDistanceTo(o) > 324.0) {
         r.petPos = tgt;
         r.petY = (float)o.y;
         r.petVy = 0.0F;
         r.petWorld = w;
         r.petYaw = oy;
         r.petMove = 0.0F;
      }

      double dx = tgt.x - r.petPos.x;
      double dz = tgt.z - r.petPos.z;
      double dist = Math.sqrt(dx * dx + dz * dz);
      if (!r.petMoving && dist > 1.1) {
         r.petMoving = true;
      }

      if (r.petMoving && dist < 0.28) {
         r.petMoving = false;
      }

      float speed = 0.0F;
      if (r.petMoving) {
         speed = (float)MathHelper.clamp(dist * 3.4, 1.2, p.isSprinting() ? 9.0 : 6.5);
         r.petPos = new Vec3d(r.petPos.x + dx / dist * speed * dt, r.petPos.y, r.petPos.z + dz / dist * speed * dt);
         float want = (float)Math.toDegrees(Math.atan2(-dx, dz));
         r.petYaw = MathHelper.lerpAngleDegrees(Math.min(1.0F, dt * 9.0F), r.petYaw, want);
      } else {
         r.petYaw = MathHelper.lerpAngleDegrees(Math.min(1.0F, dt * 3.0F), r.petYaw, oy);
      }

      r.petMove = r.petMove + ((r.petMoving ? Math.min(1.0F, speed / 4.0F) : 0.0F) - r.petMove) * Math.min(1.0F, dt * 10.0F);
      r.petWalk += speed * dt * 2.6F;
      double g = groundY(w, r.petPos.x, Math.max((double)r.petY, o.y), r.petPos.z);
      if (Double.isNaN(g)) {
         g = o.y;
      }

      boolean flyer = pet.hover > 0.0F;
      if (flyer) {
         float want = (float)g + pet.hover + 0.12F * (float)Math.sin(time * 2.2F);
         r.petY = r.petY + (want - r.petY) * Math.min(1.0F, dt * 4.0F);
      } else if (g > r.petY) {
         r.petY = r.petY + Math.min((float)g - r.petY, 9.0F * dt);
         r.petVy = 0.0F;
      } else {
         r.petVy -= 22.0F * dt;
         r.petY = r.petY + r.petVy * dt;
         if (r.petY < g) {
            r.petY = (float)g;
            r.petVy = 0.0F;
         }
      }

      int lvl = w.getLightLevel(BlockPos.ofFloored(r.petPos.x, r.petY + 0.5, r.petPos.z));
      CosmeticRenderer.Ctx c = new CosmeticRenderer.Ctx();
      c.t = time;
      c.walk = r.petWalk;
      c.move = flyer ? 0.3F : r.petMove;
      c.air = false;
      c.bright = 0.34F + 0.66F * lvl / 15.0F;
      Vec3d cp = cam.getPos();
      double cdx = r.petPos.x - cp.x;
      double cdy = r.petY + 0.4 - cp.y;
      double cdz = r.petPos.z - cp.z;
      if (!(cdx * cdx + cdy * cdy + cdz * cdz < (first ? 12.25 : 1.44))) {
         float sc = 0.040625F * (pet.size == 0.0F ? 1.0F : pet.size) * DexConfig.get().petSize;
         ms.push();
         ms.translate(r.petPos.x, r.petY, r.petPos.z);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-r.petYaw));
         if (flyer) {
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(r.petMove * 10.0F));
         }

         ms.scale(sc, sc, sc);
         drawParts(vc, ms, pet.parts, c, 1.0F);
         if (acc != null && acc.parts != null) {
            float[] ha = pet.ha != null && pet.ha.length >= 3 ? pet.ha : new float[]{0.0F, 14.0F, 6.0F};
            float hs = pet.hs == 0.0F ? 1.0F : pet.hs;
            ms.push();
            ms.translate(ha[0], ha[1], ha[2]);
            ms.scale(hs, hs, hs);
            drawParts(vc, ms, acc.parts, c, 1.0F);
            ms.pop();
         }

         ms.pop();
      }
   }

   private static void particles(
      VertexConsumer vc,
      MatrixStack ms,
      MinecraftClient mc,
      PlayerEntity p,
      Camera cam,
      Cosmetic fx,
      Vec3d o,
      float dt,
      float td,
      CosmeticRenderer.Rig r,
      float rateMul
   ) {
      String k = fx.fx;
      float amount = DexConfig.get().fxAmount;

      float rate = switch (k) {
         case "fire" -> 38.0F;
         case "water" -> 26.0F;
         case "ender" -> 30.0F;
         case "heart" -> 3.2F;
         case "snow" -> 24.0F;
         case "magic" -> 22.0F;
         case "smoke" -> 18.0F;
         case "rainbow" -> 34.0F;
         case "electric" -> 9.0F;
         case "aura" -> 46.0F;
         case "trail" -> 60.0F;
         default -> 14.0F;
      } * amount * rateMul;
      if (k.equals("trail")) {
         Vec3d v = p.getVelocity();
         if (Math.sqrt(v.x * v.x + v.z * v.z) < 0.03) {
            rate *= 0.12F;
         }
      }

      r.spawnAcc += rate * dt;
      int guard = 0;

      while (r.spawnAcc >= 1.0F && guard++ < 12) {
         r.spawnAcc--;
         if (r.pts.size() < 220) {
            r.pts.add(spawn(k, o, p));
         }
      }

      if (r.spawnAcc > 4.0F) {
         r.spawnAcc = 0.0F;
      }

      double yaw = Math.toRadians(cam.getYaw());
      double pit = Math.toRadians(cam.getPitch());
      double fxv = -Math.sin(yaw) * Math.cos(pit);
      double fyv = -Math.sin(pit);
      double fzv = Math.cos(yaw) * Math.cos(pit);
      double rxv = -fzv;
      double rzv = fxv;
      double rl = Math.sqrt(rxv * rxv + fxv * fxv);
      if (rl < 1.0E-6) {
         rxv = -1.0;
         rzv = 0.0;
         rl = 1.0;
      }

      rxv /= rl;
      rzv /= rl;
      double uxv = -rzv * fyv;
      double uyv = rzv * fxv - rxv * fzv;
      double uzv = rxv * fyv;
      double ul = Math.sqrt(uxv * uxv + uyv * uyv + uzv * uzv);
      uxv /= ul;
      uyv /= ul;
      uzv /= ul;
      Matrix4f m = ms.peek().getPositionMatrix();
      Vec3d cp = cam.getPos();

      for (int i = r.pts.size() - 1; i >= 0; i--) {
         CosmeticRenderer.Pt q = r.pts.get(i);
         q.age += dt;
         if (q.age >= q.life) {
            r.pts.remove(i);
         } else {
            step(q, k, dt, o);
         }
      }

      r.pts
         .sort(
            Comparator.comparingDouble(
               a -> -(
                  (a.x - cp.x) * (a.x - cp.x) + (a.y - cp.y) * (a.y - cp.y) + (a.z - cp.z) * (a.z - cp.z)
               )
            )
         );

      for (CosmeticRenderer.Pt q : r.pts) {
         double ddx = q.x - cp.x;
         double ddy = q.y - cp.y;
         double ddz = q.z - cp.z;
         if (!(ddx * ddx + ddy * ddy + ddz * ddz < 2.25)) {
            drawPt(vc, m, q, k, rxv, 0.0, rzv, uxv, uyv, uzv);
         }
      }
   }

   private static CosmeticRenderer.Pt spawn(String k, Vec3d o, PlayerEntity p) {
      CosmeticRenderer.Pt q = new CosmeticRenderer.Pt();
      double a = RND.nextDouble() * Math.PI * 2.0;
      q.rot = RND.nextFloat() * 6.28F;
      q.kind = 0;
      switch (k) {
         case "fire": {
            double r = 0.2 + RND.nextDouble() * 0.3;
            q.x = o.x + Math.cos(a) * r;
            q.z = o.z + Math.sin(a) * r;
            q.y = o.y + 0.05 + RND.nextDouble() * 0.5;
            q.vy = 0.8 + RND.nextDouble() * 0.9;
            q.vx = (RND.nextDouble() - 0.5) * 0.2;
            q.vz = (RND.nextDouble() - 0.5) * 0.2;
            q.life = 0.6F + RND.nextFloat() * 0.5F;
            q.size = 0.07F + RND.nextFloat() * 0.06F;
            q.c1 = 16769126;
            q.c2 = 16726544;
            break;
         }
         case "water": {
            double r = 0.15 + RND.nextDouble() * 0.45;
            q.x = o.x + Math.cos(a) * r;
            q.z = o.z + Math.sin(a) * r;
            q.y = o.y + 1.6 + RND.nextDouble() * 0.6;
            q.vy = -0.2;
            q.vx = Math.cos(a) * 0.15;
            q.vz = Math.sin(a) * 0.15;
            q.life = 1.1F + RND.nextFloat() * 0.5F;
            q.size = 0.05F + RND.nextFloat() * 0.04F;
            q.c1 = 8376575;
            q.c2 = 3111935;
            q.kind = 1;
            break;
         }
         case "ender":
         case "magic":
         case "rainbow":
            q.kind = 2;
            q.r = 0.5F + RND.nextFloat() * 0.35F;
            q.rot = (float)a;
            q.spin = (RND.nextBoolean() ? 1 : -1) * (1.6F + RND.nextFloat() * 1.4F);
            q.ox = (float)o.x;
            q.oz = (float)o.z;
            q.y = o.y + 0.1 + RND.nextDouble() * 0.5;
            q.vy = 0.35 + RND.nextDouble() * 0.5;
            q.life = 1.5F + RND.nextFloat() * 0.8F;
            q.size = k.equals("magic") ? 0.1F : 0.07F;
            if (k.equals("ender")) {
               q.c1 = 14704895;
               q.c2 = 8003536;
            } else if (k.equals("magic")) {
               q.c1 = 15249663;
               q.c2 = 6970623;
               q.kind = 3;
            } else {
               q.c1 = -1;
               q.c2 = -1;
            }
            break;
         case "heart":
            q.x = o.x + (RND.nextDouble() - 0.5) * 0.9;
            q.z = o.z + (RND.nextDouble() - 0.5) * 0.9;
            q.y = o.y + 1.7 + RND.nextDouble() * 0.5;
            q.vy = 0.45 + RND.nextDouble() * 0.2;
            q.life = 1.5F;
            q.size = 0.2F + RND.nextFloat() * 0.06F;
            q.c1 = 16726876;
            q.c2 = 16752560;
            q.kind = 4;
            q.rot = 0.0F;
            q.spin = (RND.nextFloat() - 0.5F) * 2.0F;
            break;
         case "snow": {
            double r = Math.sqrt(RND.nextDouble()) * 1.4;
            q.x = o.x + Math.cos(a) * r;
            q.z = o.z + Math.sin(a) * r;
            q.y = o.y + 2.2 + RND.nextDouble() * 0.7;
            q.vy = -(0.55 + RND.nextDouble() * 0.35);
            q.life = 3.0F;
            q.size = 0.045F + RND.nextFloat() * 0.035F;
            q.c1 = 16777215;
            q.c2 = 13625599;
            q.kind = 5;
            q.spin = RND.nextFloat() * 6.0F;
            break;
         }
         case "smoke": {
            double r = 0.15 + RND.nextDouble() * 0.3;
            q.x = o.x + Math.cos(a) * r;
            q.z = o.z + Math.sin(a) * r;
            q.y = o.y + 0.1 + RND.nextDouble() * 0.7;
            q.vy = 0.4 + RND.nextDouble() * 0.4;
            q.vx = (RND.nextDouble() - 0.5) * 0.25;
            q.vz = (RND.nextDouble() - 0.5) * 0.25;
            q.life = 1.4F + RND.nextFloat() * 0.8F;
            q.size = 0.1F;
            q.c1 = 6974070;
            q.c2 = 2763315;
            q.kind = 6;
            break;
         }
         case "electric":
            q.kind = 7;
            q.life = 0.14F + RND.nextFloat() * 0.1F;
            q.size = 0.025F;
            double bx = o.x + (RND.nextDouble() - 0.5) * 0.9;
            double by = o.y + 0.2 + RND.nextDouble() * 1.4;
            double bz = o.z + (RND.nextDouble() - 0.5) * 0.9;
            q.bolt = new double[18];
            double dx = (RND.nextDouble() - 0.5) * 0.35;
            double dy = (RND.nextDouble() - 0.5) * 0.5;
            double dz = (RND.nextDouble() - 0.5) * 0.35;

            for (int i = 0; i < 6; i++) {
               q.bolt[i * 3] = bx + dx * i + (RND.nextDouble() - 0.5) * 0.14;
               q.bolt[i * 3 + 1] = by + dy * i + (RND.nextDouble() - 0.5) * 0.14;
               q.bolt[i * 3 + 2] = bz + dz * i + (RND.nextDouble() - 0.5) * 0.14;
            }

            q.c1 = 16777215;
            q.c2 = 5818623;
            q.x = bx;
            q.y = by;
            q.z = bz;
            break;
         case "aura":
            q.kind = RND.nextInt(3) == 0 ? 3 : 2;
            q.r = 0.55F + RND.nextFloat() * 0.3F;
            q.rot = (float)a;
            q.spin = (RND.nextBoolean() ? 1 : -1) * (2.2F + RND.nextFloat() * 1.6F);
            q.ox = (float)o.x;
            q.oz = (float)o.z;
            q.y = o.y + 0.05 + RND.nextDouble() * 0.3;
            q.vy = 0.9 + RND.nextDouble() * 0.7;
            q.life = 1.3F + RND.nextFloat() * 0.6F;
            q.size = 0.075F;
            q.c1 = RND.nextBoolean() ? 14721279 : 11562239;
            q.c2 = 5909456;
            break;
         case "trail":
            q.x = o.x + (RND.nextDouble() - 0.5) * 0.3;
            q.z = o.z + (RND.nextDouble() - 0.5) * 0.3;
            q.y = o.y + 0.08 + RND.nextDouble() * 0.15;
            q.vy = 0.08 + RND.nextDouble() * 0.12;
            q.vx = (RND.nextDouble() - 0.5) * 0.1;
            q.vz = (RND.nextDouble() - 0.5) * 0.1;
            q.life = 0.8F + RND.nextFloat() * 0.5F;
            q.size = 0.09F + RND.nextFloat() * 0.05F;
            q.c1 = 10481919;
            q.c2 = 3111935;
            break;
         default: {
            double r = Math.sqrt(RND.nextDouble()) * 1.5;
            q.x = o.x + Math.cos(a) * r;
            q.z = o.z + Math.sin(a) * r;
            q.y = o.y + 2.2 + RND.nextDouble() * 0.8;
            q.vy = -(0.35 + RND.nextDouble() * 0.3);
            q.life = 4.0F;
            q.size = 0.08F + RND.nextFloat() * 0.04F;
            int[] cs = new int[]{4180810, 7265356, 10940522, 3055162};
            q.c1 = cs[RND.nextInt(cs.length)];
            q.c2 = 3055162;
            q.kind = 8;
            q.spin = (RND.nextFloat() - 0.5F) * 5.0F;
         }
      }

      return q;
   }

   private static void step(CosmeticRenderer.Pt q, String k, float dt, Vec3d o) {
      float f = q.age / q.life;
      switch (q.kind) {
         case 1:
            q.vy -= 3.5 * dt;
            q.x = q.x + q.vx * dt;
            q.y = q.y + q.vy * dt;
            q.z = q.z + q.vz * dt;
            if (q.y < o.y + 0.02) {
               q.age = q.life;
            }
            break;
         case 2:
         case 3:
            q.rot = q.rot + q.spin * dt;
            q.x = o.x + Math.cos(q.rot) * q.r;
            q.z = o.z + Math.sin(q.rot) * q.r;
            q.y = q.y + q.vy * dt;
            break;
         case 4:
            q.x = q.x + Math.sin(q.age * 3.0F + q.spin) * 0.25 * dt;
            q.y = q.y + q.vy * dt;
            break;
         case 5:
            q.x = q.x + Math.sin(q.age * 1.7 + q.spin) * 0.15 * dt;
            q.z = q.z + Math.cos(q.age * 1.3 + q.spin) * 0.15 * dt;
            q.y = q.y + q.vy * dt;
            break;
         case 6:
         default:
            q.x = q.x + q.vx * dt;
            q.y = q.y + q.vy * dt;
            q.z = q.z + q.vz * dt;
         case 7:
            break;
         case 8:
            q.x = q.x + Math.sin(q.age * 1.4 + q.spin) * 0.5 * dt;
            q.z = q.z + Math.cos(q.age * 1.1 + q.spin) * 0.5 * dt;
            q.y = q.y + q.vy * dt;
            q.rot = q.rot + q.spin * dt;
      }
   }

   private static int mix(int c1, int c2, float t) {
      int r = (int)((c1 >> 16 & 0xFF) * (1.0F - t) + (c2 >> 16 & 0xFF) * t);
      int g = (int)((c1 >> 8 & 0xFF) * (1.0F - t) + (c2 >> 8 & 0xFF) * t);
      int b = (int)((c1 & 0xFF) * (1.0F - t) + (c2 & 0xFF) * t);
      return r << 16 | g << 8 | b;
   }

   private static void drawPt(VertexConsumer vc, Matrix4f m, CosmeticRenderer.Pt q, String k, double rx, double ry, double rz, double ux, double uy, double uz) {
      float f = q.age / q.life;
      float a = 1.0F;
      float size = q.size;
      int rgb;
      if (q.c1 == -1) {
         rgb = MathHelper.hsvToRgb((time * 0.4F + q.rot * 0.16F + f * 0.5F) % 1.0F, 0.7F, 1.0F);
      } else {
         rgb = mix(q.c1, q.c2, f);
      }
      a = switch (q.kind) {
         case 0 -> {
            size *= 1.0F - 0.8F * f;
            yield 0.95F;
         }
         default -> Math.min(1.0F, (1.0F - f) * 4.0F);
         case 2, 3 -> Math.min(1.0F, Math.min(f * 6.0F, (1.0F - f) * 3.0F));
         case 4 -> Math.min(1.0F, (1.0F - f) * 2.2F);
         case 5 -> Math.min(1.0F, (1.0F - f) * 3.0F);
         case 6 -> {
            size = q.size * (1.0F + f * 3.2F);
            yield 0.5F * (1.0F - f);
         }
         case 7 -> 1.0F - f;
      };
      if (!(a <= 0.01F)) {
         int r = rgb >> 16 & 0xFF;
         int g = rgb >> 8 & 0xFF;
         int b = rgb & 0xFF;
         int al = (int)(a * 255.0F);
         switch (q.kind) {
            case 3:
               plus(vc, m, q.x, q.y, q.z, size, rx, rz, ux, uy, uz, r, g, b, al);
               break;
            case 4:
               heart(vc, m, q, size, rx, rz, ux, uy, uz, r, g, b, al);
               break;
            case 5:
               plus(vc, m, q.x, q.y, q.z, size, rx, rz, ux, uy, uz, r, g, b, al);
               break;
            case 6:
            default:
               bq(vc, m, q.x, q.y, q.z, size, size, 1.0, 0.0, rx, rz, ux, uy, uz, r, g, b, al);
               break;
            case 7:
               bolt(vc, m, q, rx, rz, ux, uy, uz, al);
               break;
            case 8:
               double c = Math.cos(q.rot);
               double s = Math.sin(q.rot);
               bq(vc, m, q.x, q.y, q.z, size * 1.4F, size * 0.8F, c, s, rx, rz, ux, uy, uz, r, g, b, al);
         }
      }
   }

   private static void bq(
      VertexConsumer vc,
      Matrix4f m,
      double x,
      double y,
      double z,
      float hw,
      float hh,
      double c,
      double s,
      double rx,
      double rz,
      double ux,
      double uy,
      double uz,
      int r,
      int g,
      int b,
      int a
   ) {
      double ax = (rx * c + ux * s) * hw;
      double ay = uy * s * hw;
      double az = (rz * c + uz * s) * hw;
      double bx = (ux * c - rx * s) * hh;
      double by = uy * c * hh;
      double bz = (uz * c - rz * s) * hh;
      vc.vertex(m, (float)(x - ax - bx), (float)(y - ay - by), (float)(z - az - bz)).color(r, g, b, a);
      vc.vertex(m, (float)(x + ax - bx), (float)(y + ay - by), (float)(z + az - bz)).color(r, g, b, a);
      vc.vertex(m, (float)(x + ax + bx), (float)(y + ay + by), (float)(z + az + bz)).color(r, g, b, a);
      vc.vertex(m, (float)(x - ax + bx), (float)(y - ay + by), (float)(z - az + bz)).color(r, g, b, a);
   }

   private static void plus(
      VertexConsumer vc, Matrix4f m, double x, double y, double z, float s, double rx, double rz, double ux, double uy, double uz, int r, int g, int b, int a
   ) {
      bq(vc, m, x, y, z, s * 0.35F, s * 0.35F, 1.0, 0.0, rx, rz, ux, uy, uz, 255, 255, 255, a);
      bq(vc, m, x, y, z, s, s * 0.22F, 1.0, 0.0, rx, rz, ux, uy, uz, r, g, b, a);
      bq(vc, m, x, y, z, s * 0.22F, s, 1.0, 0.0, rx, rz, ux, uy, uz, r, g, b, a);
   }

   private static void heart(
      VertexConsumer vc, Matrix4f m, CosmeticRenderer.Pt q, float size, double rx, double rz, double ux, double uy, double uz, int r, int g, int b, int a
   ) {
      float cell = size / 3.5F;

      for (int row = 0; row < HEART.length; row++) {
         for (int col = 0; col < 7; col++) {
            if (HEART[row].charAt(col) == 'X') {
               double ox = (col - 3) * cell;
               double oy = (2.5 - row) * cell;
               double cx = q.x + rx * ox + ux * oy;
               double cy = q.y + uy * oy;
               double cz = q.z + rz * ox + uz * oy;
               boolean hi = row == 1 && col < 3;
               bq(vc, m, cx, cy, cz, cell * 0.5F, cell * 0.5F, 1.0, 0.0, rx, rz, ux, uy, uz, hi ? 255 : r, hi ? 190 : g, hi ? 200 : b, a);
            }
         }
      }
   }

   private static void bolt(VertexConsumer vc, Matrix4f m, CosmeticRenderer.Pt q, double rx, double rz, double ux, double uy, double uz, int a) {
      double[] bp = q.bolt;

      for (int i = 0; i < 5; i++) {
         double ax = bp[i * 3];
         double ay = bp[i * 3 + 1];
         double az = bp[i * 3 + 2];
         double bx = bp[i * 3 + 3];
         double by = bp[i * 3 + 4];
         double bz = bp[i * 3 + 5];
         double dx = bx - ax;
         double dy = by - ay;
         double dz = bz - az;
         double dr = dx * rx + dz * rz;
         double du = dx * ux + dy * uy + dz * uz;
         double sx = -du * rx + dr * ux;
         double sy = dr * uy;
         double sz = -du * rz + dr * uz;
         double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
         if (!(sl < 1.0E-6)) {
            double w = 0.022 / sl;
            sx *= w;
            sy *= w;
            sz *= w;

            for (int pass = 0; pass < 2; pass++) {
               double k = pass == 0 ? 2.2 : 1.0;
               int r = pass == 0 ? 90 : 255;
               int g = pass == 0 ? 200 : 255;
               int b = 255;
               int al = pass == 0 ? a / 2 : a;
               vc.vertex(m, (float)(ax - sx * k), (float)(ay - sy * k), (float)(az - sz * k)).color(r, g, b, al);
               vc.vertex(m, (float)(ax + sx * k), (float)(ay + sy * k), (float)(az + sz * k)).color(r, g, b, al);
               vc.vertex(m, (float)(bx + sx * k), (float)(by + sy * k), (float)(bz + sz * k)).color(r, g, b, al);
               vc.vertex(m, (float)(bx - sx * k), (float)(by - sy * k), (float)(bz - sz * k)).color(r, g, b, al);
            }
         }
      }
   }

   private static final class Ctx {
      float t;
      float walk;
      float move;
      boolean air;
      boolean sprint;
      float bright = 1.0F;

      private Ctx() {
      }
   }

   private static final class Pt {
      double x;
      double y;
      double z;
      double vx;
      double vy;
      double vz;
      float life;
      float age;
      float size;
      float rot;
      float spin;
      float a;
      float r;
      float ox;
      float oy;
      float oz;
      int c1;
      int c2;
      int kind;
      double[] bolt;

      private Pt() {
      }
   }

   private static final class Rig {
      float lightSmooth = 1.0F;
      Vec3d petPos;
      float petYaw;
      float petWalk;
      float petMove;
      float petVy;
      float petY;
      boolean petMoving;
      Object petWorld;
      final List<CosmeticRenderer.Pt> pts = new ArrayList<>();
      float spawnAcc;
      long seen;

      private Rig() {
      }
   }

   private static final class Wing {
      Cosmetic w;
      Matrix4f m;
      boolean sneak;
      boolean chest;
      CosmeticRenderer.Ctx c;

      private Wing() {
      }
   }
}

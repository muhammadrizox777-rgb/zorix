package com.dexvisual.cosmetics;

import java.util.List;

public final class Cosmetic {
   public String cat;
   public String id;
   public String name;
   public String tex;
   public String fx;
   public int[] ic;
   public List<Cosmetic.Part> parts;
   public float tw;
   public float rx;
   public float ry;
   public float hover;
   public float size;
   public float[] ha;
   public float hs;

   public Cosmetic() {
   }

   public int c1() {
      return this.ic != null && this.ic.length > 0 ? this.ic[0] : 16777215;
   }

   public int c2() {
      return this.ic != null && this.ic.length > 1 ? this.ic[1] : this.c1();
   }

   public static final class Part {
      public float[] p;
      public String an;
      public int ax;
      public float amp;
      public float fq;
      public float ph;
      public float[][] b;

      public Part() {
      }
   }
}

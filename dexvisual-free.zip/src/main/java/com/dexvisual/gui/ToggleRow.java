package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.util.Gfx;
import com.dexvisual.util.I18n;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.client.gui.DrawContext;

public class ToggleRow extends W {
   private final int icon;
   private final String title;
   private final String desc;
   private final BooleanSupplier get;
   private final Consumer<Boolean> set;
   private float anim = -1.0F;

   public ToggleRow(int icon, String title, String desc, BooleanSupplier get, Consumer<Boolean> set) {
      this.icon = icon;
      this.title = title;
      this.desc = desc;
      this.get = get;
      this.set = set;
      this.h = 28;
   }

   @Override
   public void render(DrawContext c, int mx, int my) {
      boolean on = this.get.getAsBoolean();
      if (this.anim < 0.0F) {
         this.anim = on ? 1.0F : 0.0F;
      }

      this.anim = UiClock.approach(this.anim, on ? 1.0F : 0.0F, 22.0F);
      if (this.hover(mx, my)) {
         Gfx.rrect(c, this.x, this.y, this.w, this.h, 6, Theme.hover());
      }

      int t = Theme.rgb(Theme.a1());
      Gfx.rrect(c, this.x + 2, this.y + 2, 24, 24, 7, Gfx.argb(t, 0.18F), Gfx.argb(t, 0.08F));
      Gfx.rborder(c, this.x + 2, this.y + 2, 24, 24, 7, 1, Gfx.argb(t, 0.35F));
      int cx = this.x + 14;
      int cy = this.y + 14;
      int g = Gfx.ga(-1648385);
      switch (this.icon) {
         case 0:
            c.fill(cx - 1, cy - 6, cx + 1, cy + 6, g);
            c.fill(cx - 6, cy - 1, cx + 6, cy + 1, g);
            c.fill(cx - 3, cy - 3, cx + 3, cy + 3, g);
            c.fill(cx - 1, cy - 1, cx + 1, cy + 1, Gfx.ga(-15462616));
            break;
         case 1:
            c.fill(cx - 6, cy - 2, cx - 3, cy + 2, g);
            c.fill(cx - 3, cy - 4, cx - 1, cy + 4, g);
            c.fill(cx + 1, cy - 3, cx + 2, cy + 3, g);
            c.fill(cx + 3, cy - 5, cx + 4, cy + 5, g);
            break;
         default:
            for (int r = 0; r < 3; r++) {
               Gfx.rborder(c, cx - 7 + r * 2, cy - 5 + r * 2, 14 - r * 4, 14 - r * 4, 7 - r * 2, 1, -1648385);
            }

            c.fill(cx - 8, cy + 3, cx + 8, cy + 8, Gfx.ga(-15462616));
      }

      Gfx.text(c, Widgets.fit(I18n.tr(this.title), this.w - 90), this.x + 34, this.y + 5, Theme.text(), false);
      Gfx.text(c, Widgets.fit(I18n.tr(this.desc), this.w - 90), this.x + 34, this.y + 16, Theme.muted(), false);
      int sw = 28;
      int sh = 14;
      int rx = this.x + this.w - sw - 8;
      int ry = this.y + (this.h - sh) / 2;
      if (on) {
         Gfx.glow(c, rx, ry, sw, sh, 7, t, 0.5F);
      }

      Gfx.rrect(c, rx, ry, sw, sh, 7, Gfx.lerp(Theme.track(), Theme.a1(), this.anim));
      Gfx.rrect(c, rx + 2 + Math.round(this.anim * (sw - sh)), ry + 2, sh - 4, sh - 4, 5, -1);
   }

   @Override
   public boolean click(int mx, int my, int b) {
      this.set.accept(!this.get.getAsBoolean());
      DexConfig.markDirty();
      return true;
   }
}

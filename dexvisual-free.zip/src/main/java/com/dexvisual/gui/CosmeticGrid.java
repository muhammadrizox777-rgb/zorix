package com.dexvisual.gui;

import com.dexvisual.cosmetics.Cosmetic;
import com.dexvisual.cosmetics.Cosmetics;
import com.dexvisual.util.Gfx;
import java.util.List;
import net.minecraft.client.gui.DrawContext;

public class CosmeticGrid extends W {
   private static final int COLS = 5;
   private static final int TH = 42;
   private static final int GAP = 4;
   private final List<Cosmetic> items;
   private final String cat;
   private final Runnable changed;

   public CosmeticGrid(String cat, Runnable changed) {
      this.cat = cat;
      this.changed = changed;
      this.items = Cosmetics.byCat(cat);
      int rows = Math.max(1, (this.items.size() + 5 - 1) / 5);
      this.h = rows * 46 - 4;
   }

   private int tw() {
      return (this.w - 16) / 5;
   }

   @Override
   public void render(DrawContext c, int mx, int my) {
      int tw = this.tw();
      int t = Theme.rgb(Theme.a1());

      for (int i = 0; i < this.items.size(); i++) {
         Cosmetic it = this.items.get(i);
         int tx = this.x + i % 5 * (tw + 4);
         int ty = this.y + i / 5 * 46;
         boolean on = Cosmetics.isSelected(it);
         boolean hv = Gfx.in(mx, my, tx, ty, tw, 42);
         int top = on ? Gfx.argb(t, 0.28F) : (hv ? 620756991 : 318767103);
         int bot = on ? Gfx.argb(t, 0.1F) : 150994943;
         if (on) {
            Gfx.glow(c, tx, ty, tw, 42, 8, t, 0.5F);
         }

         Gfx.rrect(c, tx, ty, tw, 42, 8, top, bot);
         Gfx.rborder(c, tx, ty, tw, 42, 8, 1, on ? Gfx.argb(t, 0.8F) : 486539263);
         int c1 = 0xFF000000 | it.c1();
         int c2 = 0xFF000000 | it.c2();
         int ix = tx + tw / 2 - 9;
         int iy = ty + 5;
         Gfx.rrect(c, ix, iy, 18, 18, 6, c1, c2);
         this.glyph(c, ix + 9, iy + 9);
         Gfx.textC(c, Widgets.fit(it.name, tw - 6), tx + tw / 2, ty + 42 - 14, on ? -1 : (hv ? -2038544 : -5854016), false);
         if (on) {
            Gfx.textC(c, "ON", tx + tw / 2, ty + 42 - 6, Theme.a1(), false);
         }
      }
   }

   private void glyph(DrawContext c, int cx, int cy) {
      int w = Gfx.ga(-419430401);
      int s = Gfx.ga(1426063360);
      String var6 = this.cat;
      switch (var6) {
         case "wings":
            for (int k = 0; k < 4; k++) {
               c.fill(cx - 7 + k, cy - 3 + k, cx - 1, cy - 2 + k, w);
               c.fill(cx + 1, cy - 3 + k, cx + 7 - k, cy - 2 + k, w);
            }
            break;
         case "hats":
            c.fill(cx - 6, cy + 2, cx + 6, cy + 4, w);
            c.fill(cx - 3, cy - 4, cx + 3, cy + 2, w);
            break;
         case "capes":
            c.fill(cx - 5, cy - 5, cx + 5, cy - 3, w);
            c.fill(cx - 4, cy - 3, cx + 4, cy + 5, w);
            c.fill(cx - 1, cy - 1, cx + 1, cy + 2, s);
            break;
         case "swords":
            for (int k = 0; k < 9; k++) {
               c.fill(cx - 5 + k, cy + 4 - k, cx - 3 + k, cy + 6 - k, w);
            }

            c.fill(cx + 1, cy - 5, cx + 6, cy - 3, w);
            break;
         case "skins":
            c.fill(cx - 3, cy - 5, cx + 3, cy, w);
            c.fill(cx - 5, cy - 1, cx + 5, cy + 1, w);
            c.fill(cx - 3, cy + 1, cx + 3, cy + 6, w);
            break;
         case "killfx":
            c.fill(cx - 1, cy - 6, cx + 1, cy + 6, w);
            c.fill(cx - 6, cy - 1, cx + 6, cy + 1, w);
            c.fill(cx - 3, cy - 3, cx + 3, cy + 3, s);
            c.fill(cx - 1, cy - 1, cx + 1, cy + 1, w);
            break;
         case "petacc":
            c.fill(cx - 5, cy - 1, cx - 1, cy + 3, w);
            c.fill(cx + 1, cy - 1, cx + 5, cy + 3, w);
            c.fill(cx - 1, cy, cx + 1, cy + 2, s);
            break;
         case "colors":
         case "crowns":
            c.fill(cx - 5, cy + 1, cx + 5, cy + 4, w);
            c.fill(cx - 5, cy - 3, cx - 3, cy + 1, w);
            c.fill(cx - 1, cy - 5, cx + 1, cy + 1, w);
            c.fill(cx + 3, cy - 3, cx + 5, cy + 1, w);
            break;
         case "pets":
            c.fill(cx - 4, cy - 2, cx + 4, cy + 5, w);
            c.fill(cx - 5, cy - 5, cx - 2, cy - 2, w);
            c.fill(cx + 2, cy - 5, cx + 5, cy - 2, w);
            c.fill(cx - 2, cy, cx - 1, cy + 1, s);
            c.fill(cx + 1, cy, cx + 2, cy + 1, s);
            break;
         case "backpacks":
            c.fill(cx - 4, cy - 4, cx + 4, cy + 5, w);
            c.fill(cx - 2, cy + 1, cx + 2, cy + 4, s);
            c.fill(cx - 2, cy - 6, cx + 2, cy - 4, w);
            break;
         default:
            c.fill(cx - 5, cy - 4, cx - 3, cy - 2, w);
            c.fill(cx + 2, cy - 2, cx + 4, cy, w);
            c.fill(cx - 2, cy + 1, cx, cy + 3, w);
            c.fill(cx + 3, cy + 4, cx + 5, cy + 6, w);
            c.fill(cx - 6, cy + 3, cx - 5, cy + 4, w);
      }
   }

   @Override
   public boolean click(int mx, int my, int btn) {
      int tw = this.tw();

      for (int i = 0; i < this.items.size(); i++) {
         int tx = this.x + i % 5 * (tw + 4);
         int ty = this.y + i / 5 * 46;
         if (Gfx.in(mx, my, tx, ty, tw, 42)) {
            Cosmetics.toggle(this.items.get(i));
            if (this.changed != null) {
               this.changed.run();
            }

            return true;
         }
      }

      return false;
   }
}

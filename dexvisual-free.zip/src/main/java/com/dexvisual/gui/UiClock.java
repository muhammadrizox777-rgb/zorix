package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.module.Modules;
import com.dexvisual.util.Motion;

public final class UiClock {
   public static float dt = 0.016666668F;
   private static final long[] LAST = new long[]{0L};

   private UiClock() {
   }

   public static void tick() {
      dt = Motion.dt(LAST);
   }

   public static void reset() {
      LAST[0] = 0L;
      dt = 0.016666668F;
   }

   public static boolean animated() {
      return DexConfig.get().menuAnim && !Modules.optimizing();
   }

   public static boolean reduced() {
      return DexConfig.get().ui.reducedMotion;
   }

   public static float approach(float cur, float target, float speed) {
      return Motion.approach(cur, target, dt, reduced() ? speed * 1.6F : speed, animated());
   }
}

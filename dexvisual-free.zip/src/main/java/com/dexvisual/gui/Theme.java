package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.UiSettings;
import com.dexvisual.util.ColorUtil;

public final class Theme {
   public static final String[] ACCENT_NAMES = new String[]{"Blue", "Purple", "Cyan", "Pink"};
   public static final int TEXT = -1512459;
   public static final int MUTED = -7696218;
   public static final int HOVER = 520093695;
   public static final int LINE = 587202559;
   public static final int TRACK = -14012867;
   public static int override = -1;

   private Theme() {
   }

   private static UiSettings ui() {
      return DexConfig.get().ui;
   }

   private static int base() {
      return override >= 0 ? override : DexConfig.get().themeColor;
   }

   public static int a1() {
      return 0xFF000000 | base() & 16777215;
   }

   public static int a2() {
      int custom = ui().accent2;
      if (custom >= 0 && override < 0) {
         return 0xFF000000 | custom;
      } else {
         float[] hsv = ColorUtil.toHsv(base());
         return 0xFF000000 | ColorUtil.hsv((hsv[0] + 0.12F) % 1.0F, Math.max(hsv[1], 0.5F), Math.max(hsv[2], 0.8F));
      }
   }

   public static int rgb(int argb) {
      return argb & 16777215;
   }

   public static int sidebarRgb() {
      int c = ui().sidebarColor;
      return c >= 0 ? c : MenuSkin.current().bg1();
   }

   public static int panelRgb() {
      int c = ui().panelColor;
      return c >= 0 ? c : MenuSkin.current().bg2();
   }

   public static int backdropRgb() {
      int c = ui().bgColor;
      return c >= 0 ? c : 197642;
   }

   public static int cardRgb() {
      return ColorUtil.mix(panelRgb(), 0, 0.35F);
   }

   public static int cardInnerRgb() {
      return ColorUtil.mix(panelRgb(), 16777215, 0.04F);
   }

   public static int text() {
      int c = ui().textColor;
      return 0xFF000000 | (c >= 0 ? ColorUtil.readable(c, panelRgb(), 4.0) : 15264757);
   }

   public static int muted() {
      int c = ui().mutedColor;
      return 0xFF000000 | (c >= 0 ? ColorUtil.readable(c, panelRgb(), 3.0) : 9080998);
   }

   public static int disabled() {
      int d = ColorUtil.mix(muted() & 16777215, panelRgb(), 0.45F);
      return 0xFF000000 | (ColorUtil.contrast(d, panelRgb()) >= 2.0 ? d : muted() & 16777215);
   }

   public static int line() {
      int c = ui().borderColor;
      return c >= 0 ? 1140850688 | c : 587202559;
   }

   public static int border() {
      int c = ui().borderColor;
      return c >= 0 ? 1711276032 | c : 352321535;
   }

   public static int selected() {
      int c = ui().selectedColor;
      return 0xFF000000 | (c >= 0 ? c : a1() & 16777215);
   }

   public static int hover() {
      return 520093695;
   }

   public static int track() {
      return -14012867;
   }

   public static int resolve(int argb) {
      if (argb == -1512459) {
         return text();
      } else {
         return argb == -7696218 ? muted() : argb;
      }
   }

   public static boolean verticalGradient() {
      UiSettings u = ui();
      return u.gradient && u.gradientDir < 2;
   }

   public static int gradFrom() {
      UiSettings u = ui();
      return !u.gradient || u.gradientDir != 1 && u.gradientDir != 3 ? a1() : a2();
   }

   public static int gradTo() {
      UiSettings u = ui();
      return u.gradient ? (u.gradientDir != 1 && u.gradientDir != 3 ? a2() : a1()) : a1();
   }
}

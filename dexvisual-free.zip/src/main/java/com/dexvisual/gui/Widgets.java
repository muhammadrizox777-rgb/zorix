package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.util.ColorUtil;
import com.dexvisual.util.Gfx;
import com.dexvisual.util.I18n;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.InputUtil;

public final class Widgets {
   private Widgets() {
   }

   public static String fit(String s, int maxW) {
      if (Gfx.tw(s) <= maxW) {
         return s;
      } else {
         while (s.length() > 1 && Gfx.tw(s + "...") > maxW) {
            s = s.substring(0, s.length() - 1);
         }

         return s + "...";
      }
   }

   public static class Block extends W {
      private final Widgets.Painter p;

      public Block(int h, Widgets.Painter p) {
         this.h = h;
         this.p = p;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         this.p.paint(c, this.x, this.y, this.w, this.h, mx, my);
      }
   }

   public static class Button extends W {
      private final String label;
      private final Runnable action;
      private final int style;

      public Button(String label, int style, Runnable action) {
         this.label = label;
         this.style = style;
         this.action = action;
         this.h = 18;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         boolean hv = this.hover(mx, my);
         if (this.style == 1) {
            if (hv) {
               Gfx.glow(c, this.x, this.y, this.w, this.h, 5, Theme.rgb(Theme.a1()), 0.7F);
            }

            Gfx.gradFill(c, this.x, this.y, this.w, this.h, 5, Theme.gradFrom(), Theme.gradTo(), DexConfig.get().ui.gradientDir & 1);
         } else if (this.style == 2) {
            Gfx.rrect(c, this.x, this.y, this.w, this.h, 5, hv ? -860343734 : 1723347530);
         } else {
            Gfx.rrect(c, this.x, this.y, this.w, this.h, 5, hv ? 822083583 : 419430399);
            Gfx.rborder(c, this.x, this.y, this.w, this.h, 5, 1, hv ? Gfx.argb(Theme.rgb(Theme.a1()), 0.7F) : 587202559);
         }

         Gfx.textC(c, Widgets.fit(I18n.tr(this.label), this.w - 6), this.x + this.w / 2, this.y + (this.h - 8) / 2, -1, false);
      }

      @Override
      public boolean click(int mx, int my, int b) {
         this.action.run();
         return true;
      }
   }

   public static class ColorEditor extends W {
      private final String label;
      private final IntSupplier get;
      private final IntSupplier shown;
      private final IntConsumer set;
      private final Runnable reset;
      private final Widgets.Input hex = new Widgets.Input("#RRGGBB", null);
      private float[] hsv = new float[]{0.0F, 0.0F, 1.0F};
      private int synced = Integer.MIN_VALUE;
      private int drag = -1;
      private static final int PAL_N = 16;

      public ColorEditor(String label, IntSupplier get, IntSupplier shown, IntConsumer set, Runnable reset) {
         this.label = label;
         this.get = get;
         this.shown = shown;
         this.set = set;
         this.reset = reset;
         this.h = 66;
         this.hex.max = 7;
         this.hex.filter = ch -> ch == 35 || Character.digit(ch, 16) >= 0;
      }

      private int cur() {
         return this.shown.getAsInt() & 16777215;
      }

      private boolean auto() {
         return this.get.getAsInt() < 0;
      }

      private int hexW() {
         return 58;
      }

      private int autoW() {
         return this.reset == null ? 0 : 34;
      }

      private void emit(int rgb) {
         this.synced = rgb & 16777215;
         this.set.accept(this.synced);
         DexConfig.markDirty();
      }

      private int barY(int i) {
         return this.y + 28 + i * 11;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         int cur = this.cur();
         if (cur != this.synced) {
            this.hsv = ColorUtil.toHsv(cur);
            this.synced = cur;
         }

         int rx = this.x + this.w - 6;
         if (this.reset != null) {
            int bw = this.autoW() - 4;
            int bx = rx - bw;
            boolean a = this.auto();
            Gfx.rrect(c, bx, this.y + 1, bw, 12, 4, a ? Gfx.argb(Theme.rgb(Theme.selected()), 0.45F) : 587202559);
            Gfx.textC(c, I18n.tr("Auto"), bx + bw / 2, this.y + 3, a ? -1 : Theme.muted(), false);
            rx -= this.autoW();
         }

         this.hex.x = rx - this.hexW();
         this.hex.y = this.y + 1;
         this.hex.w = this.hexW();
         this.hex.h = 13;
         if (Widgets.Input.focused != this.hex) {
            this.hex.sb.setLength(0);
            this.hex.sb.append(ColorUtil.toHex(cur));
            this.hex.invalid = false;
         } else {
            String ht = this.hex.sb.toString().trim();
            int digits = ht.startsWith("#") ? ht.length() - 1 : ht.length();
            int v = digits == 6 ? ColorUtil.parseHex(ht) : -1;
            this.hex.invalid = digits >= 6 && v < 0;
            if (v >= 0 && v != cur) {
               this.emit(v);
               this.hsv = ColorUtil.toHsv(v);
               cur = v;
            }
         }

         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.hex.x - this.x - 30), this.x + 6, this.y + 3, Theme.text(), false);
         Gfx.rrect(c, this.hex.x - 22, this.y + 2, 18, 10, 3, 0xFF000000 | cur);
         Gfx.rborder(c, this.hex.x - 22, this.y + 2, 18, 10, 3, 1, 1442840575);
         this.hex.render(c, mx, my);
         int s = Math.max(6, Math.min(10, (this.w - 12) / 16 - 1));

         for (int i = 0; i < 16; i++) {
            int sx = this.x + 6 + i * (s + 1);
            Gfx.rrect(c, sx, this.y + 17, s, s, 2, 0xFF000000 | Widgets.ColorPick.PAL[i]);
            if (Widgets.ColorPick.PAL[i] == cur) {
               Gfx.rborder(c, sx - 1, this.y + 16, s + 2, s + 2, 2, 1, -1);
            }
         }

         int bw = this.w - 12;

         for (int b = 0; b < 3; b++) {
            int by = this.barY(b);

            for (int ix = 0; ix < bw; ix += 3) {
               float t = (float)ix / Math.max(1, bw - 1);
               int col = b == 0
                  ? ColorUtil.hsv(t, 1.0F, 1.0F)
                  : (b == 1 ? ColorUtil.hsv(this.hsv[0], t, Math.max(0.35F, this.hsv[2])) : ColorUtil.hsv(this.hsv[0], this.hsv[1], t));
               c.fill(this.x + 6 + ix, by, this.x + 6 + Math.min(bw, ix + 3), by + 8, Gfx.ga(0xFF000000 | col));
            }

            Gfx.rborder(c, this.x + 6, by, bw, 8, 0, 1, 872415231);
            float p = b == 0 ? this.hsv[0] : (b == 1 ? this.hsv[1] : this.hsv[2]);
            Gfx.rrect(c, this.x + 6 + Math.round(p * (bw - 1)) - 1, by - 1, 3, 10, 1, -1);
         }
      }

      private void bar(int mx) {
         float t = MathHelper.clamp((float)(mx - (this.x + 6)) / Math.max(1, this.w - 13), 0.0F, 1.0F);
         if (this.drag == 0) {
            this.hsv[0] = Math.min(t, 0.999F);
         } else if (this.drag == 1) {
            this.hsv[1] = t;
         } else {
            this.hsv[2] = t;
         }

         this.emit(ColorUtil.hsv(this.hsv[0], this.hsv[1], this.hsv[2]));
         if (this.drag == 0 && this.hsv[1] < 0.01F) {
            this.hsv[1] = 1.0F;
         }
      }

      @Override
      public boolean click(int mx, int my, int b) {
         if (this.reset != null && Gfx.in(mx, my, this.x + this.w - 6 - (this.autoW() - 4), this.y + 1, this.autoW() - 4, 12)) {
            this.reset.run();
            this.synced = Integer.MIN_VALUE;
            return true;
         } else if (Gfx.in(mx, my, this.hex.x, this.hex.y, this.hex.w, this.hex.h)) {
            Widgets.Input.focused = this.hex;
            return true;
         } else {
            for (int i = 0; i < 3; i++) {
               if (my >= this.barY(i) - 1 && my < this.barY(i) + 9) {
                  this.drag = i;
                  this.bar(mx);
                  return true;
               }
            }

            int s = Math.max(6, Math.min(10, (this.w - 12) / 16 - 1));
            int ix = (mx - (this.x + 6)) / (s + 1);
            if (my >= this.y + 16 && my < this.y + 17 + s + 1 && ix >= 0 && ix < 16) {
               this.emit(Widgets.ColorPick.PAL[ix]);
               return true;
            } else {
               return true;
            }
         }
      }

      @Override
      public boolean drag(int mx, int my) {
         if (this.drag >= 0) {
            this.bar(mx);
         }

         return this.drag >= 0;
      }

      @Override
      public void release() {
         this.drag = -1;
      }
   }

   public static class ColorPick extends W {
      static final int[] PAL = new int[]{
         16777215, 13159640, 8423316, 0, 16731501, 16747085, 16762967, 16773197, 4652980, 5111660, 4184319, 7113983, 10513663, 16739508, 16728048, 724244
      };
      private final String label;
      private final IntSupplier get;
      private final IntConsumer set;
      private boolean hueDrag;

      public ColorPick(String label, IntSupplier get, IntConsumer set) {
         this.label = label;
         this.get = get;
         this.set = set;
         this.h = 42;
      }

      static int hsv(float h, float s, float v) {
         int i = (int)Math.floor(h * 6.0F);
         float f = h * 6.0F - i;
         float p = v * (1.0F - s);
         float q = v * (1.0F - f * s);
         float t = v * (1.0F - (1.0F - f) * s);
         float r;
         float g;
         float b;
         switch (Math.floorMod(i, 6)) {
            case 0:
               r = v;
               g = t;
               b = p;
               break;
            case 1:
               r = q;
               g = v;
               b = p;
               break;
            case 2:
               r = p;
               g = v;
               b = t;
               break;
            case 3:
               r = p;
               g = q;
               b = v;
               break;
            case 4:
               r = t;
               g = p;
               b = v;
               break;
            default:
               r = v;
               g = p;
               b = q;
         }

         return (int)(r * 255.0F) << 16 | (int)(g * 255.0F) << 8 | (int)(b * 255.0F);
      }

      private int sz() {
         return Math.max(6, Math.min(11, (this.w - 12) / PAL.length - 1));
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         int cur = this.get.getAsInt() & 16777215;
         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.w - 40), this.x + 6, this.y + 3, Theme.text(), false);
         Gfx.rrect(c, this.x + this.w - 28, this.y + 2, 22, 9, 3, 0xFF000000 | cur);
         Gfx.rborder(c, this.x + this.w - 28, this.y + 2, 22, 9, 3, 1, 1442840575);
         int s = this.sz();

         for (int i = 0; i < PAL.length; i++) {
            int sx = this.x + 6 + i * (s + 1);
            Gfx.rrect(c, sx, this.y + 15, s, s, 2, 0xFF000000 | PAL[i]);
            if (PAL[i] == cur) {
               Gfx.rborder(c, sx - 1, this.y + 14, s + 2, s + 2, 2, 1, -1);
            }
         }

         int bw = this.w - 12;

         for (int ix = 0; ix < bw; ix += 2) {
            c.fill(this.x + 6 + ix, this.y + 29, this.x + 8 + ix, this.y + 37, Gfx.ga(0xFF000000 | hsv((float)ix / bw, 1.0F, 1.0F)));
         }

         Gfx.rborder(c, this.x + 6, this.y + 29, bw, 8, 0, 1, 872415231);
      }

      private void hue(int mx) {
         float hh = MathHelper.clamp((float)(mx - (this.x + 6)) / (this.w - 12), 0.0F, 0.999F);
         this.set.accept(hsv(hh, 1.0F, 1.0F));
         DexConfig.markDirty();
      }

      @Override
      public boolean click(int mx, int my, int b) {
         if (my >= this.y + 28) {
            this.hueDrag = true;
            this.hue(mx);
            return true;
         } else {
            int s = this.sz();
            int i = (mx - (this.x + 6)) / (s + 1);
            if (my >= this.y + 14 && i >= 0 && i < PAL.length) {
               this.set.accept(PAL[i]);
               DexConfig.markDirty();
            }

            return true;
         }
      }

      @Override
      public boolean drag(int mx, int my) {
         if (this.hueDrag) {
            this.hue(mx);
         }

         return this.hueDrag;
      }

      @Override
      public void release() {
         this.hueDrag = false;
      }
   }

   public static class Heading extends W {
      private final String t;

      public Heading(String t) {
         this.t = t;
         this.h = 18;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         String u = I18n.tr(this.t).toUpperCase(Locale.ROOT);
         Gfx.text(c, u, this.x + 2, this.y + 6, Theme.a1(), false);
         int tw = Gfx.tw(u);
         Gfx.rrect(c, this.x + tw + 8, this.y + 10, Math.max(0, this.w - tw - 8), 1, 0, Theme.line());
      }
   }

   public static class Input extends W {
      public static Widgets.Input focused;
      public final StringBuilder sb = new StringBuilder();
      private final String hint;
      private final Runnable enter;
      public int max = 24;
      public IntPredicate filter;
      public boolean invalid;

      public Input(String hint, Runnable enter) {
         this.hint = hint;
         this.enter = enter;
         this.h = 18;
      }

      public String text() {
         return this.sb.toString().trim();
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         boolean f = focused == this;
         Gfx.rrect(c, this.x, this.y, this.w, this.h, 5, 587202559);
         Gfx.rborder(c, this.x, this.y, this.w, this.h, 5, 1, this.invalid ? -45715 : (f ? Theme.selected() : 587202559));
         String s = this.sb.toString();
         if (s.isEmpty() && !f) {
            Gfx.text(c, Widgets.fit(I18n.tr(this.hint), this.w - 12), this.x + 6, this.y + 5, Theme.muted(), false);
         } else {
            Gfx.text(c, Widgets.fit(s, this.w - 16) + (f && System.currentTimeMillis() / 500L % 2L == 0L ? "_" : ""), this.x + 6, this.y + 5, -1, false);
         }
      }

      @Override
      public boolean click(int mx, int my, int b) {
         focused = this;
         return true;
      }

      public static boolean type(char ch) {
         if (focused == null) {
            return false;
         } else {
            if (ch >= ' ' && ch != 127 && focused.sb.length() < focused.max && (focused.filter == null || focused.filter.test(ch))) {
               focused.sb.append(ch);
            }

            return true;
         }
      }

      public static boolean key(int key, int mods) {
         Widgets.Input f = focused;
         if (f == null) {
            return false;
         } else {
            if (key == 259) {
               if (f.sb.length() > 0) {
                  f.sb.deleteCharAt(f.sb.length() - 1);
               }
            } else if (key != 257 && key != 335) {
               if (key == 256) {
                  focused = null;
               } else if (key == 86 && (mods & 2) != 0) {
                  String cb = MinecraftClient.getInstance().keyboard.getClipboard();
                  if (cb != null) {
                     for (char ch : cb.toCharArray()) {
                        if (ch >= ' ' && f.sb.length() < f.max && (f.filter == null || f.filter.test(ch))) {
                           f.sb.append(ch);
                        }
                     }
                  }
               }
            } else if (f.enter != null) {
               f.enter.run();
            }

            return true;
         }
      }
   }

   public static class KeyBind extends W {
      public static Widgets.KeyBind listening;
      private final String label;
      private final IntSupplier get;
      private final IntConsumer set;

      public KeyBind(String label, IntSupplier get, IntConsumer set) {
         this.label = label;
         this.get = get;
         this.set = set;
         this.h = 18;
      }

      public static String keyName(int k) {
         if (k < 0) {
            return I18n.tr("None");
         } else {
            try {
               return InputUtil.fromKeyCode(k, -1).getLocalizedText().getString();
            } catch (Exception var2) {
               return "Key " + k;
            }
         }
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         if (this.hover(mx, my)) {
            Gfx.rrect(c, this.x, this.y, this.w, this.h, 4, Theme.hover());
         }

         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.w - 90), this.x + 6, this.y + 5, Theme.text(), false);
         boolean l = listening == this;
         int bw = 76;
         int bx = this.x + this.w - bw - 4;
         Gfx.rrect(c, bx, this.y + 2, bw, this.h - 4, 4, l ? Gfx.argb(Theme.rgb(Theme.a1()), 0.35F) : 587202559);
         Gfx.rborder(c, bx, this.y + 2, bw, this.h - 4, 4, 1, l ? Theme.a1() : 587202559);
         Gfx.textC(c, l ? I18n.tr("Press key...") : Widgets.fit(keyName(this.get.getAsInt()), bw - 6), bx + bw / 2, this.y + 5, -1, false);
      }

      @Override
      public boolean click(int mx, int my, int b) {
         listening = this;
         return true;
      }

      public void accept(int key) {
         this.set.accept(key);
         DexConfig.markDirty();
         listening = null;
      }
   }

   public static class Label extends W {
      private final String t;
      private final int col;

      public Label(String t, int col) {
         this.t = t;
         this.col = col;
         this.h = 12;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         Gfx.text(c, Widgets.fit(I18n.tr(this.t), this.w - 2), this.x + 2, this.y + 2, Theme.resolve(this.col), false);
      }
   }

   public interface Painter {
      void paint(DrawContext var1, int var2, int var3, int var4, int var5, int var6, int var7);
   }

   public static class Select extends W {
      private final String label;
      private final String[] opts;
      private final IntSupplier get;
      private final IntConsumer set;

      public Select(String label, String[] opts, IntSupplier get, IntConsumer set) {
         this.label = label;
         this.opts = opts;
         this.get = get;
         this.set = set;
         this.h = 18;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         if (this.hover(mx, my)) {
            Gfx.rrect(c, this.x, this.y, this.w, this.h, 4, Theme.hover());
         }

         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.w / 2 - 4), this.x + 6, this.y + 5, Theme.text(), false);
         int i = Math.floorMod(this.get.getAsInt(), this.opts.length);
         Gfx.textR(c, Widgets.fit("< " + I18n.tr(this.opts[i]) + " >", this.w / 2 - 4), this.x + this.w - 6, this.y + 5, Theme.selected(), false);
      }

      @Override
      public boolean click(int mx, int my, int b) {
         int i = Math.floorMod(this.get.getAsInt() + (b == 1 ? -1 : 1), this.opts.length);
         this.set.accept(i);
         DexConfig.markDirty();
         return true;
      }
   }

   public static class Slider extends W {
      private final String label;
      private final String fmt;
      private final float min;
      private final float max;
      private final Supplier<Float> get;
      private final Consumer<Float> set;
      private final boolean integer;
      private boolean dragging;

      public Slider(String label, float min, float max, Supplier<Float> get, Consumer<Float> set, String fmt, boolean integer) {
         this.label = label;
         this.min = min;
         this.max = max;
         this.get = get;
         this.set = set;
         this.fmt = fmt;
         this.integer = integer;
         this.h = 24;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         float v = this.get.get();
         if (Float.isNaN(v)) {
            v = this.min;
         }

         String vs = this.integer ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, this.fmt, v);
         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.w - 60), this.x + 6, this.y + 3, Theme.text(), false);
         Gfx.textR(c, vs, this.x + this.w - 6, this.y + 3, Theme.muted(), false);
         int tx = this.x + 6;
         int tw = this.w - 12;
         int ty = this.y + 16;
         float pct = MathHelper.clamp((v - this.min) / (this.max - this.min), 0.0F, 1.0F);
         int fw = (int)(tw * pct);
         Gfx.rrect(c, tx, ty, tw, 4, 2, -14539728);
         if (fw > 0) {
            int t = Theme.rgb(Theme.a1());
            Gfx.rrect(c, tx, ty, fw, 4, 2, 0xFF000000 | t);
         }

         int thumbX = tx + fw - 6;
         Gfx.rrect(c, thumbX, ty - 4, 12, 12, 6, -1);
      }

      private void apply(int mx) {
         float pct = MathHelper.clamp((float)(mx - (this.x + 6)) / (this.w - 12), 0.0F, 1.0F);
         float v = this.min + pct * (this.max - this.min);
         if (this.integer) {
            v = Math.round(v);
         }

         this.set.accept(v);
         DexConfig.markDirty();
      }

      @Override
      public boolean click(int mx, int my, int b) {
         this.dragging = true;
         this.apply(mx);
         return true;
      }

      @Override
      public boolean drag(int mx, int my) {
         if (this.dragging) {
            this.apply(mx);
         }

         return this.dragging;
      }

      @Override
      public void release() {
         this.dragging = false;
      }
   }

   public static class Toggle extends W {
      private final String label;
      private final BooleanSupplier get;
      private final Consumer<Boolean> set;
      private float anim = -1.0F;

      public Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
         this.label = label;
         this.get = get;
         this.set = set;
         this.h = 18;
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         boolean on = this.get.getAsBoolean();
         if (this.anim < 0.0F) {
            this.anim = on ? 1.0F : 0.0F;
         }

         this.anim = UiClock.approach(this.anim, on ? 1.0F : 0.0F, 22.0F);
         Gfx.text(c, Widgets.fit(I18n.tr(this.label), this.w - 50), this.x + 6, this.y + 5, Theme.text(), false);
         int t = Theme.rgb(Theme.a1());
         int tw = 34;
         int th = 20;
         int tx = this.x + this.w - tw - 6;
         int ty = this.y + (this.h - th) / 2;
         int tBg = Gfx.lerp(-14539728, 0xFF000000 | t, this.anim);
         Gfx.rrect(c, tx, ty, tw, th, th / 2, tBg);
         if (!on) {
            Gfx.rborder(c, tx, ty, tw, th, th / 2, 1, -13289402);
         }

         int kx = tx + 2 + (int)((tw - 20) * this.anim);
         Gfx.rrect(c, kx, ty + 2, 16, 16, 8, -1);
         if (this.anim > 0.01F) {
            Gfx.glow(c, tx, ty, tw, th, th / 2, t, 0.5F * this.anim);
         }
      }

      @Override
      public boolean click(int mx, int my, int b) {
         this.set.accept(!this.get.getAsBoolean());
         DexConfig.markDirty();
         return true;
      }
   }
}

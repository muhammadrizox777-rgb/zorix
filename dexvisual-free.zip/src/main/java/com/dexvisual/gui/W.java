package com.dexvisual.gui;

import java.util.function.BooleanSupplier;
import net.minecraft.client.gui.DrawContext;

public abstract class W {
   public int x;
   public int y;
   public int w;
   public int h = 18;
   public BooleanSupplier disabled;

   public W() {
   }

   public final boolean off() {
      return this.disabled != null && this.disabled.getAsBoolean();
   }

   public W disabledIf(BooleanSupplier d) {
      this.disabled = d;
      return this;
   }

   public abstract void render(DrawContext var1, int var2, int var3);

   public boolean click(int mx, int my, int btn) {
      return false;
   }

   public boolean drag(int mx, int my) {
      return false;
   }

   public void release() {
   }

   public boolean hover(int mx, int my) {
      return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
   }
}

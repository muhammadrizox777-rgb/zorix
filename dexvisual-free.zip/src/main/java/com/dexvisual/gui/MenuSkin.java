package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;

public record MenuSkin(String name, int accent, int bg1, int bg2, float alpha, boolean stars, boolean custom) {
   public static final MenuSkin[] ALL = new MenuSkin[]{
      new MenuSkin("Default", 691455, 790037, 2303533, 1.0F, false, false),
      new MenuSkin("Neon", 2282478, 267292, 469558, 1.0F, false, false),
      new MenuSkin("Dark Red", 15680580, 1574409, 2820624, 1.0F, false, false),
      new MenuSkin("Galaxy", 12616956, 722212, 2756429, 1.0F, true, false),
      new MenuSkin("Transparent", 8238335, 1053727, 1712176, 0.55F, false, false),
      new MenuSkin("Custom", 0, 790037, 2303533, 1.0F, false, true),
      new MenuSkin("Onyx Premium", 16777215, 328965, 921102, 0.9F, false, false),
      new MenuSkin("Diamond HUD", 4388323, 72228, 140595, 0.8F, true, false),
      new MenuSkin("Crimson Pro", 16722474, 1310977, 3015170, 1.0F, false, false)
   };

   public static MenuSkin current() {
      return ALL[Math.floorMod(DexConfig.get().menuSkin, ALL.length)];
   }

   public int accentRgb() {
      return !this.custom && !DexConfig.get().ui.themeAccent ? this.accent : DexConfig.get().themeColor & 16777215;
   }
}

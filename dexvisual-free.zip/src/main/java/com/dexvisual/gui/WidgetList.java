package com.dexvisual.gui;

import com.dexvisual.util.Gfx;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;

public class WidgetList {
   public int x;
   public int y;
   public int w;
   public int h;
   public float scroll = 0.0F;
   public final List<W> items = new ArrayList<>();
   private int cy = 0;
   private W active;
   private static final int PAD = 4;

   public WidgetList(int x, int y, int w, int h) {
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
   }

   public <T extends W> T add(T wd) {
      wd.x = 4;
      wd.y = this.cy;
      wd.w = this.w - 8 - 4;
      this.cy = this.cy + wd.h + 3;
      this.items.add(wd);
      return wd;
   }

   public void addRow(W a, W b) {
      int half = (this.w - 8 - 4 - 4) / 2;
      a.x = 4;
      a.y = this.cy;
      a.w = half;
      b.x = 4 + half + 4;
      b.y = this.cy;
      b.w = half;
      this.cy = this.cy + Math.max(a.h, b.h) + 3;
      this.items.add(a);
      this.items.add(b);
   }

   public void addRow(W... ws) {
      int n = ws.length;
      int cw = (this.w - 8 - 4 - (n - 1) * 4) / n;
      int hh = 0;

      for (int i = 0; i < n; i++) {
         ws[i].x = 4 + i * (cw + 4);
         ws[i].y = this.cy;
         ws[i].w = cw;
         hh = Math.max(hh, ws[i].h);
         this.items.add(ws[i]);
      }

      this.cy += hh + 3;
   }

   public void addGrid(int cols, int gap, List<? extends W> ws) {
      int cell = (this.w - 8 - 4 - (cols - 1) * gap) / cols;

      for (int i = 0; i < ws.size(); i += cols) {
         int hh = 0;

         for (int k = 0; k < cols && i + k < ws.size(); k++) {
            W a = ws.get(i + k);
            a.x = 4 + k * (cell + gap);
            a.y = this.cy;
            a.w = cell;
            hh = Math.max(hh, a.h);
            this.items.add(a);
         }

         this.cy += hh + gap;
      }
   }

   public void gap(int g) {
      this.cy += g;
   }

   public boolean inside(int mx, int my) {
      return Gfx.in(mx, my, this.x, this.y, this.w, this.h);
   }

   private float minScroll() {
      return -Math.max(0, this.cy - this.h);
   }

   public void render(DrawContext c, int mx, int my) {
      this.scroll = MathHelper.clamp(this.scroll, this.minScroll(), 0.0F);
      c.enableScissor(this.x, this.y, this.x + this.w, this.y + this.h);
      MatrixStack ms = c.getMatrices();
      ms.push();
      ms.translate(this.x, this.y + (int)this.scroll, 0.0F);
      boolean in = this.inside(mx, my);
      int lx = in ? mx - this.x : -9999;
      int ly = in ? my - this.y - (int)this.scroll : -9999;

      for (W wd : this.items) {
         if (!(wd.y + wd.h < -this.scroll - 2.0F) && !(wd.y > -this.scroll + this.h + 2.0F)) {
            if (wd.off()) {
               float keep = Gfx.alpha;
               Gfx.alpha = keep * 0.4F;
               wd.render(c, -9999, -9999);
               Gfx.alpha = keep;
            } else {
               wd.render(c, lx, ly);
            }
         }
      }

      ms.pop();
      c.disableScissor();
      if (this.cy > this.h) {
         float vis = (float)this.h / this.cy;
         int bh = Math.max(14, (int)(this.h * vis));
         int by = this.y + (int)(-this.scroll / (this.cy - this.h) * (this.h - bh));
         Gfx.rrect(c, this.x + this.w - 3, by, 2, bh, 1, 1157627903);
      }
   }

   public int contentHeight() {
      return this.cy;
   }

   public boolean click(int mx, int my, int btn) {
      if (!this.inside(mx, my)) {
         return false;
      } else {
         Widgets.Input.focused = null;
         int lx = mx - this.x;
         int ly = my - this.y - (int)this.scroll;

         for (int i = this.items.size() - 1; i >= 0; i--) {
            W wd = this.items.get(i);
            if (wd.hover(lx, ly)) {
               if (wd.off()) {
                  return true;
               }

               if (wd.click(lx, ly, btn)) {
                  this.active = wd;
                  return true;
               }
            }
         }

         return false;
      }
   }

   public boolean drag(int mx, int my) {
      if (this.active == null) {
         return false;
      } else {
         this.active.drag(mx - this.x, my - this.y - (int)this.scroll);
         return true;
      }
   }

   public void release() {
      if (this.active != null) {
         this.active.release();
      }

      this.active = null;
   }

   public boolean scroll(double mx, double my, double amount) {
      if (!this.inside((int)mx, (int)my)) {
         return false;
      } else {
         this.scroll = MathHelper.clamp(this.scroll + (float)amount * 16.0F, this.minScroll(), 0.0F);
         return true;
      }
   }
}

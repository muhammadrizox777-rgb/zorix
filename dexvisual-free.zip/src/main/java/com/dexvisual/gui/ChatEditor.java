package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.hud.HudRenderer;
import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.util.Gfx;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseRelease;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseScroll;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.screen.Screen;

public final class ChatEditor {
   private static HudModule drag;
   private static boolean resizing;
   private static int offX;
   private static int offY;
   private static int guideX = -1;
   private static int guideY = -1;

   private ChatEditor() {
   }

   public static void hook(Screen screen) {
      drag = null;
      resizing = false;
      guideY = -1;
      guideX = -1;
      ScreenEvents.afterRender(screen).register((AfterRender)(s, ctx, mx, my, td) -> render(s, ctx, mx, my));
      ScreenMouseEvents.allowMouseClick(screen).register((AllowMouseClick)(s, mx, my, btn) -> !click((int)mx, (int)my, btn));
      ScreenMouseEvents.allowMouseRelease(screen).register((AllowMouseRelease)(s, mx, my, btn) -> !release());
      ScreenMouseEvents.allowMouseScroll(screen).register((AllowMouseScroll)(s, mx, my, h, v) -> !scroll((int)mx, (int)my, v));
   }

   private static HudModule hit(MinecraftClient mc, int mx, int my) {
      for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
         HudModule m = Modules.ALL.get(i);
         if (m.box && m.cfg().enabled) {
            int[] b = HudRenderer.boxOrPreview(m, mc);
            if (b != null && Gfx.in(mx, my, b[0] - 2, b[1] - 2, b[2] + 6, b[3] + 6)) {
               return m;
            }
         }
      }

      return null;
   }

   private static boolean click(int mx, int my, int btn) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (btn == 0 && DexConfig.get().hudVisible) {
         HudModule m = hit(mc, mx, my);
         if (m == null) {
            return false;
         } else {
            int[] b = HudRenderer.boxOrPreview(m, mc);
            drag = m;
            resizing = Gfx.in(mx, my, b[0] + b[2] - 8, b[1] + b[3] - 8, 12, 12);
            offX = mx - b[0];
            offY = my - b[1];
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean release() {
      if (drag == null) {
         return false;
      } else {
         drag = null;
         resizing = false;
         guideY = -1;
         guideX = -1;
         DexConfig.markDirty();
         return true;
      }
   }

   private static boolean scroll(int mx, int my, double v) {
      MinecraftClient mc = MinecraftClient.getInstance();
      HudModule m = DexConfig.get().hudVisible ? hit(mc, mx, my) : null;
      if (m == null) {
         return false;
      } else {
         ModuleSettings s = m.cfg();
         s.scale = MathHelper.clamp(s.scale + (v > 0.0 ? 0.1F : -0.1F), 0.5F, 3.0F);
         DexConfig.markDirty();
         return true;
      }
   }

   private static void render(Screen s, DrawContext c, int mx, int my) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int w = s.width;
      int h = s.height;
      if (DexConfig.get().hudVisible) {
         if (drag != null) {
            update(mc, mx, my, w, h);
         }

         HudRenderer.renderGhosts(c, mc);
         int t = Theme.rgb(Theme.a1());

         for (HudModule m : Modules.ALL) {
            if (m.box && m.cfg().enabled) {
               int[] b = HudRenderer.boxOrPreview(m, mc);
               if (b != null) {
                  if (m == drag) {
                     Gfx.glow(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, 0, 0.6F);
                     Gfx.rrect(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, -1879048192);
                     Gfx.glow(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, t, 0.5F);
                     Gfx.rborder(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, 1, Theme.a1());
                     Gfx.rrect(c, b[0], b[1] - 18, Gfx.tw(m.name) + 20, 16, 6, -805306368);
                     c.drawTexture(
                        RenderLayer::getGuiTextured,
                        Identifier.of("dexvisual", "textures/gui/mod_" + m.id + ".png"),
                        b[0] + 4,
                        b[1] - 16,
                        0.0F,
                        0.0F,
                        12,
                        12,
                        12,
                        12
                     );
                     Gfx.text(c, m.name, b[0] + 18, b[1] - 14, Theme.a1(), true);
                  } else {
                     boolean hv = drag == null && Gfx.in(mx, my, b[0] - 2, b[1] - 2, b[2] + 6, b[3] + 6);
                     if (hv) {
                        Gfx.glow(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, 0, 0.5F);
                        Gfx.rrect(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, 1610612736);
                        Gfx.rborder(c, b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, 6, 1, -1996488705);
                        Gfx.rrect(c, b[0], b[1] - 18, Gfx.tw(m.name) + 20, 16, 6, -1342177280);
                        c.drawTexture(
                           RenderLayer::getGuiTextured,
                           Identifier.of("dexvisual", "textures/gui/mod_" + m.id + ".png"),
                           b[0] + 4,
                           b[1] - 16,
                           0.0F,
                           0.0F,
                           12,
                           12,
                           12,
                           12
                        );
                        Gfx.text(c, m.name, b[0] + 18, b[1] - 14, -1, true);
                     } else {
                        Gfx.rborder(c, b[0], b[1], b[2], b[3], 4, 1, 553648127);
                     }
                  }

                  Gfx.rrect(
                     c,
                     b[0] + b[2] - 3,
                     b[1] + b[3] - 3,
                     6,
                     6,
                     3,
                     m == drag ? -1 : (drag == null && Gfx.in(mx, my, b[0] + b[2] - 8, b[1] + b[3] - 8, 16, 16) ? -5592406 : 1442840575)
                  );
               }
            }
         }

         if (drag != null && DexConfig.get().guides) {
            if (guideX >= 0) {
               c.fill(guideX, 0, guideX + 1, h, Gfx.argb(Theme.rgb(Theme.a2()), 0.8F));
            }

            if (guideY >= 0) {
               c.fill(0, guideY, w, guideY + 1, Gfx.argb(Theme.rgb(Theme.a2()), 0.8F));
            }
         }

         Gfx.glow(c, w / 2 - 140, 4, 280, 22, 11, 0, 0.6F);
         Gfx.rrect(c, w / 2 - 140, 4, 280, 22, 11, -1610612736);
         Gfx.textC(c, "HUD Editor: drag, corner, scroll", w / 2, 11, -1, true);
      }
   }

   private static void update(MinecraftClient mc, int mx, int my, int w, int h) {
      ModuleSettings s = drag.cfg();
      int[] b = HudRenderer.boxOrPreview(drag, mc);
      if (b != null) {
         if (resizing) {
            s.scale = MathHelper.clamp((float)(mx - b[0]) / b[4], 0.5F, 3.0F);
         } else {
            int nx = mx - offX;
            int ny = my - offY;
            guideY = -1;
            guideX = -1;
            if (DexConfig.get().snap) {
               int sd = DexConfig.get().snapDist;
               int[] xs = new int[]{0, (w - b[2]) / 2, w - b[2]};
               int[] ys = new int[]{0, (h - b[3]) / 2, h - b[3]};

               for (int v : xs) {
                  if (Math.abs(nx - v) <= sd) {
                     nx = v;
                     guideX = v == 0 ? 0 : (v == xs[1] ? w / 2 : w - 1);
                  }
               }

               for (int vx : ys) {
                  if (Math.abs(ny - vx) <= sd) {
                     ny = vx;
                     guideY = vx == 0 ? 0 : (vx == ys[1] ? h / 2 : h - 1);
                  }
               }
            }

            s.x = MathHelper.clamp((float)nx / w, 0.0F, 1.0F);
            s.y = MathHelper.clamp((float)ny / h, 0.0F, 1.0F);
         }

         DexConfig.markDirty();
      }
   }
}

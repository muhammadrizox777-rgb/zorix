package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.util.Gfx;
import com.dexvisual.util.I18n;
import net.minecraft.client.gui.DrawContext;

public class SkinPicker extends W {
   private static final int COLS = 3;
   private static final int TH = 40;
   private static final int ROW = 52;
   private static final int GAP = 5;
   private static final int PV = 104;
   private final Runnable changed;

   public SkinPicker(Runnable changed) {
      this.changed = changed;
      int rows = (MenuSkin.ALL.length + 3 - 1) / 3;
      this.h = rows * 52 + 5;
   }

   private boolean preview() {
      return this.w >= 330;
   }

   private int gridW() {
      return this.preview() ? this.w - 104 - 8 : this.w;
   }

   private int tw() {
      return (this.gridW() - 10) / 3;
   }

   @Override
   public void render(DrawContext c, int mx, int my) {
      int tw = this.tw();
      int cur = Math.floorMod(DexConfig.get().menuSkin, MenuSkin.ALL.length);

      for (int i = 0; i < MenuSkin.ALL.length; i++) {
         MenuSkin s = MenuSkin.ALL[i];
         int tx = this.x + i % 3 * (tw + 5);
         int ty = this.y + i / 3 * 57;
         boolean on = i == cur;
         boolean hv = Gfx.in(mx, my, tx, ty, tw, 40);
         int acc = s.custom() ? s.accentRgb() : s.accent();
         if (on) {
            Gfx.glow(c, tx, ty, tw, 40, 7, acc, 0.7F);
         }

         Gfx.rrect(c, tx, ty, tw, 40, 7, Gfx.argb(s.bg1(), s.alpha() < 1.0F ? 0.7F : 1.0F), Gfx.argb(s.bg2(), s.alpha() < 1.0F ? 0.55F : 1.0F));
         Gfx.rborder(c, tx, ty, tw, 40, 7, 1, on ? Gfx.argb(acc, 1.0F) : (hv ? 1728053247 : 872415231));
         if (s.custom()) {
            int ix = tx + tw / 2 - 7;
            int iy = ty + 8;
            Gfx.rborder(c, ix, iy, 14, 11, 2, 1, -4606762);
            c.fill(ix + 3, iy + 7, ix + 6, iy + 9, Gfx.ga(-4606762));
            c.fill(ix + 6, iy + 5, ix + 10, iy + 9, Gfx.ga(-4606762));
            Gfx.textC(c, Widgets.fit(I18n.tr("Your style"), tw - 4), tx + tw / 2, ty + 25, -6643528, false);
         } else {
            for (int r = 0; r < 3; r++) {
               int ry = ty + 8 + r * 9;
               Gfx.rrect(c, tx + 7, ry, 5, 5, 2, Gfx.argb(acc, 1.0F));
               Gfx.rrect(c, tx + 16, ry + 1, Math.max(6, tw - 30 - r * 6), 3, 1, Gfx.argb(acc, 0.55F));
            }

            if (s.stars()) {
               for (int k = 0; k < 9; k++) {
                  c.fill(tx + 5 + k * 23 % (tw - 8), ty + 3 + k * 11 % 34, tx + 6 + k * 23 % (tw - 8), ty + 4 + k * 11 % 34, Gfx.ga(-1711276033));
               }
            }
         }

         if (on) {
            Gfx.rrect(c, tx + tw - 13, ty + 3, 10, 10, 5, Gfx.argb(acc, 1.0F));
            int bx = tx + tw - 11;
            int by = ty + 6;
            int wc = Gfx.ga(-1);
            c.fill(bx, by + 2, bx + 1, by + 3, wc);
            c.fill(bx + 1, by + 3, bx + 2, by + 4, wc);
            c.fill(bx + 2, by + 2, bx + 3, by + 3, wc);
            c.fill(bx + 3, by + 1, bx + 4, by + 2, wc);
            c.fill(bx + 4, by, bx + 5, by + 1, wc);
         }

         Gfx.text(c, Widgets.fit(I18n.tr(s.name()), tw - 4), tx + 3, ty + 40 + 4, on ? -1 : -6643528, false);
      }

      if (this.preview()) {
         this.drawPreview(c, this.x + this.gridW() + 8, this.y);
      }
   }

   private void drawPreview(DrawContext c, int px, int py) {
      MenuSkin s = MenuSkin.current();
      int t = Theme.rgb(Theme.a1());
      Gfx.rrect(c, px, py, 104, this.h, 8, Gfx.argb(s.bg1(), s.alpha() < 1.0F ? 0.7F : 1.0F), Gfx.argb(s.bg2(), s.alpha() < 1.0F ? 0.55F : 1.0F));
      Gfx.rborder(c, px, py, 104, this.h, 8, 1, Gfx.argb(t, 0.8F));
      c.getMatrices().push();
      c.getMatrices().translate(px + 8, py + 7, 0.0F);
      c.getMatrices().scale(0.8F, 0.8F, 1.0F);
      Gfx.text(c, "DEX", 0, 0, -1, true);
      Gfx.text(c, "VISUAL", Gfx.tw("DEX "), 0, Theme.a1(), true);
      c.getMatrices().pop();

      for (int i = 0; i < MenuScreen.NAV.length; i++) {
         int ry = py + 22 + i * 11;
         boolean act = MenuScreen.NAV[i].equals("Cosmetics");
         if (act) {
            Gfx.rrect(c, px + 5, ry - 1, 94, 10, 4, Gfx.argb(t, 0.85F), Gfx.argb(t, 0.5F));
         }

         c.getMatrices().push();
         c.getMatrices().translate(px + 10, ry, 0.0F);
         c.getMatrices().scale(0.75F, 0.75F, 1.0F);
         Gfx.text(c, I18n.tr(MenuScreen.NAV[i]), 0, 0, act ? -1 : -6643528, false);
         c.getMatrices().pop();
      }

      c.getMatrices().push();
      c.getMatrices().translate(px + 8, py + this.h - 10, 0.0F);
      c.getMatrices().scale(0.7F, 0.7F, 1.0F);
      Gfx.text(c, "v" + MenuScreen.version(), 0, 0, -9472372, false);
      c.getMatrices().pop();
   }

   @Override
   public boolean click(int mx, int my, int btn) {
      int tw = this.tw();

      for (int i = 0; i < MenuSkin.ALL.length; i++) {
         int tx = this.x + i % 3 * (tw + 5);
         int ty = this.y + i / 3 * 57;
         if (Gfx.in(mx, my, tx, ty, tw, 52)) {
            DexConfig.get().menuSkin = i;
            DexConfig.get().ui.themeAccent = false;
            DexConfig.markDirty();
            if (this.changed != null) {
               this.changed.run();
            }

            return true;
         }
      }

      return false;
   }
}

package com.dexvisual.gui;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.util.KillFx;

public final class ModulePanel {
   static final String[] ANIMS = new String[]{"NONE", "FADE", "SLIDE", "POP"};

   private ModulePanel() {
   }

   public static int animIndex(String a) {
      for (int i = 0; i < ANIMS.length; i++) {
         if (ANIMS[i].equals(a)) {
            return i;
         }
      }

      return 3;
   }

   public static void build(WidgetList l, HudModule m, Runnable rebuild) {
      l.add(new Widgets.Toggle("Enabled", () -> m.cfg().enabled, v -> Modules.set(m, v)));
      if (m.box) {
         l.add(new Widgets.Slider("Scale", 0.5F, 3.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Opacity", 0.1F, 1.0F, () -> m.cfg().opacity, v -> m.cfg().opacity = v, "%.2f", false));
         if (m.container) {
            l.add(new Widgets.Toggle("Background", () -> m.cfg().background, v -> m.cfg().background = v));
            l.add(new Widgets.ColorPick("Background color", () -> m.cfg().bgColor, v -> m.cfg().bgColor = v));
            l.add(new Widgets.Slider("Background opacity", 0.0F, 1.0F, () -> m.cfg().bgOpacity, v -> m.cfg().bgOpacity = v, "%.2f", false));
            l.add(new Widgets.Toggle("Border", () -> m.cfg().border, v -> m.cfg().border = v));
            l.add(new Widgets.ColorPick("Border color", () -> m.cfg().borderColor, v -> {
               m.cfg().borderColor = v;
               m.cfg().ownColor = true;
            }));
            l.add(new Widgets.Slider("Border width", 1.0F, 3.0F, () -> (float)m.cfg().borderWidth, v -> m.cfg().borderWidth = Math.round(v), "%.0f", true));
            l.add(new Widgets.Slider("Corner radius", 0.0F, 10.0F, () -> (float)m.cfg().radius, v -> m.cfg().radius = Math.round(v), "%.0f", true));
         }

         l.add(new Widgets.ColorPick("Text color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
         }));
         l.add(new Widgets.Toggle("Text shadow", () -> m.cfg().shadow, v -> m.cfg().shadow = v));
         l.add(new Widgets.Select("Animation", ANIMS, () -> animIndex(m.cfg().animation), i -> m.cfg().animation = ANIMS[i]));
         l.add(new Widgets.Slider("Position X", 0.0F, 1.0F, () -> m.cfg().x, v -> m.cfg().x = v, "%.3f", false));
         l.add(new Widgets.Slider("Position Y", 0.0F, 1.0F, () -> m.cfg().y, v -> m.cfg().y = v, "%.3f", false));
      } else if (m.id.equals("damage")) {
         l.add(new Widgets.ColorPick("Number color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
         }));
      } else if (m.id.equals("hands")) {
         l.add(new Widgets.Slider("Animation speed", 0.2F, 3.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Light strength", 0.2F, 2.0F, () -> m.cfg().val <= 0.01F ? 1.0F : m.cfg().val, v -> m.cfg().val = v, "%.2fx", false));
         l.add(new Widgets.ColorPick("Outline glow color", () -> m.cfg().ownColor ? m.cfg().textColor : 4063152, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
         }));
         l.add(new Widgets.Label("Hands get an animated cloud aura with your skin preserved.", -7696218));
      } else if (m.id.equals("chinahat")) {
         l.add(new Widgets.Slider("Size", 0.5F, 2.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.ColorPick("Hat color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
            m.cfg().option2 = true;
         }));
         l.add(new Widgets.Label("Cone hat above your head. Switch to third person (F5) to see it.", -7696218));
      } else if (m.id.equals("jumpcircles")) {
         l.add(new Widgets.Slider("Size", 0.5F, 2.5F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Animation speed", 0.4F, 3.0F, () -> m.cfg().val2, v -> m.cfg().val2 = v, "%.1fx", false));
         l.add(new Widgets.ColorPick("Ring color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
            m.cfg().option2 = true;
         }));
         l.add(new Widgets.Label("Ring appears where you jump (only your own jumps).", -7696218));
      } else if (m.id.equals("zoom")) {
         l.add(new Widgets.Slider("Zoom level", 1.5F, 12.0F, () -> m.cfg().val <= 0.01F ? 4.0F : m.cfg().val, v -> m.cfg().val = v, "%.1fx", false));
         l.add(new Widgets.Label("Hold the Zoom key (default C, change it in Controls > DEX VISUAL).", -7696218));
      } else if (m.id.equals("freelook")) {
         l.add(new Widgets.Label("Hold the Freelook key (default Left Alt) and move the mouse: the camera turns, your character does not.", -7696218));
      } else if (m.id.equals("motionblur")) {
         l.add(new Widgets.Slider("Strength", 0.1F, 1.0F, () -> m.cfg().val <= 0.01F ? 0.7F : m.cfg().val, v -> m.cfg().val = v, "%.2f", false));
         l.add(new Widgets.Slider("Turn boost", 0.5F, 2.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Label("Soft trail that grows when you turn the camera fast. The HUD stays sharp. Off while Optimization is on.", -7696218));
      } else if (m.id.equals("killeffect")) {
         l.add(new Widgets.Select("Style", KillFx.STYLES, () -> Math.max(0, Math.min(KillFx.STYLES.length - 1, Math.round(m.cfg().val))), i -> m.cfg().val = i));
         l.add(new Widgets.Slider("Size", 0.5F, 2.5F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Animation speed", 0.4F, 3.0F, () -> m.cfg().val2, v -> m.cfg().val2 = v, "%.1fx", false));
         l.add(new Widgets.Slider("Screen flash", 0.0F, 1.0F, () -> m.cfg().val3, v -> m.cfg().val3 = v, "%.2f", false));
         l.add(new Widgets.ColorPick("Effect color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
            m.cfg().option2 = true;
         }));
         l.add(new Widgets.Button("Test effect", 1, KillFx::test));
         l.add(new Widgets.Label("Plays where you eliminate a player. Test closes the menu and shows it in front of you.", -7696218));
      } else if (m.id.equals("targetesp")) {
         l.add(
            new Widgets.Select(
               "Style", Modules.TargetEspModule.STYLES, () -> Math.max(0, Math.min(Modules.TargetEspModule.STYLES.length - 1, Math.round(m.cfg().val))), i -> {
                  m.cfg().val = i;
                  rebuild.run();
               }
            )
         );
         l.add(new Widgets.Slider("Size", 0.5F, 2.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         if (Math.round(m.cfg().val) == 2) {
            l.add(new Widgets.Slider("Glow intensity", 0.0F, 1.0F, () -> m.cfg().val4, v -> m.cfg().val4 = v, "%.2f", false));
            l.add(new Widgets.Slider("Glow radius", 0.3F, 3.0F, () -> m.cfg().glowRadius, v -> m.cfg().glowRadius = v, "%.1fx", false));
            l.add(new Widgets.Slider("Outline thickness", 1.0F, 6.0F, () -> (float)m.cfg().lineW, v -> m.cfg().lineW = Math.round(v), "%.0f", true));
            l.add(new Widgets.Slider("Animation speed", 0.3F, 3.0F, () -> m.cfg().val2, v -> m.cfg().val2 = v, "%.1fx", false));
            l.add(new Widgets.ColorPick("Glow color", () -> m.cfg().glowColor, v -> m.cfg().glowColor = v));
            l.add(new Widgets.Toggle("Pulse animation", () -> m.cfg().glowPulse, v -> m.cfg().glowPulse = v));
            l.add(new Widgets.Toggle("Health-based colors", () -> m.cfg().glowHealthColor, v -> m.cfg().glowHealthColor = v));
            l.add(new Widgets.Toggle("Show target name", () -> m.cfg().glowName, v -> m.cfg().glowName = v));
            l.add(new Widgets.Toggle("Show target health", () -> m.cfg().glowHealthText, v -> m.cfg().glowHealthText = v));
         } else {
            l.add(new Widgets.Slider("Line thickness", 1.0F, 8.0F, () -> (float)m.cfg().lineW, v -> m.cfg().lineW = Math.round(v), "%.0f", true));
            l.add(new Widgets.Slider("Glow strength", 0.0F, 1.0F, () -> m.cfg().val4, v -> m.cfg().val4 = v, "%.2f", false));
            l.add(new Widgets.Slider("Bracket arm length", 0.25F, 0.95F, () -> m.cfg().val3, v -> m.cfg().val3 = v, "%.2f", false));
            l.add(new Widgets.Slider("Animation speed", 0.3F, 3.0F, () -> m.cfg().val2, v -> m.cfg().val2 = v, "%.1fx", false));
            l.add(new Widgets.ColorPick("Effect color", () -> m.cfg().textColor, v -> {
               m.cfg().textColor = v;
               m.cfg().ownColor = true;
               m.cfg().option2 = true;
            }));
         }

         l.add(new Widgets.Label("Right-click a player to lock the ESP on them.", -7696218));
      } else if (m.id.equals("blockoverlay")) {
         l.add(new Widgets.Slider("Fill opacity", 0.0F, 0.8F, () -> m.cfg().val, v -> m.cfg().val = v, "%.2f", false));
         l.add(new Widgets.ColorPick("Color", () -> m.cfg().textColor, v -> {
            m.cfg().textColor = v;
            m.cfg().ownColor = true;
         }));
      } else if (m.id.equals("artihelper")) {
         l.add(new Widgets.Slider("Trap duration (sec)", 3.0F, 60.0F, () -> m.cfg().val, v -> m.cfg().val = Math.round(v), "%.0f", true));
         l.add(new Widgets.Slider("Plast duration (sec)", 3.0F, 60.0F, () -> m.cfg().val2, v -> m.cfg().val2 = Math.round(v), "%.0f", true));
         l.add(new Widgets.Slider("Trap size (blocks)", 1.0F, 9.0F, () -> m.cfg().val3, v -> m.cfg().val3 = Math.round(v), "%.0f", true));
         l.add(new Widgets.Slider("Plast size (blocks)", 1.0F, 9.0F, () -> m.cfg().val4, v -> m.cfg().val4 = Math.round(v), "%.0f", true));
         l.add(new Widgets.ColorPick("Trap color", () -> m.cfg().textColor, v -> m.cfg().textColor = v));
         l.add(new Widgets.ColorPick("Plast color", () -> m.cfg().borderColor, v -> m.cfg().borderColor = v));
         l.add(
            new Widgets.Label(
               "Hold the item to see its area. Items are found by their name (trap / \u0442\u0440\u0430\u043f, plast / \u043f\u043b\u0430\u0441\u0442). Set the durations and sizes to match your server.",
               -7696218
            )
         );
      } else if (m.id.equals("particles")) {
         l.add(new Widgets.Label("Tracks pearls, arrows, potions, tridents (yours and others').", -7696218));
      } else if (m.id.equals("aspect")) {
         l.add(new Widgets.Slider("Aspect ratio", 0.6F, 3.0F, () -> m.cfg().val, v -> m.cfg().val = v, "%.2f", false));
         l.add(new Widgets.Label("1.33 = 4:3 stretched, 1.78 = 16:9 (normal).", -7696218));
      } else if (m.id.equals("customsky")) {
         l.add(new Widgets.Slider("Rotation speed", 0.0F, 3.0F, () -> m.cfg().val <= 0.001F ? 1.0F : m.cfg().val, v -> m.cfg().val = v, "%.2fx", false));
         l.add(new Widgets.Slider("Brightness", 0.2F, 2.0F, () -> m.cfg().scale <= 0.001F ? 1.0F : m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Opacity", 0.1F, 1.0F, () -> m.cfg().val2 <= 0.001F ? 1.0F : m.cfg().val2, v -> m.cfg().val2 = v, "%.2f", false));
         l.add(new Widgets.Label("Realistic custom skybox with smooth rotating clouds.", -7696218));
      } else if (m.id.equals("scoreboard") || m.id.equals("tablist") || m.id.equals("chat")) {
         l.add(new Widgets.Slider("Scale", 0.5F, 2.0F, () -> m.cfg().scale, v -> m.cfg().scale = v, "%.2fx", false));
         l.add(new Widgets.Slider("Offset X", -300.0F, 300.0F, () -> m.cfg().offX, v -> m.cfg().offX = Math.round(v), "%.0f", true));
         l.add(new Widgets.Slider("Offset Y", -300.0F, 300.0F, () -> m.cfg().offY, v -> m.cfg().offY = Math.round(v), "%.0f", true));
      }

      if (m.optionLabel != null) {
         l.add(new Widgets.Toggle(m.optionLabel, () -> m.cfg().option, v -> m.cfg().option = v));
      }

      if (m.optionLabel2 != null) {
         l.add(new Widgets.Toggle(m.optionLabel2, () -> m.cfg().option2, v -> m.cfg().option2 = v));
      }

      if (m.optionLabel3 != null) {
         l.add(new Widgets.Toggle(m.optionLabel3, () -> m.cfg().option3, v -> m.cfg().option3 = v));
      }

      l.gap(2);
      l.add(new Widgets.KeyBind("Toggle key", () -> m.cfg().key, v -> m.cfg().key = v));
      l.add(new Widgets.Button("Reset this module", 2, () -> {
         ModuleSettings old = m.cfg();
         ModuleSettings d = m.defaults();
         d.enabled = old.enabled;
         d.key = old.key;
         DexConfig.get().modules.put(m.id, d);
         DexConfig.markDirty();
         rebuild.run();
      }));
   }
}

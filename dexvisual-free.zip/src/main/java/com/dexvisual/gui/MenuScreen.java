package com.dexvisual.gui;

import com.dexvisual.DexVisualClient;
import com.dexvisual.config.ConfigStore;
import com.dexvisual.config.CrosshairSettings;
import com.dexvisual.config.DesignPreset;
import com.dexvisual.config.DesignStore;
import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.config.Profile;
import com.dexvisual.config.UiSettings;
import com.dexvisual.cosmetics.Cosmetics;
import com.dexvisual.hud.CrosshairRenderer;
import com.dexvisual.hud.HudRenderer;
import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.net.SyncNet;
import com.dexvisual.util.ColorUtil;
import com.dexvisual.util.Gfx;
import com.dexvisual.util.I18n;
import com.dexvisual.util.MenuLayout;
import com.dexvisual.util.ModuleSearch;
import com.dexvisual.util.Motion;
import com.dexvisual.util.Notifications;
import com.dexvisual.util.Tracker;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;

public class MenuScreen extends Screen {
   static final String[] NAV = new String[]{"Modules", "Settings", "Themes", "Cosmetics", "Profile", "Crosshair"};
   static final String[] NAV_ICON = new String[]{"modules", "gear", "palette", "shirt", "person", "crosshair"};
   static final String[] MOD_TABS = new String[]{"All", "HUD", "Visual", "Chat", "Misc", "Favorites", "Recent"};
   static final String[] THEME_TABS = new String[]{"Skins", "Colors", "Presets", "Layout"};
   static final String[] COS_TABS = new String[]{"Items", "Effects"};
   static final String[] SORTS = new String[]{"Name", "Category", "Enabled first", "Favorites first", "Recent first"};
   static final String[] GRADIENT_DIRS = new String[]{"Top to bottom", "Bottom to top", "Left to right", "Right to left"};
   static final String[] STYLES = new String[]{"CROSS", "PLUS", "T", "X", "DOT", "CIRCLE", "DIAMOND", "HALO"};
   static final int[] PRESETS = new int[]{7113983, 10513663, 4184319, 16739508, 4652980, 16762967};
   static final Set<String> CHAT = Set.of("chat", "chatanim", "tabanim", "tablist", "scoreboard", "notifications");
   static final Set<String> VIS = Set.of(
      "watermark",
      "crosshair",
      "damage",
      "hands",
      "target",
      "customsky",
      "fullbright",
      "aspect",
      "particles",
      "blockoverlay",
      "targetesp",
      "artihelper",
      "jumpcircles",
      "chinahat",
      "killeffect",
      "motionblur",
      "freelook",
      "zoom"
   );
   static final Set<String> UTIL = Set.of("togglesprint", "togglesneak", "session", "perf", "memory", "optimize", "autosprint");
   private static final Map<String, Identifier> TEX = new HashMap<>();
   static String page = "Modules";
   static String modTab = "All";
   static String themeTab = "Skins";
   static String cosTab = "Items";
   private HudModule detail;
   private WidgetList list;
   private WidgetList detailList;
   private int detailX = -1;
   private int detailY = -1;
   private boolean detailDragging = false;
   private int dragOffsetX = 0;
   private int dragOffsetY = 0;
   private int px;
   private int py;
   private int pw;
   private int ph;
   private int sbw;
   private int nh;
   private int mpx;
   private int mpw;
   private int cx0;
   private int cx1;
   private boolean compact;
   private final long opened = System.currentTimeMillis();
   private long pageStart = this.opened;
   private final Map<String, Float> rowAnim = new HashMap<>();
   private final Map<String, Float> hoverAnim = new HashMap<>();
   private Widgets.Input nameInput;
   private final Widgets.Input search = new Widgets.Input("Search modules", null);
   private String lastQ = "";
   private String status = "";
   private boolean statusErr;
   private long statusAt;
   private String confirmMsg;
   private Runnable confirmAction;
   private boolean closing;
   private long closeStart;
   private boolean closeArmed;
   private boolean relayoutPending;
   private boolean wasDirty;
   private long savedAt;

   public MenuScreen() {
      super(Text.literal("DEX VISUAL"));
      this.search.max = 32;
      if (!Arrays.asList(NAV).contains(page)) {
         page = "Modules";
      }

      if (!Arrays.asList(MOD_TABS).contains(modTab)) {
         modTab = "All";
      }

      if (!Arrays.asList(THEME_TABS).contains(themeTab)) {
         themeTab = "Skins";
      }

      UiClock.reset();
   }

   static String version() {
      return FabricLoader.getInstance().getModContainer("dexvisual").map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("2.0");
   }

   public boolean shouldPause() {
      return false;
   }

   protected void init() {
      MenuLayout L = MenuLayout.compute(this.width, this.height, DexConfig.get().ui.uiScale);
      this.pw = L.pw();
      this.ph = L.ph();
      this.px = L.px();
      this.py = L.py();
      this.compact = L.compact();
      this.sbw = 0;
      this.mpx = this.px;
      this.mpw = this.pw;
      this.cx0 = this.mpx + 14;
      this.cx1 = this.mpx + this.mpw - 14;
      this.nh = Math.max(14, Math.min(26, (this.ph - 46 - 50) / (NAV.length + 1) - 4));
      float keep = this.list == null ? 0.0F : this.list.scroll;
      this.build();
      this.list.scroll = keep;
   
   }

   static CrosshairSettings cs() {
      return DexConfig.get().crosshair;
   }

   static UiSettings ui() {
      return DexConfig.get().ui;
   }

   private int cw() {
      return this.cx1 - this.cx0;
   }

   private int[] closeR() {
      return new int[]{this.px + (this.compact ? 12 : 16), this.py + 14, 16, 16};
   }

   private int[] navR(int i) {
      int dw = NAV.length * 44 + 8;
      int dx = this.px + (this.pw - dw) / 2;
      int dy = this.py + this.ph + 8;
      return new int[]{dx + 4 + i * 44, dy + 6, 28, 28};
   }

   private String[] tabs() {
      if (this.detail != null) {
         return null;
      } else {
         String var1 = page;

         return switch (var1) {
            case "Modules" -> MOD_TABS;
            case "Themes" -> THEME_TABS;
            case "Cosmetics" -> COS_TABS;
            default -> null;
         };
      }
   }

   private String curTab() {
      String var1 = page;

      return switch (var1) {
         case "Modules" -> modTab;
         case "Themes" -> themeTab;
         default -> cosTab;
      };
   }

   private void setTab(String t) {
      String var2 = page;
      switch (var2) {
         case "Modules":
            modTab = t;
            break;
         case "Themes":
            themeTab = t;
            break;
         default:
            cosTab = t;
      }
   }

   private int[] tabBar() {
      return new int[]{this.cx0, this.py + 50, this.cw(), 24};
   }

   private int[] tabR(int i) {
      String[] tb = this.tabs();
      if (tb == null) {
         return new int[]{0, 0, 0, 0};
      } else {
         int tx = this.cx0;

         for (int k = 0; k < i; k++) {
            tx += Gfx.tw(I18n.tr(tb[k])) + 12 + Gfx.tw("/");
         }

         return new int[]{tx - 2, this.py + 14, Gfx.tw(I18n.tr(tb[i])) + 4, 16};
      }
   }

   private int contentTop() {
      return this.py + 48;
   }

   private int contentH() {
      return Math.max(20, this.py + this.ph - 18 - this.contentTop());
   }

   private boolean searchVisible() {
      return page.equals("Modules") && this.detail == null && this.mpw > 260;
   }

   private int[] searchR() {
      int sw = 180;
      return new int[]{this.cx1 - sw, this.py + 12, sw, 28};
   }

   private int[] searchClearR() {
      int[] s = this.searchR();
      return new int[]{s[0] + s[2] - 20, s[1] + 4, 18, 18};
   }

   private int accent() {
      DexConfig cfg = DexConfig.get();
      return cfg.rainbow && UiClock.animated()
         ? ColorUtil.hsv((float)(System.currentTimeMillis() % 7000L) / 7000.0F, 0.65F, 1.0F)
         : MenuSkin.current().accentRgb();
   }

   private boolean handleDrag(int mx, int my) {
      if (this.detailDragging && this.detailList != null) {
         this.detailX = MathHelper.clamp(mx - this.dragOffsetX, 2, this.width - 234);
         this.detailY = MathHelper.clamp(my - this.dragOffsetY, 2, this.height - 60);
         this.detailList.x = this.detailX + 8;
         this.detailList.y = this.detailY + 24;
         return true;
      } else {
         return false;
      }
   }

   private void click() {
      if (DexConfig.get().menuSound) {
         this.client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.field_15015, 1.0F));
      }
   }

   private void setStatus(String text, boolean err) {
      this.status = text;
      this.statusErr = err;
      this.statusAt = System.currentTimeMillis();
   }

   private void ok(String key, Object... a) {
      this.setStatus(a.length == 0 ? I18n.tr(key) : I18n.fmt(key, a), false);
   }

   private void err(String key, Object... a) {
      this.setStatus(a.length == 0 ? I18n.tr(key) : I18n.fmt(key, a), true);
   }

   private void ask(String msgKey, Runnable action) {
      this.confirmMsg = msgKey;
      this.confirmAction = action;
      Widgets.Input.focused = null;
   }

   static void icon(DrawContext c, String name, int x, int y, int s, int argb) {
      Identifier id = TEX.computeIfAbsent(name, n -> Identifier.of("dexvisual", "textures/ui/" + n + ".png"));
      c.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0.0F, 0.0F, s, s, 64, 64, 64, 64, Gfx.ga(argb));
   }

   private static void surface(DrawContext c, int x, int y, int w, int h, int r, int rgb, float alpha) {
      Gfx.glow(c, x, y, w, h, r, 0, alpha * 0.75F);
      Gfx.glow(c, x, y, w, h, r, Theme.a1() | 0xFF000000, alpha * 0.15F);
      UiSettings u = ui();
      int hi = ColorUtil.mix(rgb, 16777215, 0.07F);
      int lo = ColorUtil.mix(rgb, 0, 0.28F);
      if (Theme.verticalGradient()) {
         boolean up = u.gradientDir == 1;
         Gfx.rrect(c, x, y, w, h, r, Gfx.argb(up ? lo : hi, alpha), Gfx.argb(up ? hi : lo, alpha));
      } else {
         Gfx.rrect(c, x, y, w, h, r, Gfx.argb(rgb, alpha));
      }
   }

   public void renderBackground(DrawContext c, int mx, int my, float d) {
   }

   public void render(DrawContext c, int mx, int my, float delta) {
      if (this.list != null) {
         DexConfig cfg = DexConfig.get();
         UiSettings u = cfg.ui;
         UiClock.tick();
         long now = System.currentTimeMillis();
         boolean anim = UiClock.animated();
         boolean reduced = UiClock.reduced();
         float dur = Motion.duration(0.25F, cfg.animSpeed, reduced);
         float fade = !anim ? 1.0F : Motion.easeOut(Motion.progress(this.opened, now, dur));
         int slide = 0;
         if (this.closing) {
            float q = anim ? Motion.progress(this.closeStart, now, dur * 0.7F) : 1.0F;
            fade = 1.0F - Motion.easeOut(q);
         }

         if (anim && !reduced) {
            slide = Math.round((1.0F - fade) * 10.0F);
         }

         Gfx.alpha = fade;
         Theme.override = this.accent();
         boolean pushed = false;

         try {
            if (!this.search.text().equals(this.lastQ)) {
               this.lastQ = this.search.text();
               this.build();
            }

            boolean d = DexConfig.dirty;
            if (this.wasDirty && !d && DexConfig.saveError == null) {
               this.savedAt = now;
            }

            this.wasDirty = d;
            int t = Theme.rgb(Theme.a1());
            if (slide != 0) {
               c.getMatrices().push();
               c.getMatrices().translate(0.0F, slide, 0.0F);
               pushed = true;
            }

            c.fill(0, 0, this.width, this.height, Gfx.ga(Gfx.argb(Theme.backdropRgb(), u.backdrop)));
            if (u.backdrop > 0.05F) {
               float time = (float)now / 1000.0F;
               int orbs = 5;

               for (int i = 0; i < orbs; i++) {
                  float ox = (float)(this.width / 2 + Math.sin(time * 0.5F + i * 1.5F) * (this.width / 2.5F));
                  float oy = (float)(this.height / 2 + Math.cos(time * 0.4F + i * 2.0F) * (this.height / 2.5F));
                  int col = ColorUtil.mix(t, Theme.rgb(Theme.a2()), (float)i / orbs);
                  Gfx.glow(c, (int)ox - 150, (int)oy - 150, 300, 300, 150, col, 0.5F * fade * u.backdrop);
               }
            }

            float wa = Math.min(0.97F, (0.4F + cfg.panelOpacity * 0.6F) * MenuSkin.current().alpha());
            surface(c, this.px, this.py, this.sbw, this.ph, 16, Theme.sidebarRgb(), wa);
            Gfx.rborder(c, this.px, this.py, this.sbw, this.ph, 16, 1, Theme.border());
            int[] cr = this.closeR();
            boolean xh = Gfx.in(mx, my, cr[0] - 3, cr[1] - 3, 22, 22);
            icon(c, "close", cr[0], cr[1], 16, xh ? -1 : Theme.muted());
            String tip = null;
            int tipX = 0;
            int tipY = 0;
            int dw = NAV.length * 44 + 8;
            int dx = this.px + (this.pw - dw) / 2;
            int dy = this.py + this.ph + 8;
            Gfx.rrect(c, dx, dy, dw, 40, 20, -1878323948);
            Gfx.rborder(c, dx, dy, dw, 40, 20, 1, 822083583);

            for (int i = 0; i < NAV.length; i++) {
               int[] r = this.navR(i);
               boolean on = NAV[i].equals(page);
               boolean hv = Gfx.in(mx, my, r[0], r[1], r[2], r[3]);
               String key = "navhover:" + NAV[i];
               float ha = this.hoverAnim.getOrDefault(key, 0.0F);
               ha = UiClock.approach(ha, hv ? 1.0F : 0.0F, 20.0F);
               this.hoverAnim.put(key, ha);
               if (ha > 0.01F) {
                  Gfx.rrect(c, r[0], r[1], r[2], r[3], 14, Gfx.argb(16777215, 0.1F * ha));
               }

               if (on) {
                  Gfx.rrect(c, r[0], r[1], r[2], r[3], 14, Gfx.argb(Theme.a1(), 0.35F));
               }

               int col = !on && !hv ? Theme.muted() : Theme.text();
               String ic = NAV_ICON[i];
               icon(c, ic, r[0] + 7, r[1] + 7, 14, col);
               if (hv) {
                  tip = I18n.tr(NAV[i]);
                  tipX = mx;
                  tipY = my;
               }
            }

            Gfx.rrect(c, this.mpx, this.py, this.mpw, this.ph, 16, -100070898);
            Gfx.rborder(c, this.mpx, this.py, this.mpw, this.ph, 16, 1, 369098751);
            if (u.gradient) {
               Gfx.gradFill(c, this.mpx + 16, this.py, Math.max(0, this.mpw - 32), 2, 0, Theme.a1(), Theme.a2(), u.gradientDir >= 2 ? u.gradientDir : 2);
            }

            MenuSkin skin = MenuSkin.current();
            if (skin.stars() && anim && !reduced) {
               float tm = (float)now / 1000.0F;

               for (int i = 0; i < 40; i++) {
                  int sx = this.mpx + 8 + (i * 97 + i * i * 13) % Math.max(1, this.mpw - 16);
                  int sy = this.py + 8 + (i * 53 + i * i * 7) % Math.max(1, this.ph - 16);
                  float tw2 = 0.35F + 0.65F * (0.5F + 0.5F * (float)Math.sin(tm * 1.6F + i));
                  Gfx.rrect(c, sx, sy, 1, 1, 0, Gfx.argb(16777215, 0.7F * tw2));
               }
            } else if (skin.stars()) {
               for (int i = 0; i < 40; i++) {
                  int sx = this.mpx + 8 + (i * 97 + i * i * 13) % Math.max(1, this.mpw - 16);
                  int sy = this.py + 8 + (i * 53 + i * i * 7) % Math.max(1, this.ph - 16);
                  Gfx.rrect(c, sx, sy, 1, 1, 0, Gfx.argb(16777215, 0.45F));
               }
            }

            int sw = this.searchVisible() ? this.searchR()[2] + 12 : 0;
            String[] curTbs = this.tabs();
            if (curTbs == null) {
               String title = I18n.tr(page);
               Gfx.text(c, Widgets.fit(title, this.cw() - sw - 4), this.cx0 + 4, this.py + 14, Theme.text(), false);
            }

            if (!page.equals("Modules")) {
               if (anim && !reduced) {
                  Gfx.waveText(c, "DEX VISUAL", this.cx0 + 4, this.py + 34, 1, t, Theme.rgb(Theme.a2()), 1.0F);
               } else {
                  Gfx.text(c, "DEX VISUAL", this.cx0 + 4, this.py + 34, Theme.selected(), false);
               }
            } else {
               int onx = 0;

               for (HudModule m : Modules.ALL) {
                  if (m.cfg().enabled) {
                     onx++;
                  }
               }

               Gfx.text(
                  c,
                  Widgets.fit(I18n.fmt("%d modules  |  %d enabled", Modules.ALL.size(), onx), this.cw() - sw - 4),
                  this.cx0 + 4,
                  this.py + 34,
                  Theme.muted(),
                  false
               );
            }

            if (this.searchVisible()) {
               int[] sr = this.searchR();
               boolean f = Widgets.Input.focused == this.search;
               Gfx.rrect(c, sr[0], sr[1], sr[2], sr[3], 13, Gfx.argb(Theme.sidebarRgb(), 0.92F));
               if (f) {
                  Gfx.rborder(c, sr[0], sr[1], sr[2], sr[3], 13, 1, Gfx.argb(t, 0.8F));
               }

               icon(c, "search", sr[0] + 9, sr[1] + 7, 12, Theme.muted());
               String s = this.search.sb.toString();
               boolean hasText = !s.isEmpty();
               int room = sr[2] - 38 - (hasText ? 16 : 0);
               if (!hasText && !f) {
                  Gfx.text(c, Widgets.fit(I18n.tr("Search modules"), room), sr[0] + 26, sr[1] + 9, Theme.muted(), false);
               } else {
                  Gfx.text(c, tail(s, room) + (f && now / 500L % 2L == 0L ? "_" : ""), sr[0] + 26, sr[1] + 9, Theme.text(), false);
               }

               if (hasText) {
                  int[] cl = this.searchClearR();
                  boolean hvx = Gfx.in(mx, my, cl[0], cl[1], cl[2], cl[3]);
                  Gfx.textC(c, "x", cl[0] + cl[2] / 2, cl[1] + 5, hvx ? -1 : Theme.muted(), false);
               }
            }

            String[] tb = this.tabs();
            if (tb != null) {
               int tx = this.cx0;

               for (int i = 0; i < tb.length; i++) {
                  boolean onx = tb[i].equals(this.curTab());
                  String name = I18n.tr(tb[i]);
                  Gfx.text(c, name, tx, this.py + 18, onx ? Theme.text() : Theme.muted(), false);
                  tx += Gfx.tw(name) + 6;
                  if (i < tb.length - 1) {
                     Gfx.text(c, "/", tx, this.py + 18, Gfx.argb(16777215, 0.2F), false);
                     tx += Gfx.tw("/") + 6;
                  }
               }
            }

            int top = this.contentTop();
            float pf = anim ? Motion.easeOut(Motion.progress(this.pageStart, now, reduced ? 0.08F : 0.16F)) : 1.0F;
            float keepA = Gfx.alpha;
            Gfx.alpha = keepA * (0.35F + 0.65F * pf);
            this.list.render(c, mx, my);
            Gfx.alpha = keepA;
            if (this.detailList != null && this.detail != null) {
               int pw = 230;
               int contentH = this.detailList.contentHeight();
               int maxH = Math.max(100, this.height - 30);
               int ph = Math.min(maxH, Math.max(90, contentH + 34));
               this.detailList.w = pw - 16;
               this.detailList.h = ph - 30;
               this.detailList.x = this.detailX + 8;
               this.detailList.y = this.detailY + 24;
               int pdx = this.detailX;
               int pdy = this.detailY;
               Gfx.glow(c, pdx, pdy, pw, ph, 20, 0, 0.65F);
               Gfx.rrect(c, pdx, pdy, pw, ph, 14, -99676139);
               Gfx.rborder(c, pdx, pdy, pw, ph, 14, 1, 620756991);
               Gfx.text(c, Widgets.fit(I18n.modName(this.detail), pw - 36), pdx + 12, pdy + 8, -1, false);
               boolean pxh = Gfx.in(mx, my, pdx + pw - 22, pdy + 5, 16, 16);
               Gfx.textC(c, "x", pdx + pw - 14, pdy + 7, pxh ? -1 : -2130706433, false);
               this.detailList.render(c, mx, my);
            }

            int fy = this.py + this.ph - 13;
            boolean fresh = now - this.statusAt < 5000L;
            if (DexConfig.saveError != null) {
               Gfx.textR(c, Widgets.fit(I18n.tr("Save failed - will retry"), this.cw() / 2), this.cx1, fy, -45715, false);
            } else if (!this.status.isEmpty() && fresh) {
               Gfx.textR(c, Widgets.fit(this.status, this.cw() / 2), this.cx1, fy, this.statusErr ? -45715 : Theme.a1(), false);
            }

            if (DexConfig.dirty) {
               Gfx.text(c, I18n.tr("Saving..."), this.cx0 + 4, fy, Theme.muted(), false);
            } else if (now - this.savedAt < 2000L) {
               Gfx.text(c, I18n.tr("Saved"), this.cx0 + 4, fy, Theme.muted(), false);
            }

            if (tip != null) {
               int tw = Gfx.tw(tip) + 10;
               int tx = Math.max(2, Math.min(this.width - tw - 2, tipX + 10));
               int ty = Math.max(2, tipY - 4);
               Gfx.rrect(c, tx, ty, tw, 14, 4, -301331438);
               Gfx.text(c, tip, tx + 5, ty + 3, -1, false);
            }

            if (this.confirmMsg != null) {
               this.drawConfirm(c, mx, my);
            }
         } finally {
            if (pushed) {
               c.getMatrices().pop();
            }

            Gfx.alpha = 1.0F;
            Theme.override = -1;
         }
      }
   }

   private static String tail(String s, int maxW) {
      while (s.length() > 1 && Gfx.tw(s) > maxW) {
         s = s.substring(1);
      }

      return s;
   }

   private int[] dlg() {
      int w = Math.min(280, this.width - 20);
      return new int[]{(this.width - w) / 2, this.height / 2 - 40, w, 80};
   }

   private int[] dlgBtn(int i) {
      int[] d = this.dlg();
      int bw = (d[2] - 30) / 2;
      return new int[]{d[0] + 10 + i * (bw + 10), d[1] + d[3] - 26, bw, 18};
   }

   private void drawConfirm(DrawContext c, int mx, int my) {
      c.fill(0, 0, this.width, this.height, Gfx.ga(-1728053248));
      int[] d = this.dlg();
      Gfx.rrect(c, d[0], d[1], d[2], d[3], 10, Gfx.argb(Theme.sidebarRgb(), 0.99F));
      Gfx.rborder(c, d[0], d[1], d[2], d[3], 10, 1, Theme.border());
      String msg = I18n.tr(this.confirmMsg);
      List<String> lines = new ArrayList<>();
      StringBuilder cur = new StringBuilder();

      for (String word : msg.split(" ")) {
         String test = cur.length() == 0 ? word : cur + " " + word;
         if (Gfx.tw(test) > d[2] - 24 && cur.length() > 0) {
            lines.add(cur.toString());
            cur = new StringBuilder(word);
         } else {
            cur.setLength(0);
            cur.append(test);
         }
      }

      if (cur.length() > 0) {
         lines.add(cur.toString());
      }

      for (int i = 0; i < Math.min(3, lines.size()); i++) {
         Gfx.textC(c, lines.get(i), d[0] + d[2] / 2, d[1] + 10 + i * 11, Theme.text(), false);
      }

      String[] lb = new String[]{"Cancel", "Confirm"};

      for (int i = 0; i < 2; i++) {
         int[] b = this.dlgBtn(i);
         boolean hv = Gfx.in(mx, my, b[0], b[1], b[2], b[3]);
         if (i == 1) {
            Gfx.rrect(c, b[0], b[1], b[2], b[3], 5, hv ? -860343734 : -1715981750);
         } else {
            Gfx.rrect(c, b[0], b[1], b[2], b[3], 5, hv ? 822083583 : 419430399);
            Gfx.rborder(c, b[0], b[1], b[2], b[3], 5, 1, 587202559);
         }

         Gfx.textC(c, Widgets.fit(I18n.tr(lb[i]), b[2] - 6), b[0] + b[2] / 2, b[1] + 5, -1, false);
      }
   }

   private void startPage() {
      this.pageStart = System.currentTimeMillis();
   }

   public boolean mouseClicked(double dx, double dy, int btn) {
      int mx = (int)dx;
      int my = (int)dy;
      if (this.closing) {
         return true;
      } else if (this.confirmMsg != null) {
         int[] b0 = this.dlgBtn(0);
         int[] b1 = this.dlgBtn(1);
         Runnable go = null;
         if (Gfx.in(mx, my, b1[0], b1[1], b1[2], b1[3])) {
            go = this.confirmAction;
         }

         boolean inside = Gfx.in(mx, my, b0[0], b0[1], b0[2], b0[3]) || go != null;
         if (inside || !Gfx.in(mx, my, this.dlg()[0], this.dlg()[1], this.dlg()[2], this.dlg()[3])) {
            this.confirmMsg = null;
            this.confirmAction = null;
            this.click();
            if (go != null) {
               go.run();
            }
         }

         return true;
      } else {
         this.click();
         if (this.searchVisible()) {
            int[] sr = this.searchR();
            if (Gfx.in(mx, my, sr[0], sr[1], sr[2], sr[3])) {
               int[] cl = this.searchClearR();
               if (!this.search.sb.isEmpty() && Gfx.in(mx, my, cl[0], cl[1], cl[2], cl[3])) {
                  this.search.sb.setLength(0);
                  return true;
               }

               this.search.click(mx, my, btn);
               return true;
            }
         }

         if (Widgets.Input.focused == this.search) {
            Widgets.Input.focused = null;
         }

         int[] cr = this.closeR();
         if (Gfx.in(mx, my, cr[0] - 3, cr[1] - 3, 22, 22)) {
            this.close();
            return true;
         } else {
            String gox = null;

            for (int i = 0; i < NAV.length; i++) {
               int[] r = this.navR(i);
               if (Gfx.in(mx, my, r[0], r[1], r[2], r[3])) {
                  gox = NAV[i];
               }
            }

            if (gox != null) {
               page = gox;
               this.detail = null;
               this.search.sb.setLength(0);
               this.lastQ = "";
               this.status = "";
               this.startPage();
               this.build();
               return true;
            } else {
               String[] tb = this.tabs();
               if (tb != null) {
                  for (int ix = 0; ix < tb.length; ix++) {
                     int[] r = this.tabR(ix);
                     if (Gfx.in(mx, my, r[0], r[1], r[2], r[3])) {
                        this.setTab(tb[ix]);
                        this.startPage();
                        this.build();
                        return true;
                     }
                  }
               }

               if (this.detailList != null && this.detail != null) {
                  int pw = 230;
                  int contentH = this.detailList.contentHeight();
                  int maxH = Math.max(100, this.height - 30);
                  int ph = Math.min(maxH, Math.max(90, contentH + 34));
                  int pdx = this.detailX;
                  int pdy = this.detailY;
                  if (Gfx.in(mx, my, pdx, pdy, pw, ph)) {
                     if (Gfx.in(mx, my, pdx + pw - 24, pdy + 4, 20, 20)) {
                        this.detail = null;
                        this.detailList = null;
                        return true;
                     }

                     boolean handled = this.detailList.click(mx, my, btn);
                     if (!handled) {
                        this.detailDragging = true;
                        this.dragOffsetX = mx - this.detailX;
                        this.dragOffsetY = my - this.detailY;
                     }

                     return true;
                  }

                  this.detail = null;
                  this.detailList = null;
               }

               this.list.click(mx, my, btn);
               return true;
            }
         }
      }
   }

   public boolean mouseDragged(double dx, double dy, int btn, double ddx, double ddy) {
      return !this.closing
         && this.confirmMsg == null
         && (this.handleDrag((int)dx, (int)dy) || this.detailList != null && this.detailList.drag((int)dx, (int)dy) || this.list.drag((int)dx, (int)dy));
   }

   public boolean mouseReleased(double dx, double dy, int btn) {
      this.list.release();
      if (this.detailList != null) {
         this.detailList.release();
      }

      this.detailDragging = false;
      if (this.relayoutPending) {
         this.relayoutPending = false;
         this.init();
      }

      return true;
   }

   public boolean mouseScrolled(double mx, double my, double h, double v) {
      return !this.closing && this.confirmMsg == null && (this.detailList != null && this.detailList.scroll(mx, my, v) || this.list.scroll(mx, my, v));
   }

   public boolean keyPressed(int key, int sc, int mods) {
      if (this.confirmMsg != null) {
         if (key == 256) {
            this.confirmMsg = null;
            this.confirmAction = null;
         }

         return true;
      } else if (Widgets.KeyBind.listening != null) {
         Widgets.KeyBind.listening.accept(key == 256 ? -1 : key);
         return true;
      } else if (Widgets.Input.focused != null) {
         Widgets.Input.key(key, mods);
         return true;
      } else if (DexVisualClient.menuKeyMatches(key, sc)) {
         if (this.closeArmed || System.currentTimeMillis() - this.opened > 900L) {
            this.close();
         }

         return true;
      } else if ((key == 47 || key == 70 && (mods & 2) != 0) && this.searchVisible()) {
         Widgets.Input.focused = this.search;
         return true;
      } else if (key == 264 || key == 267) {
         this.list.scroll(this.list.x + 1, this.list.y + 1, -(key == 264 ? 1 : 4));
         return true;
      } else if (key != 265 && key != 266) {
         return super.keyPressed(key, sc, mods);
      } else {
         this.list.scroll(this.list.x + 1, this.list.y + 1, key == 265 ? 1.0 : 4.0);
         return true;
      }
   }

   public boolean keyReleased(int key, int sc, int mods) {
      if (DexVisualClient.menuKeyMatches(key, sc)) {
         this.closeArmed = true;
      }

      return super.keyReleased(key, sc, mods);
   }

   public boolean charTyped(char ch, int mods) {
      return Widgets.Input.type(ch) || super.charTyped(ch, mods);
   }

   public void close() {
      if (!this.closing && UiClock.animated()) {
         this.closing = true;
         this.closeStart = System.currentTimeMillis();
         Widgets.Input.focused = null;
         Widgets.KeyBind.listening = null;
      } else {
         this.finish();
      }
   }

   private void finish() {
      super.close();
   }

   public void tick() {
      if (this.closing) {
         float dur = Motion.duration(0.25F, DexConfig.get().animSpeed, UiClock.reduced()) * 0.7F;
         if ((float)(System.currentTimeMillis() - this.closeStart) >= dur * 1000.0F) {
            this.finish();
         }
      }
   }

   public void removed() {
      Widgets.Input.focused = null;
      Widgets.KeyBind.listening = null;
      Gfx.alpha = 1.0F;
      Theme.override = -1;
      this.rowAnim.clear();
      this.hoverAnim.clear();
      UiClock.reset();
      DexConfig.get().save();
      if (DexConfig.saveError != null) {
         Notifications.push(I18n.tr("Save failed"), DexConfig.saveError, 16731501);
      }
   }

   private void build() {
      int top = this.contentTop();
      this.list = new WidgetList(this.cx0 + 6, top + 6, this.cw() - 12, this.contentH() - 12);
      if (Widgets.Input.focused != this.search) {
         Widgets.Input.focused = null;
      }

      String var2 = page;
      switch (var2) {
         case "Themes":
            this.themes();
            break;
         case "Cosmetics":
            this.cosmetics();
            break;
         case "Profile":
            this.profiles();
            this.configs();
            break;
         case "Crosshair":
            this.crosshair();
            break;
         case "Settings":
            this.settings();
            this.animations();
            this.about();
            this.stats();
            break;
         default:
            this.cards(modTab);
      }
   }

   private void themes() {
      String var1 = themeTab;
      switch (var1) {
         case "Colors":
            this.colors();
            break;
         case "Presets":
            this.presets();
            break;
         case "Layout":
            this.layoutPage();
            break;
         default:
            this.cosmetics();
      }
   }

   private void themeChanged() {
      ui().activePreset = "";
      DexConfig.markDirty();
   }

   private void colors() {
      DexConfig cfg = DexConfig.get();
      UiSettings u = cfg.ui;
      this.list.add(new Widgets.Block(52, (c, x, y, w, h, mx, my) -> {
         Gfx.rrect(c, x, y, w, h, 8, Gfx.argb(Theme.backdropRgb(), 0.9F));
         int sw2 = Math.min(90, w / 3);
         Gfx.rrect(c, x + 6, y + 6, sw2, h - 12, 7, Gfx.argb(Theme.sidebarRgb(), 0.95F));
         Gfx.rrect(c, x + 12, y + 14, 5, 12, 2, Theme.a1(), Theme.a2());
         Gfx.rrect(c, x + 20, y + 16, sw2 - 22, 3, 1, Theme.muted());
         Gfx.rrect(c, x + 12, y + 32, sw2 - 12, 3, 1, Theme.disabled());
         int pxx = x + 6 + sw2 + 6;
         int pww = w - sw2 - 18;
         Gfx.rrect(c, pxx, y + 6, pww, h - 12, 7, Gfx.argb(Theme.panelRgb(), 0.95F));
         int cwid = Math.max(20, (pww - 24) / 3);

         for (int i = 0; i < 3; i++) {
            int cxx = pxx + 6 + i * (cwid + 6);
            Gfx.rrect(c, cxx, y + 12, cwid, h - 24, 5, Gfx.argb(Theme.cardRgb(), Math.min(1.0F, u.cardOpacity + 0.35F)));
            Gfx.rrect(c, cxx + 4, y + 16, cwid - 8, 3, 1, Theme.text());
            Gfx.rrect(c, cxx + 4, y + 23, Math.max(4, cwid / 2), 3, 1, Theme.muted());
            Gfx.rrect(c, cxx + 4, y + h - 20, cwid - 8, 2, 1, i == 0 ? Theme.selected() : Theme.a2());
         }

         Gfx.rborder(c, x, y, w, h, 8, 1, Theme.border());
      }));
      this.list.add(new Widgets.Heading("Accent colors"));
      this.list.add(new Widgets.ColorEditor("Primary accent", () -> cfg.themeColor, () -> cfg.themeColor, v -> {
         cfg.themeColor = v & 16777215;
         u.themeAccent = true;
         this.themeChanged();
      }, null));
      this.list.add(new Widgets.ColorEditor("Secondary accent", () -> u.accent2, () -> Theme.a2() & 16777215, v -> {
         u.accent2 = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.accent2 = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.Heading("Surfaces"));
      this.list.add(new Widgets.ColorEditor("Background", () -> u.bgColor, Theme::backdropRgb, v -> {
         u.bgColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.bgColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.ColorEditor("Panel", () -> u.panelColor, Theme::panelRgb, v -> {
         u.panelColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.panelColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.ColorEditor("Sidebar", () -> u.sidebarColor, Theme::sidebarRgb, v -> {
         u.sidebarColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.sidebarColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.Heading("Text & lines"));
      this.list.add(new Widgets.ColorEditor("Text", () -> u.textColor, () -> Theme.text() & 16777215, v -> {
         u.textColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.textColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.ColorEditor("Secondary text", () -> u.mutedColor, () -> Theme.muted() & 16777215, v -> {
         u.mutedColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.mutedColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.ColorEditor("Border", () -> u.borderColor, () -> u.borderColor >= 0 ? u.borderColor : 16777215, v -> {
         u.borderColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.borderColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.ColorEditor("Selected / active", () -> u.selectedColor, () -> Theme.selected() & 16777215, v -> {
         u.selectedColor = v & 16777215;
         this.themeChanged();
      }, () -> {
         u.selectedColor = -1;
         this.themeChanged();
      }));
      this.list.add(new Widgets.Label("Text colors that would be hard to read are adjusted automatically.", -7696218));
      this.list.add(new Widgets.Heading("Opacity"));
      this.list.add(new Widgets.Slider("Panel opacity", 0.3F, 1.0F, () -> cfg.panelOpacity, v -> {
         cfg.panelOpacity = v;
         this.themeChanged();
      }, "%.2f", false));
      this.list.add(new Widgets.Slider("Card opacity", 0.2F, 1.0F, () -> u.cardOpacity, v -> {
         u.cardOpacity = v;
         this.themeChanged();
      }, "%.2f", false));
      this.list.add(new Widgets.Slider("Background dim", 0.0F, 0.8F, () -> u.backdrop, v -> {
         u.backdrop = v;
         this.themeChanged();
      }, "%.2f", false));
      this.list.add(new Widgets.Heading("Gradient"));
      this.list.add(new Widgets.Toggle("Use gradients", () -> u.gradient, v -> {
         u.gradient = v;
         this.themeChanged();
      }));
      this.list.add(new Widgets.Select("Gradient direction", GRADIENT_DIRS, () -> u.gradientDir, i -> {
         u.gradientDir = i;
         this.themeChanged();
      }).disabledIf(() -> !u.gradient));
      this.list.add(new Widgets.Toggle("Apply theme to all modules", () -> cfg.themeSync, v -> cfg.themeSync = v));
      this.list.add(new Widgets.Button("Reset theme colors", 2, () -> this.ask("Reset all theme colors, opacity and gradient to the defaults?", () -> {
         u.resetAppearance();
         cfg.themeColor = 7113983;
         cfg.panelOpacity = 0.6F;
         cfg.menuSkin = 0;
         u.activePreset = "";
         DexConfig.markDirty();
         this.ok("Theme reset");
         this.build();
      })));
   }

   private void presets() {
      DexConfig cfg = DexConfig.get();
      this.list.add(new Widgets.Label("Presets only change the look. Module profiles are kept separate (Profile page).", -7696218));
      this.list.add(new Widgets.Heading("Built-in presets"));

      for (DesignPreset bp : DesignStore.builtIns()) {
         String name = bp.name;
         this.list.add(this.presetRow(bp, cfg.ui.activePreset.equalsIgnoreCase(name)));
         this.list.addRow(new Widgets.Button("Apply", 1, () -> {
            DesignPreset fresh = DesignStore.builtIn(name);
            if (fresh == null) {
               this.err("Preset is missing or invalid");
            } else {
               DesignStore.apply(fresh);
               this.ok("Applied %s", name);
               this.relayoutPending = false;
               this.init();
            }
         }));
         this.list.gap(2);
      }

      this.list.add(new Widgets.Heading("My presets"));
      List<String> custom = DesignStore.listCustom();
      if (custom.isEmpty()) {
         this.list.add(new Widgets.Label("No custom presets yet. Name your current look below and save it.", -7696218));
      }

      for (String n : custom) {
         DesignPreset p = DesignStore.read(n);
         if (p == null) {
            this.list
               .add(
                  new Widgets.Block(
                     14, (c, x, y, w, h, mx, my) -> Gfx.text(c, Widgets.fit(n + "  -  " + I18n.tr("invalid file"), w - 4), x + 3, y + 3, -45715, false)
                  )
               );
            this.list.addRow(new Widgets.Button("Delete", 2, () -> this.ask("Delete this preset? This cannot be undone.", () -> {
               DesignStore.delete(n);
               this.build();
            })));
            this.list.gap(3);
         } else {
            this.list.add(this.presetRow(p, cfg.ui.activePreset.equalsIgnoreCase(n)));
            this.list.addRow(new Widgets.Button("Apply", 1, () -> {
               DesignPreset fresh = DesignStore.read(n);
               if (fresh == null) {
                  this.err("Preset is missing or invalid");
                  this.build();
               } else {
                  DesignStore.apply(fresh);
                  this.ok("Applied %s", n);
                  this.init();
               }
            }), new Widgets.Button("Rename", 0, () -> {
               String to = this.nameInput == null ? "" : DesignStore.cleanName(this.nameInput.text());
               if (to.isEmpty()) {
                  this.err("Type a new name first");
               } else if (DesignStore.isBuiltIn(to)) {
                  this.err("That name is reserved for a built-in preset");
               } else {
                  if (DesignStore.rename(n, to)) {
                     if (cfg.ui.activePreset.equalsIgnoreCase(n)) {
                        cfg.ui.activePreset = to;
                        DexConfig.markDirty();
                     }

                     this.ok("Renamed to %s", to);
                  } else {
                     this.err("Could not rename (name already used?)");
                  }

                  this.build();
               }
            }), new Widgets.Button("Export", 0, () -> {
               this.client.keyboard.setClipboard(DesignStore.export(p));
               this.ok("Copied %s to clipboard", n);
            }), new Widgets.Button("Delete", 2, () -> this.ask("Delete this preset? This cannot be undone.", () -> {
               if (DesignStore.delete(n)) {
                  if (cfg.ui.activePreset.equalsIgnoreCase(n)) {
                     cfg.ui.activePreset = "";
                     DexConfig.markDirty();
                  }

                  this.ok("Deleted %s", n);
               } else {
                  this.err("Delete failed");
               }

               this.build();
            })));
            this.list.gap(3);
         }
      }

      this.list.add(new Widgets.Heading("Save current look"));
      this.nameInput = this.list.add(new Widgets.Input("Preset name", null));
      this.list.addRow(new Widgets.Button("Save as preset", 1, () -> {
         String nx = DesignStore.cleanName(this.nameInput.text());
         if (nx.isEmpty()) {
            this.err("Enter a valid preset name");
         } else if (DesignStore.isBuiltIn(nx)) {
            this.err("That name is reserved for a built-in preset");
         } else {
            Runnable save = () -> {
               if (DesignStore.write(DesignStore.capture(nx))) {
                  cfg.ui.activePreset = nx;
                  DexConfig.markDirty();
                  this.ok("Saved %s", nx);
               } else {
                  this.err("Save failed");
               }

               this.build();
            };
            if (DesignStore.listCustom().stream().anyMatch(s -> s.equalsIgnoreCase(nx))) {
               this.ask("A preset with this name exists. Overwrite it?", save);
            } else {
               save.run();
            }
         }
      }), new Widgets.Button("Import (clipboard)", 0, () -> {
         DesignPreset px = DesignStore.parse(this.client.keyboard.getClipboard());
         if (px == null) {
            this.err("Clipboard is not a valid preset");
         } else {
            if (DesignStore.isBuiltIn(px.name)) {
               px.name = px.name + " 2";
            }

            if (DesignStore.write(px)) {
               this.ok("Imported %s", px.name);
            } else {
               this.err("Save failed");
            }

            this.build();
         }
      }));
   }

   private W presetRow(DesignPreset p, boolean active) {
      return new Widgets.Block(26, (c, x, y, w, h, mx, my) -> {
         Gfx.rrect(c, x, y, w, h, 7, Gfx.argb(16777215, active ? 0.1F : 0.05F));
         if (active) {
            Gfx.rborder(c, x, y, w, h, 7, 1, Gfx.argb(Theme.rgb(Theme.selected()), 0.8F));
         }

         int tc = p.themeColor >= 0 ? p.themeColor : DexConfig.get().themeColor;
         int a2 = p.ui != null && p.ui.accent2 >= 0 ? p.ui.accent2 : ColorUtil.mix(tc, 16777215, 0.35F);
         Gfx.rrect(c, x + 6, y + 6, 14, 14, 4, 0xFF000000 | tc, 0xFF000000 | a2);
         Gfx.text(c, Widgets.fit(p.name + (active ? "  (" + I18n.tr("active") + ")" : ""), w - 34), x + 26, y + 9, Theme.text(), false);
      });
   }

   private void layoutPage() {
      DexConfig cfg = DexConfig.get();
      UiSettings u = cfg.ui;
      this.list.add(new Widgets.Heading("Language"));
      this.list.add(new Widgets.Select("Language", I18n.LANG_NAMES, I18n::langIndex, i -> {
         I18n.setLang(i);
         this.build();
      }));
      this.list.add(new Widgets.Heading("Menu size"));
      this.list.add(new Widgets.Toggle("Automatic menu size", () -> u.uiScale == 0.0F, v -> {
         u.uiScale = v ? 0.0F : 1.0F;
         this.relayoutPending = false;
         this.init();
      }));
      this.list.add(new Widgets.Slider("Menu size", 0.7F, 1.3F, () -> u.uiScale == 0.0F ? 1.0F : u.uiScale, v -> {
         u.uiScale = Math.round(v * 20.0F) / 20.0F;
         this.relayoutPending = true;
      }, "%.2fx", false).disabledIf(() -> u.uiScale == 0.0F));
      this.list.add(new Widgets.Label("Scales the panel to fit your window. The menu always stays inside the screen.", -7696218));
      this.list.add(new Widgets.Heading("Animations"));
      this.list.add(new Widgets.Toggle("Menu animation", () -> cfg.menuAnim, v -> cfg.menuAnim = v));
      this.list.add(new Widgets.Toggle("Reduced motion", () -> u.reducedMotion, v -> u.reducedMotion = v).disabledIf(() -> !cfg.menuAnim));
      this.list
         .add(new Widgets.Slider("Animation speed", 0.3F, 2.5F, () -> cfg.animSpeed, v -> cfg.animSpeed = v, "%.2fx", false).disabledIf(() -> !cfg.menuAnim));
      this.list.add(new Widgets.Toggle("Sound Effects", () -> cfg.menuSound, v -> cfg.menuSound = v));
      this.list.add(new Widgets.Label("Reduced motion removes sliding and shortens fades. Turning animations off makes every change instant.", -7696218));
   }

   private void cosmetics() {
      DexConfig cfg = DexConfig.get();
      String var2 = page.equals("Themes") ? themeTab : cosTab;
      switch (var2) {
         case "Items":
            this.list.add(new Widgets.Button("Remove all", 2, () -> {
               Cosmetics.clear();
               this.build();
            }));
            this.list.add(new Widgets.Label("Tap to equip, tap again to remove. Wings / hats / backpacks show in third person (F5).", -7696218));

            for (int i = 0; i < Cosmetics.CATS.length; i++) {
               this.list.add(new Widgets.Heading(Cosmetics.LABELS[i]));
               this.list.add(new CosmeticGrid(Cosmetics.CATS[i], null));
            }
            break;
         case "Effects":
            this.list.add(new Widgets.Toggle("Show cosmetics", () -> cfg.cosmeticsOn, v -> cfg.cosmeticsOn = v));
            this.list.add(new Widgets.Toggle("Share mine (DV users)", () -> cfg.shareCosmetics, v -> {
               cfg.shareCosmetics = v;
               SyncNet.changed();
            }));
            this.list.add(new Widgets.Toggle("See others' cosmetics", () -> cfg.showOthers, v -> cfg.showOthers = v));
            this.list.add(new Widgets.Slider("Wing size", 0.6F, 1.5F, () -> cfg.wingSize, v -> cfg.wingSize = v, "%.2f", false));
            this.list.add(new Widgets.Slider("Pet size", 0.5F, 1.8F, () -> cfg.petSize, v -> cfg.petSize = v, "%.2f", false));
            this.list.add(new Widgets.Slider("Particle amount", 0.2F, 2.0F, () -> cfg.fxAmount, v -> cfg.fxAmount = v, "%.2f", false));
            break;
         default:
            this.list.add(new Widgets.Heading("Menu Skin"));
            this.list.add(new Widgets.Label("Choose your favorite style.", -7696218));
            this.list.add(new SkinPicker(this::build));
            if (MenuSkin.current().custom()) {
               this.list.add(new Widgets.ColorPick("Custom color", () -> cfg.themeColor, v -> cfg.themeColor = v));
            }

            this.list.add(new Widgets.Heading("Extra Settings"));
            this.list.add(new Widgets.Label("Additional customization options.", -7696218));
            this.list.add(new ToggleRow(0, "Animated Effects", "Enable smooth animations.", () -> cfg.menuAnim, v -> cfg.menuAnim = v));
            this.list.add(new ToggleRow(1, "Sound Effects", "Play sounds on menu events.", () -> cfg.menuSound, v -> cfg.menuSound = v));
            this.list.add(new ToggleRow(2, "Rainbow Mode", "Make your menu colors dynamic.", () -> cfg.rainbow, v -> cfg.rainbow = v));
      }
   }

   private void card(DrawContext c, int x, int y, int w, int h) {
      Gfx.rrect(c, x, y, w, h, 6, 385875967, 218103807);
      Gfx.rborder(c, x, y, w, h, 6, 1, 486539263);
   }

   private void stat(DrawContext c, int x, int y, int w, int h, String label, String value) {
      this.card(c, x, y, w, h);
      Gfx.text(c, Widgets.fit(label, w - 10), x + 7, y + 6, Theme.muted(), false);
      Gfx.text(c, Widgets.fit(value, w - 10), x + 7, y + 20, Theme.text(), false);
      Gfx.rrect(c, x + 7, y + h - 6, Math.max(8, w / 3), 2, 1, Theme.a1(), Theme.a2());
   }

   private void statRow(DrawContext c, int x, int y, int w, int h, String[][] s) {
      int n = s.length;
      int cw = (w - (n - 1) * 4) / n;

      for (int i = 0; i < n; i++) {
         this.stat(c, x + i * (cw + 4), y, cw, h, s[i][0], s[i][1]);
      }
   }

   private void bar(DrawContext c, int x, int y, int w, float pct, String label) {
      Gfx.text(c, Widgets.fit(label, w), x, y, Theme.muted(), false);
      Gfx.rrect(c, x, y + 10, w, 5, 2, Theme.track());
      Gfx.rrect(c, x, y + 10, Math.max(3, (int)(w * Math.min(1.0F, pct))), 5, 2, Theme.a1(), Theme.a2());
   }

   private void graph(DrawContext c, int x, int y, int w, int h) {
      this.card(c, x, y, w, h);
      float[] fr = Tracker.recentFrames(120);
      int n = Math.min(fr.length, w - 8);

      for (int i = 0; i < n; i++) {
         float fps = 1000.0F / Math.max(1.0F, fr[fr.length - n + i]);
         int bh = Math.max(1, Math.min(h - 6, Math.round(fps / 300.0F * (h - 6))));
         int col = Gfx.lerp(Theme.a1(), Theme.a2(), (float)i / Math.max(1, n));
         c.fill(x + 4 + i, y + h - 3 - bh, x + 5 + i, y + h - 3, Gfx.ga(col));
      }

      Gfx.text(c, I18n.tr("FPS graph"), x + 6, y + 4, Gfx.argb(16777215, 0.5F), false);
      if (n < 2) {
         Gfx.textC(c, Widgets.fit(I18n.tr("Join a world to record frames"), w - 8), x + w / 2, y + h / 2 - 4, Theme.muted(), false);
      }
   }

   private String up(String key) {
      return I18n.tr(key).toUpperCase(Locale.ROOT);
   }

   private void dashboard() {
      this.list.add(new Widgets.Heading("Overview"));
      this.list
         .add(
            new Widgets.Block(
               38,
               (c, x, y, w, h, mx, my) -> this.statRow(
                  c,
                  x,
                  y,
                  w,
                  h,
                  new String[][]{
                     {"FPS", String.valueOf(this.client.getCurrentFps())},
                     {this.up("Avg / 1% low"), Tracker.avgFps + " / " + Tracker.lowFps},
                     {"PING", this.pingText()},
                     {"CPS", Tracker.cpsLeft() + " | " + Tracker.cpsRight()}
                  }
               )
            )
         );
      this.list.add(new Widgets.Heading("Player & Server"));
      this.list
         .add(
            new Widgets.Block(
               66,
               (c, x, y, w, h, mx, my) -> {
                  int half = (w - 4) / 2;
                  this.card(c, x, y, half, h);
                  this.card(c, x + half + 4, y, half, h);
                  boolean g = this.client.player != null && this.client.world != null;
                  String none = "-";
                  String[] l = new String[]{
                     I18n.tr("Player"),
                     g ? this.client.player.getName().getString() : this.client.getSession().getUsername(),
                     g
                        ? String.format(
                           "XYZ %.0f %.0f %.0f",
                           this.client.player.getX(),
                           this.client.player.getY(),
                           this.client.player.getZ()
                        )
                        : "XYZ  " + none,
                     g ? I18n.tr("Biome") + " " + Modules.biome(this.client) : I18n.tr("Biome") + "  " + none,
                     g ? I18n.tr("Facing") + " " + Modules.facing(this.client.player.getYaw()) : I18n.tr("Facing") + "  " + none
                  };

                  for (int ixx = 0; ixx < l.length; ixx++) {
                     Gfx.text(c, Widgets.fit(l[ixx], half - 12), x + 7, y + 6 + ixx * 11, ixx == 0 ? Theme.a1() : Theme.text(), false);
                  }

                  String addr = this.client.getCurrentServerEntry() != null
                     ? this.client.getCurrentServerEntry().address
                     : (this.client.isInSingleplayer() ? I18n.tr("Singleplayer") : I18n.tr("Not connected"));
                  int online = this.client.getNetworkHandler() == null ? 0 : this.client.getNetworkHandler().getPlayerList().size();
                  String[] r = new String[]{
                     I18n.tr("Server"),
                     addr,
                     I18n.tr("Online players") + ": " + online,
                     I18n.tr("Version") + " 1.21.4 (Fabric)",
                     g ? this.client.world.getRegistryKey().getValue().getPath() : I18n.tr("Dimension") + "  " + none
                  };

                  for (int ix = 0; ix < r.length; ix++) {
                     Gfx.text(c, Widgets.fit(r[ix], half - 12), x + half + 11, y + 6 + ix * 11, ix == 0 ? Theme.a1() : Theme.text(), false);
                  }
               }
            )
         );
      this.list.add(new Widgets.Heading("System"));
      this.list.add(new Widgets.Block(24, (c, x, y, w, h, mx, my) -> {
         int half = (w - 8) / 2;
         this.bar(c, x + 2, y, half, Tracker.ramPercent(), "RAM  " + Tracker.usedRam());
         this.bar(c, x + half + 8, y, half, Tracker.cpu / 100.0F, "CPU  " + String.format("%.0f%%", Tracker.cpu));
      }));
      this.list.add(new Widgets.Block(60, (c, x, y, w, h, mx, my) -> this.graph(c, x, y, w, h)));
      this.list.add(new Widgets.Heading("Quick toggles"));
      HudModule[] q = new HudModule[]{
         Modules.WATERMARK, Modules.CPS, Modules.PING, Modules.COORDS, Modules.KEYSTROKES, Modules.ARMOR, Modules.CROSSHAIR, Modules.TARGET
      };

      for (int i = 0; i < q.length; i += 2) {
         HudModule a = q[i];
         HudModule b = q[i + 1];
         this.list
            .addRow(
               new Widgets.Toggle(I18n.modName(a), () -> a.cfg().enabled, v -> Modules.set(a, v)),
               new Widgets.Toggle(I18n.modName(b), () -> b.cfg().enabled, v -> Modules.set(b, v))
            );
      }
   }

   private String pingText() {
      if (this.client.getNetworkHandler() != null && this.client.player != null) {
         PlayerListEntry e = this.client.getNetworkHandler().getPlayerListEntry(this.client.player.getUuid());
         return e == null ? "--" : e.getLatency() + " ms";
      } else {
         return "--";
      }
   }

   private static String tabOf(HudModule m) {
      return CHAT.contains(m.id) ? "Chat" : (VIS.contains(m.id) ? "Visual" : (UTIL.contains(m.id) ? "Misc" : "HUD"));
   }

   private static boolean fav(HudModule m) {
      return DexConfig.get().favorites.contains(m.id);
   }

   private static void used(HudModule m) {
      if (DexConfig.get().ui.touchRecent(m.id)) {
         DexConfig.markDirty();
      }
   }

   private void openDetail(HudModule m) {
      if (this.detail == m) {
         this.detail = null;
         this.detailList = null;
      } else {
         this.detail = m;
         used(m);
         int popupW = 230;
         if (this.detailX == -1 || this.detailY == -1) {
            if (this.px >= popupW + 10) {
               this.detailX = this.px - popupW - 8;
            } else if (this.width - (this.px + this.pw) >= popupW + 10) {
               this.detailX = this.px + this.pw + 8;
            } else {
               this.detailX = Math.max(10, this.px + 16);
            }

            this.detailY = Math.max(15, this.py + 20);
         }

         this.detailList = new WidgetList(this.detailX + 8, this.detailY + 24, popupW - 16, 260);
         ModulePanel.build(this.detailList, m, this::build);
      }
   }

   private void cards(String tab) {
      UiSettings u = ui();
      String q = this.search.text();
      Set<String> favs = new HashSet<>(DexConfig.get().favorites);
      List<ModuleSearch.Item> items = new ArrayList<>();
      Map<String, HudModule> byId = new HashMap<>();

      for (HudModule m : Modules.ALL) {
         byId.put(m.id, m);
         items.add(new ModuleSearch.Item(m.id, m.name, I18n.modName(m), m.description, I18n.modDesc(m), tabOf(m), m.cfg().enabled));
      }

      List<ModuleSearch.Item> res = ModuleSearch.apply(items, q, tab, u.sort, favs, u.recent);
      this.list.gap(2);
      int count = res.size();
      this.list
         .addRow(
            new Widgets.Select("Sort", SORTS, () -> ui().sort, i -> {
               ui().sort = i;
               this.build();
            }),
            new Widgets.Block(
               18, (c, x, y, w, h, mx, my) -> Gfx.textR(c, Widgets.fit(I18n.fmt("%d shown", count), w - 6), x + w - 4, y + 5, Theme.muted(), false)
            )
         );
      List<W> cs = new ArrayList<>();
      int cols = 2;
      int ch = 48;

      for (ModuleSearch.Item it : res) {
         cs.add(new MenuScreen.Card(byId.get(it.id()), ch));
      }

      this.list.addGrid(cols, 12, cs);
      if (res.isEmpty()) {
         this.emptyState(tab, q);
      } else {
         this.list.add(new Widgets.Label("Click a card to toggle  |  heart = favorite  |  gear or right-click = settings", -7696218));
      }
   }

   private void emptyState(String tab, String q) {
      boolean searching = !q.isEmpty();
      String title = searching
         ? "No modules found"
         : ("Favorites".equals(tab) ? "No favorites yet" : ("Recent".equals(tab) ? "Nothing used recently" : "No modules found"));
      String hint = searching
         ? "Try another word or clear the search."
         : (
            "Favorites".equals(tab)
               ? "Tap the heart on a module card to pin it here."
               : ("Recent".equals(tab) ? "Modules you toggle or open will show up here." : "Nothing in this category.")
         );
      this.list.add(new Widgets.Block(58, (c, x, y, w, h, mx, my) -> {
         icon(c, "search", x + w / 2 - 10, y + 6, 20, Theme.disabled());
         Gfx.textC(c, Widgets.fit(I18n.tr(title), w - 8), x + w / 2, y + 32, Theme.text(), false);
         Gfx.textC(c, Widgets.fit(I18n.tr(hint), w - 8), x + w / 2, y + 44, Theme.muted(), false);
      }));
      if (searching) {
         this.list.add(new Widgets.Button("Clear search", 1, () -> {
            this.search.sb.setLength(0);
            Widgets.Input.focused = null;
         }));
      }
   }

   private void moduleDetail() {
      HudModule m = this.detail;
      this.list.add(new Widgets.Button("< Back", 0, () -> {
         this.detail = null;
         this.startPage();
         this.build();
      }));
      this.list.add(new Widgets.Block(m.box ? 84 : 62, (c, x, y, w, h, mxx, my) -> {
         Gfx.rrect(c, x, y, w, h, 8, -14998477, -15723233);
         Gfx.rborder(c, x, y, w, h, 8, 1, Theme.border());
         Gfx.text(c, I18n.tr("Preview"), x + 6, y + 5, Gfx.argb(16777215, 0.45F), false);
         boolean drawn = false;
         if (m == Modules.CROSSHAIR) {
            CrosshairRenderer.draw(c, x + w / 2, y + h / 2, cs(), false, 0.0F);
            drawn = true;
         } else if (m.box) {
            drawn = HudRenderer.drawPreview(c, this.client, m, x, y + 8, w, h - 8);
         }

         if (!drawn) {
            icon(c, "mod_" + m.id, x + w / 2 - 12, y + 12, 24, -1);
            Gfx.textC(c, Widgets.fit(I18n.tr("Live preview is not available for this module."), w - 12), x + w / 2, y + 42, Theme.muted(), false);
         }

         if (!m.cfg().enabled) {
            Gfx.textR(c, I18n.tr("Disabled"), x + w - 6, y + 5, Gfx.argb(16777215, 0.45F), false);
         }
      }));
      ModulePanel.build(this.list, this.detail, this::build);
      if (this.detail == Modules.CROSSHAIR) {
         this.list.add(new Widgets.Button("Open Crosshair Editor", 1, () -> {
            page = "Settings";
            this.detail = null;
            this.startPage();
            this.build();
         }));
      }
   }

   private void configs() {
      this.list.add(new Widgets.Heading("Save / import"));
      this.nameInput = this.list.add(new Widgets.Input("Config name", null));
      this.list.addRow(new Widgets.Button("Save current settings", 1, () -> {
         String nx = this.nameInput.text().isEmpty() ? "config" + (ConfigStore.list().size() + 1) : this.nameInput.text();
         if (ConfigStore.save(nx)) {
            this.ok("Saved %s", nx);
         } else {
            this.err("Save failed");
         }

         this.build();
      }), new Widgets.Button("Import (clipboard)", 0, () -> {
         String nx = ConfigStore.importJson(this.client.keyboard.getClipboard(), this.nameInput.text());
         if (nx == null) {
            this.err("Clipboard is not a valid config");
         } else {
            this.ok("Imported %s", nx);
         }

         this.build();
      }));
      this.list.add(new Widgets.Heading("Saved configs"));
      List<String> names = ConfigStore.list();
      if (names.isEmpty()) {
         this.list.add(new Widgets.Label("No saved configs yet. Type a name and press Save.", -7696218));
      }

      for (String n : names) {
         this.list.add(new Widgets.Block(14, (c, x, y, w, h, mx, my) -> Gfx.text(c, Widgets.fit(n, w - 6), x + 3, y + 3, Theme.text(), false)));
         this.list.addRow(new Widgets.Button("Load", 1, () -> {
            if (ConfigStore.load(n)) {
               this.ok("Loaded %s", n);
            } else {
               this.err("Load failed");
            }

            this.build();
         }), new Widgets.Button("Overwrite", 0, () -> this.ask("Overwrite this saved config with your current settings?", () -> {
            if (ConfigStore.save(n)) {
               this.ok("Saved %s", n);
            } else {
               this.err("Save failed");
            }
         })), new Widgets.Button("Export", 0, () -> {
            this.client.keyboard.setClipboard(ConfigStore.read(n));
            this.ok("Copied %s to clipboard", n);
         }), new Widgets.Button("Delete", 2, () -> this.ask("Delete this saved config? This cannot be undone.", () -> {
            ConfigStore.delete(n);
            this.build();
         })));
         this.list.gap(3);
      }

      this.list.add(new Widgets.Label("Files: .minecraft/config/dexvisual-configs/", -7696218));
   }

   private void stats() {
      this.dashboard();
      this.list.add(new Widgets.Heading("World"));
      this.list
         .add(
            new Widgets.Block(
               38,
               (c, x, y, w, h, mx, my) -> {
                  int ents = 0;
                  if (this.client.world != null) {
                     for (Entity e : this.client.world.getEntities()) {
                        ents++;
                     }
                  }

                  this.statRow(
                     c,
                     x,
                     y,
                     w,
                     h,
                     new String[][]{
                        {this.up("Render dist"), this.client.options.getViewDistance().getValue() + " " + I18n.tr("chunks")},
                        {this.up("Entities"), String.valueOf(ents)},
                        {this.up("Frame time"), String.format("%.1f ms", Tracker.frameMs)}
                     }
                  );
               }
            )
         );
   }

   private void animations() {
      DexConfig cfg = DexConfig.get();
      this.list.add(new Widgets.Heading("Animations"));
      this.list.add(new Widgets.Toggle("Menu animation", () -> cfg.menuAnim, v -> cfg.menuAnim = v));
      this.list.add(new Widgets.Toggle("Reduced motion", () -> cfg.ui.reducedMotion, v -> cfg.ui.reducedMotion = v).disabledIf(() -> !cfg.menuAnim));
      this.list.add(new Widgets.Toggle("HUD animations", () -> DexConfig.get().hudAnim, v -> DexConfig.get().hudAnim = v));
      this.list.add(new Widgets.Toggle("Chat animation", () -> Modules.CHATANIM.cfg().enabled, v -> Modules.set(Modules.CHATANIM, v)));
      this.list.add(new Widgets.Toggle("Tab animation", () -> Modules.TABANIM.cfg().enabled, v -> Modules.set(Modules.TABANIM, v)));
      this.list.add(new Widgets.Slider("Animation speed", 0.3F, 2.5F, () -> DexConfig.get().animSpeed, v -> DexConfig.get().animSpeed = v, "%.2fx", false));
      this.list.add(new Widgets.Block(46, (c, x, y, w, h, mx, my) -> {
         this.card(c, x, y, w, h);
         float e;
         if (UiClock.animated()) {
            float t = (float)(System.currentTimeMillis() % 2400L) / 2400.0F;
            e = Gfx.ease(t < 0.5F ? t * 2.0F : (1.0F - t) * 2.0F);
            if (UiClock.reduced()) {
               e = 0.5F + (e - 0.5F) * 0.25F;
            }
         } else {
            e = 0.5F;
         }

         int bx = x + 8 + Math.round(e * Math.max(0, w - 70));
         Gfx.glow(c, bx, y + 10, 54, 26, 6, Theme.rgb(Theme.a1()), 0.5F + e);
         Gfx.rrect(c, bx, y + 10, 54, 26, 6, Theme.a1(), Theme.a2());
         Gfx.textC(c, I18n.tr("SLIDE"), bx + 27, y + 19, -1, false);
      }));
      this.list.add(new Widgets.Label("Each module has its own animation: NONE / FADE / SLIDE / POP.", -7696218));
   }

   private void crosshair() {
      this.list.add(new Widgets.Toggle("Enable custom crosshair", () -> Modules.CROSSHAIR.cfg().enabled, v -> {
         Modules.set(Modules.CROSSHAIR, v);
         this.build();
      }));
      this.list.add(new Widgets.Heading("Preview"));
      this.list
         .add(
            new Widgets.Block(
               84,
               (c, x, y, w, h, mx, my) -> {
                  for (int i = 0; i < w; i += 14) {
                     for (int j = 0; j < h; j += 14) {
                        c.fill(
                           x + i, y + j, Math.min(x + i + 14, x + w), Math.min(y + j + 14, y + h), Gfx.ga((i / 14 + j / 14) % 2 == 0 ? -11827920 : -10642374)
                        );
                     }
                  }

                  Gfx.rborder(c, x, y, w, h, 0, 1, 1090519039);
                  long t = System.currentTimeMillis();
                  boolean hit = false;
                  float extra = cs().dynamic ? (float)Math.abs(Math.sin(t / 600.0)) * 4.0F : 0.0F;
                  CrosshairRenderer.draw(c, x + w / 2, y + h / 2, cs(), hit, extra);
               }
            )
         );
      this.list.add(new Widgets.Heading("Presets"));
      this.list
         .addRow(
            new Widgets.Button("Classic", 0, () -> this.preset("CROSS", 6, 1, 3, false)),
            new Widgets.Button("Dot", 0, () -> this.preset("DOT", 4, 3, 0, true)),
            new Widgets.Button("Tight", 0, () -> this.preset("PLUS", 5, 1, 0, false)),
            new Widgets.Button("Circle", 0, () -> this.preset("CIRCLE", 8, 1, 0, true))
         );
      this.list.add(new Widgets.Heading("Position"));
      this.list.add(new Widgets.Toggle("Lock position", () -> cs().lockPos, v -> cs().lockPos = v));
      this.list.add(new Widgets.Slider("Offset X", -250.0F, 250.0F, () -> (float)cs().offX, v -> cs().offX = Math.round(v), "%.0f", true));
      this.list.add(new Widgets.Slider("Offset Y", -250.0F, 250.0F, () -> (float)cs().offY, v -> cs().offY = Math.round(v), "%.0f", true));
      this.list.add(new Widgets.Button("Center crosshair", 0, () -> {
         cs().offX = 0;
         cs().offY = 0;
         DexConfig.markDirty();
      }));
      this.list.add(new Widgets.Label("Drag it in the HUD Editor; right-click there to lock.", -7696218));
      this.list.add(new Widgets.Heading("Style"));
      this.list.add(new Widgets.Select("Crosshair style", STYLES, () -> {
         for (int i = 0; i < STYLES.length; i++) {
            if (STYLES[i].equals(cs().style)) {
               return i;
            }
         }

         return 0;
      }, i -> cs().style = STYLES[i]));
      this.list.add(new Widgets.Slider("Size", 1.0F, 20.0F, () -> (float)cs().size, v -> cs().size = Math.round(v), "%.0f", true));
      this.list.add(new Widgets.Slider("Thickness", 1.0F, 6.0F, () -> (float)cs().thickness, v -> cs().thickness = Math.round(v), "%.0f", true));
      this.list.add(new Widgets.Slider("Gap", 0.0F, 12.0F, () -> (float)cs().gap, v -> cs().gap = Math.round(v), "%.0f", true));
      this.list.add(new Widgets.Toggle("Outline", () -> cs().outline, v -> cs().outline = v));
      this.list.add(new Widgets.Toggle("Center dot", () -> cs().dot, v -> cs().dot = v));
      this.list.add(new Widgets.Toggle("Soft glow", () -> cs().glow, v -> cs().glow = v));
      this.list.add(new Widgets.Toggle("Dynamic (expands while moving)", () -> cs().dynamic, v -> cs().dynamic = v));
      this.list.add(new Widgets.Heading("Color"));
      this.list.add(new Widgets.Label("Uses the global theme color while \"Apply theme\" is on.", -7696218));
      this.list.add(new Widgets.ColorPick("Crosshair color", () -> cs().color, v -> {
         cs().color = v;
         cs().ownColor = true;
      }));
      this.list.add(new Widgets.Slider("Opacity", 0.1F, 1.0F, () -> cs().opacity, v -> cs().opacity = v, "%.2f", false));
      this.list.add(new Widgets.Heading("Custom presets"));
      this.list.add(new Widgets.Button("Save current crosshair as preset", 1, () -> {
         CrosshairSettings s = cs().copy();
         s.name = "Custom " + (DexConfig.get().crosshairPresets.size() + 1);
         DexConfig.get().crosshairPresets.add(s);
         DexConfig.markDirty();
         this.build();
      }));

      for (CrosshairSettings p : new ArrayList<>(DexConfig.get().crosshairPresets)) {
         this.list.addRow(new Widgets.Button(p.name == null ? "Preset" : p.name, 0, () -> {
            DexConfig.get().crosshair = p.copy();
            DexConfig.markDirty();
            this.build();
         }), new Widgets.Button("Delete", 2, () -> this.ask("Delete this preset? This cannot be undone.", () -> {
            DexConfig.get().crosshairPresets.remove(p);
            DexConfig.markDirty();
            this.build();
         })));
      }

      if (!Modules.CROSSHAIR.cfg().enabled) {
         this.list.add(new Widgets.Button("Enable custom crosshair (currently off)", 1, () -> {
            Modules.set(Modules.CROSSHAIR, true);
            this.build();
         }));
      }
   }

   private void preset(String style, int size, int th, int gap, boolean dot) {
      CrosshairSettings s = cs();
      s.style = style;
      s.size = size;
      s.thickness = th;
      s.gap = gap;
      s.dot = dot;
      DexConfig.markDirty();
   }

   private void profiles() {
      DexConfig cfg = DexConfig.get();
      this.list.add(new Widgets.Heading("Create / rename"));
      this.nameInput = this.list.add(new Widgets.Input("Profile name", null));
      this.list.addRow(new Widgets.Button("Create profile", 1, () -> {
         Profile px = cfg.createProfile(this.nameInput.text().isEmpty() ? "Custom" : this.nameInput.text());
         this.ok("Created %s", px.name);
         this.build();
      }), new Widgets.Button("Import (clipboard)", 0, () -> {
         Profile px = cfg.importProfile(this.client.keyboard.getClipboard());
         if (px == null) {
            this.err("Clipboard is not a valid profile");
         } else {
            this.ok("Imported %s", px.name);
         }

         this.build();
      }));
      this.list.add(new Widgets.Label("Type a name above, then use Create or Rename on a profile.", -7696218));
      this.list.add(new Widgets.Heading("Your profiles"));

      for (Profile p : new ArrayList<>(cfg.profiles)) {
         boolean active = p.name.equals(cfg.activeProfile);
         this.list
            .add(
               new Widgets.Block(
                  14,
                  (c, x, y, w, h, mx, my) -> Gfx.text(
                     c,
                     Widgets.fit(
                        (active ? "\u00c3\u00a2\u00e2\u20ac\u201d\u00c2\u008f " : "  ") + p.name + (active ? "  (" + I18n.tr("active") + ")" : ""), w - 6
                     ),
                     x + 3,
                     y + 3,
                     active ? Theme.a1() : Theme.text(),
                     false
                  )
               )
            );
         this.list.addRow(new Widgets.Button("Load", active ? 1 : 0, () -> {
            cfg.applyProfile(p.name);
            Notifications.push(I18n.tr("Profile loaded"), p.name, 10513663);
            this.ok("Loaded %s", p.name);
            this.build();
         }), new Widgets.Button("Rename", 0, () -> {
            if (!this.nameInput.text().isEmpty()) {
               cfg.renameProfile(p, this.nameInput.text());
               this.build();
            } else {
               this.err("Type a new name first");
            }
         }), new Widgets.Button("Copy", 0, () -> {
            cfg.duplicateProfile(p);
            this.build();
         }), new Widgets.Button("Export", 0, () -> {
            this.client.keyboard.setClipboard(cfg.exportProfile(p));
            this.ok("Copied %s to clipboard", p.name);
         }), new Widgets.Button("Delete", 2, () -> this.ask("Delete this profile? This cannot be undone.", () -> {
            if (!cfg.deleteProfile(p)) {
               this.err("Keep at least one profile");
            }

            this.build();
         })));
         this.list.gap(3);
      }
   }

   private void settings() {
      this.list.add(new Widgets.Heading("General"));
      this.list.add(new Widgets.Toggle("HUD visible", () -> DexConfig.get().hudVisible, v -> DexConfig.get().hudVisible = v));
      this.list
         .add(
            new Widgets.Slider(
               "Notification time (s)", 1.0F, 10.0F, () -> (float)DexConfig.get().notifSeconds, v -> DexConfig.get().notifSeconds = Math.round(v), "%.0f", true
            )
         );
      this.list.add(new Widgets.Heading("HUD Editor"));
      this.list.add(new Widgets.Toggle("Snap to edges & elements", () -> DexConfig.get().snap, v -> DexConfig.get().snap = v));
      this.list.add(new Widgets.Toggle("Show alignment guides", () -> DexConfig.get().guides, v -> DexConfig.get().guides = v));
      this.list
         .add(
            new Widgets.Slider("Snap distance", 1.0F, 12.0F, () -> (float)DexConfig.get().snapDist, v -> DexConfig.get().snapDist = Math.round(v), "%.0f", true)
         );
      this.list.add(new Widgets.Heading("Interface"));
      this.list.add(new Widgets.Select("Language", I18n.LANG_NAMES, I18n::langIndex, i -> {
         I18n.setLang(i);
         this.build();
      }));
      this.list.add(new Widgets.ColorPick("Theme color", () -> DexConfig.get().themeColor, v -> {
         DexConfig.get().themeColor = v;
         ui().themeAccent = true;
         ui().activePreset = "";
      }));
      this.list.add(new Widgets.Toggle("Apply theme to all modules", () -> DexConfig.get().themeSync, v -> DexConfig.get().themeSync = v));
      this.list.add(new Widgets.Button("Reset custom colors (follow theme)", 1, () -> {
         for (ModuleSettings ms : DexConfig.get().modules.values()) {
            ms.ownColor = false;
         }

         DexConfig.get().crosshair.ownColor = false;
         DexConfig.markDirty();
         this.ok("Colors reset");
      }));
      this.list.add(new Widgets.Slider("Panel opacity", 0.3F, 1.0F, () -> DexConfig.get().panelOpacity, v -> DexConfig.get().panelOpacity = v, "%.2f", false));
      this.list.add(new Widgets.Label("More colors, presets and menu size: Themes page.", -7696218));
      this.list.add(new Widgets.Heading("Keybinds (module toggle keys)"));
      this.list.add(new Widgets.Label("Menu key is in Options > Controls > DEX VISUAL.", -7696218));

      for (HudModule m : Modules.ALL) {
         this.list.add(new Widgets.KeyBind(I18n.modName(m), () -> m.cfg().key, v -> m.cfg().key = v));
      }

      this.list.add(new Widgets.Heading("Reset"));
      this.list
         .add(new Widgets.Button("Reset HUD layout & styles", 2, () -> this.ask("Reset every module's position and style? Enabled states are kept.", () -> {
            DexConfig.get().resetModules(true);
            this.ok("HUD reset");
            this.build();
         })));
      this.list
         .add(
            new Widgets.Button(
               "Reset ALL settings", 2, () -> this.ask("Reset ALL DEX VISUAL settings to the defaults? Profiles and saved configs are kept.", () -> {
                  DexConfig.get().resetAll();
                  this.ok("Everything reset");
                  this.init();
               })
            )
         );
   }

   private void about() {
      this.list.add(new Widgets.Block(54, (c, x, y, w, h, mx, my) -> {
         Gfx.glow(c, x + 4, y + 4, 38, 38, 10, Theme.rgb(Theme.a1()), 1.0F);
         Gfx.rrect(c, x + 4, y + 4, 38, 38, 10, Theme.a1(), Theme.a2());
         Gfx.textC(c, "DEX", x + 23, y + 20, -1, false);
         Gfx.text(c, "DEX VISUAL", x + 52, y + 10, Theme.text(), false);
         Gfx.text(c, Widgets.fit(I18n.tr("Visual client mod") + "  -  v" + version(), w - 56), x + 52, y + 24, Theme.muted(), false);
      }));
      this.list.add(new Widgets.Heading("Info"));
      this.list.add(new Widgets.Label("Minecraft 1.21.4  |  Fabric Loader  |  Fabric API  |  Java 21", -1512459));
      this.list
         .add(
            new Widgets.Block(
               12,
               (c, x, y, w, h, mx, my) -> Gfx.text(
                  c,
                  Widgets.fit(I18n.fmt("%d modules  |  profiles & HUD presets  |  crosshair editor", Modules.ALL.size()), w - 4),
                  x + 2,
                  y + 2,
                  Theme.text(),
                  false
               )
            )
         );
      this.list.add(new Widgets.Heading("Controls"));
      this.list.add(new Widgets.Label("Menu key  -  open this menu (default Right Shift)", -7696218));
      this.list.add(new Widgets.Label("T (chat)  -  drag HUD elements", -7696218));
      this.list.add(new Widgets.Label("H  -  show / hide the whole HUD", -7696218));
      this.list.add(new Widgets.Label("/dexwp add <name>  -  create a waypoint", -7696218));
      this.list.add(new Widgets.Label("/ or Ctrl+F  -  search modules", -7696218));
      this.list.add(new Widgets.Heading("HUD Editor tips"));
      this.list.add(new Widgets.Label("Drag boxes to move, drag the corner to resize,", -7696218));
      this.list.add(new Widgets.Label("mouse wheel to scale, right-click to toggle,", -7696218));
      this.list.add(new Widgets.Label("arrow keys nudge (hold Shift = bigger steps).", -7696218));
   }

   private class Card extends W {
      final HudModule m;

      Card(HudModule m, int h) {
         this.m = m;
         this.h = h;
      }

      private boolean inToggle(int mx, int my) {
         return Gfx.in(mx, my, this.x + this.w - 50, this.y, 50, this.h);
      }

      @Override
      public void render(DrawContext c, int mx, int my) {
         boolean on = this.m.cfg().enabled;
         boolean hv = this.hover(mx, my);
         float a = MenuScreen.this.rowAnim.getOrDefault(this.m.id, on ? 1.0F : 0.0F);
         a = UiClock.approach(a, on ? 1.0F : 0.0F, 18.0F);
         MenuScreen.this.rowAnim.put(this.m.id, a);
         float ha = MenuScreen.this.hoverAnim.getOrDefault(this.m.id, 0.0F);
         ha = UiClock.approach(ha, hv ? 1.0F : 0.0F, 22.0F);
         MenuScreen.this.hoverAnim.put(this.m.id, ha);
         int t = Theme.rgb(Theme.a1());
         int bg = Gfx.lerp(1879772436, -1877731808, ha);
         Gfx.rrect(c, this.x, this.y, this.w, this.h, 14, bg);
         if (ha > 0.01F) {
            Gfx.rborder(c, this.x, this.y, this.w, this.h, 14, 1, Gfx.argb(16777215, 0.08F * ha));
         }

         Gfx.text(c, Widgets.fit(I18n.modName(this.m), this.w - 60), this.x + 16, this.y + (this.h - 9) / 2, -1, false);
         int tw = 36;
         int th = 20;
         int tx = this.x + this.w - 16 - tw;
         int ty = this.y + (this.h - th) / 2;
         int tBg = Gfx.lerp(-14539728, 0xFF000000 | t, a);
         Gfx.rrect(c, tx, ty, tw, th, th / 2, tBg);
         if (!on) {
            Gfx.rborder(c, tx, ty, tw, th, th / 2, 1, -13289402);
         }

         int kx = tx + 2 + (int)((tw - 20) * a);
         Gfx.rrect(c, kx, ty + 2, 16, 16, 8, -1);
         if (a > 0.01F) {
            Gfx.glow(c, tx, ty, tw, th, th / 2, t, 0.5F * a);
         }
      }

      @Override
      public boolean click(int mx, int my, int b) {
         if (b == 1) {
            MenuScreen.this.openDetail(this.m);
            return true;
         } else {
            Modules.toggle(this.m);
            MenuScreen.used(this.m);
            return true;
         }
      }
   }
}

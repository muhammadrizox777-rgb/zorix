package com.dexvisual.gui;

import com.dexvisual.util.Gfx;
import com.dexvisual.util.I18n;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

public final class TitleBrand {
   private static int bx;
   private static int by;
   private static int bw;
   private static int bh;
   private static final Identifier LOGO = Identifier.of("dexvisual", "textures/logo.png");

   private TitleBrand() {
   }

   public static void render(DrawContext c, Screen s, int mx, int my) {
      MenuSkin skin = MenuSkin.current();
      Theme.override = skin.accentRgb();

      try {
         int w = s.width;
         int a1 = Theme.rgb(Theme.a1());
         int a2 = Theme.rgb(Theme.a2());
         long now = System.currentTimeMillis();
         String name = "DEX VISUAL";
         int ww = Gfx.waveWidth(name, 2);
         float sc = 2.0F;
         int pw = Math.min(w - 20, 84 + Math.round(ww * sc) + 14);
         int ph = 50;
         int x = (w - pw) / 2;
         int y = 12;
         Gfx.glow(c, x, y, pw, ph, 14, a1, 1.3F);
         Gfx.rrect(c, x, y, pw, ph, 14, Gfx.argb(skin.bg1(), 0.96F), Gfx.argb(skin.bg2(), 0.96F));
         Gfx.rrect(c, x + 3, y + 3, pw / 2, 18, 11, Gfx.argb(a1, 0.12F), Gfx.argb(a1, 0.0F));
         Gfx.rborder(c, x, y, pw, ph, 14, 1, Gfx.argb(a1, 0.85F));
         Gfx.rborder(c, x + 1, y + 1, pw - 2, ph - 2, 13, 1, Gfx.argb(a2, 0.22F));
         Gfx.glow(c, x + 16, y + 14, 36, 20, 8, a1, 0.45F + 0.2F * (float)Math.sin(now / 450.0));
         c.drawTexture(RenderLayer::getGuiTextured, LOGO, x + 12, y + 8, 0.0F, 0.0F, 48, 30, 292, 184, 292, 184, -1);
         int tx = x + 72;
         c.getMatrices().push();
         c.getMatrices().translate(tx, y + 9, 0.0F);
         c.getMatrices().scale(sc, sc, 1.0F);
         Gfx.waveText(c, name, 0, 0, 2, a1, a2, 1.0F);
         c.getMatrices().pop();
         Gfx.text(c, "VISUAL CLIENT  \u2022  1.21.4  \u2022  FABRIC", tx, y + 30, -4606762, false);
         int lx = x + 18;
         int lw = pw - 36;
         int ly = y + ph - 6;
         c.fill(lx, ly, lx + lw, ly + 1, Gfx.argb(16777215, 0.1F));
         int sx = lx + Math.round((float)(now % 2400L) / 2400.0F * (lw + 50)) - 50;

         for (int k = 0; k < 10; k++) {
            int x0 = Math.max(lx, sx + k * 5);
            int x1 = Math.min(lx + lw, sx + (k + 1) * 5);
            if (x1 > x0) {
               c.fill(x0, ly, x1, ly + 1, Gfx.argb(k < 5 ? a1 : a2, 0.25F + 0.75F * (1.0F - Math.abs(k - 4.5F) / 5.0F)));
            }
         }

         String label = I18n.t(
            "DEX VISUAL menyusini ochish", "Open DEX VISUAL menu", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043c\u0435\u043d\u044e DEX VISUAL"
         );
         bw = Math.max(150, Gfx.tw(label) + 28);
         bh = 18;
         bx = (w - bw) / 2;
         by = y + ph + 8;
         boolean hv = Gfx.in(mx, my, bx, by, bw, bh);
         Gfx.glow(c, bx, by, bw, bh, 9, a1, hv ? 1.0F : 0.45F);
         Gfx.rrect(c, bx, by, bw, bh, 9, hv ? Gfx.argb(a1, 0.95F) : Gfx.argb(skin.bg1(), 0.92F), hv ? Gfx.argb(a2, 0.95F) : Gfx.argb(skin.bg2(), 0.92F));
         Gfx.rborder(c, bx, by, bw, bh, 9, 1, Gfx.argb(a1, hv ? 1.0F : 0.7F));
         Gfx.textC(c, label, w / 2, by + 5, -1, false);
      } finally {
         Theme.override = -1;
      }
   }

   public static boolean click(Screen s, double dx, double dy, int btn) {
      if (btn == 0 && Gfx.in((int)dx, (int)dy, bx, by, bw, bh)) {
         MinecraftClient.getInstance().setScreen(new MenuScreen());
         return true;
      } else {
         return false;
      }
   }
}

package com.dexvisual.mixin;

import com.dexvisual.module.Modules;
import com.dexvisual.util.CustomSkyRenderer;
import net.minecraft.world.World;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({SkyRendering.class})
public class SkyRenderingMixin {
   public SkyRenderingMixin() {
   }

   @Inject(
      method = {"renderSky(FFF)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$cancelVanillaDaySky(float r, float g, float b, CallbackInfo ci) {
      if (Modules.CUSTOMSKY != null && Modules.CUSTOMSKY.cfg().enabled) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"renderSkyDark(Lnet/minecraft/client/util/math/MatrixStack;)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$cancelVanillaDarkSky(MatrixStack matrices, CallbackInfo ci) {
      if (Modules.CUSTOMSKY != null && Modules.CUSTOMSKY.cfg().enabled) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"renderGlowingSky(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;FI)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$cancelGlowingSky(MatrixStack matrices, Immediate immediate, float f, int i, CallbackInfo ci) {
      if (Modules.CUSTOMSKY != null && Modules.CUSTOMSKY.cfg().enabled && !Modules.CUSTOMSKY.cfg().option) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"renderCelestialBodies(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;FIFFLnet/minecraft/client/render/Fog;)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$renderSky(
      MatrixStack matrices, Immediate immediate, float tickDelta, int skyAngle, float starBrightness, float moonAngle, Fog fog, CallbackInfo ci
   ) {
      if (Modules.CUSTOMSKY != null && Modules.CUSTOMSKY.cfg().enabled) {
         CustomSkyRenderer.render(matrices, immediate, tickDelta);
         if (!Modules.CUSTOMSKY.cfg().option) {
            ci.cancel();
         }
      }
   }
}

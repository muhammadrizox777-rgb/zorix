package com.dexvisual.mixin;

import net.minecraft.client.gui.LogoDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LogoDrawer.class})
public class LogoDrawerMixin {
   public LogoDrawerMixin() {
   }

   @Inject(
      method = {"draw"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$hideLogo(CallbackInfo ci) {
      ci.cancel();
   }
}

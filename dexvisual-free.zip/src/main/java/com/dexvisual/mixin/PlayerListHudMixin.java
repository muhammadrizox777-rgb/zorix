package com.dexvisual.mixin;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import com.dexvisual.util.UiAnim;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerListHud.class})
public class PlayerListHudMixin {
   private static final String RENDER = "render(Lnet/minecraft/client/gui/DrawContext;ILnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreboardObjective;)V";

   public PlayerListHudMixin() {
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;ILnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("HEAD")},
      require = 0
   )
   private void dexvisual$head(DrawContext ctx, int width, Scoreboard sb, ScoreboardObjective obj, CallbackInfo ci) {
      ModuleSettings s = Modules.TABLIST.cfg();
      boolean anim = Modules.TABANIM.cfg().enabled;
      if (s.enabled || anim) {
         float ax = MinecraftClient.getInstance().getWindow().getScaledWidth() / 2.0F;
         float ay = 10.0F;
         ctx.getMatrices().push();
         if (s.enabled) {
            ctx.getMatrices().translate(ax + s.offX, ay + s.offY, 0.0F);
            ctx.getMatrices().scale(s.scale, s.scale, 1.0F);
            ctx.getMatrices().translate(-ax, -ay, 0.0F);
         }

         if (anim) {
            float p = UiAnim.tab();
            float k = 0.93F + 0.07F * p;
            ctx.getMatrices().translate(ax, ay - (1.0F - p) * 9.0F, 0.0F);
            ctx.getMatrices().scale(k, k, 1.0F);
            ctx.getMatrices().translate(-ax, -ay, 0.0F);
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;ILnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("RETURN")},
      require = 0
   )
   private void dexvisual$return(DrawContext ctx, int width, Scoreboard sb, ScoreboardObjective obj, CallbackInfo ci) {
      if (Modules.TABLIST.cfg().enabled || Modules.TABANIM.cfg().enabled) {
         ctx.getMatrices().pop();
      }
   }
}

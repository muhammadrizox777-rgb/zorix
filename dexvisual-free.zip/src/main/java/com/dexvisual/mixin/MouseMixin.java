package com.dexvisual.mixin;

import com.dexvisual.util.Zoom;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseMixin {
   public MouseMixin() {
   }

   @Inject(
      method = {"onMouseScroll(JDD)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$scroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      if (Zoom.scroll(vertical)) {
         ci.cancel();
      }
   }
}

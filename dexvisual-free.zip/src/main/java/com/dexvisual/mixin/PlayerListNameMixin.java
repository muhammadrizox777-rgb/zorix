package com.dexvisual.mixin;

import com.dexvisual.net.SyncNet;
import net.minecraft.text.Text;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public class PlayerListNameMixin {
   public PlayerListNameMixin() {
   }

   @Inject(
      method = {"getPlayerName(Lnet/minecraft/client/network/PlayerListEntry;)Lnet/minecraft/text/Text;"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$dvTag(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
      try {
         if (entry == null || entry.getProfile() == null || !SyncNet.isDv(entry.getProfile().getId())) {
            return;
         }

         Text base = (Text)(cir.getReturnValue() != null
            ? (Text)cir.getReturnValue()
            : Text.literal(entry.getProfile().getName()));
         if (base.getString().contains("[DV]")) {
            return;
         }

         Text badge = Text.literal("[DV] ").styled(s -> s.withColor(4063152).withBold(true));
         cir.setReturnValue(Text.empty().append(badge).append(base));
      } catch (Throwable var5) {
      }
   }
}

package com.dexvisual.mixin;

import com.dexvisual.util.UndergroundCull;
import java.util.List;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.ChunkRenderingDataPreparer;
import net.minecraft.client.render.chunk.ChunkBuilder.BuiltChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChunkRenderingDataPreparer.class})
public class ChunkRenderingDataPreparerMixin {
   public ChunkRenderingDataPreparerMixin() {
   }

   @Inject(
      method = {"collectChunks"},
      at = {@At("RETURN")},
      require = 0
   )
   private void dexvisual$cullUnderground(Frustum frustum, List<BuiltChunk> builtChunks, List<BuiltChunk> nearbyChunks, CallbackInfo ci) {
      try {
         UndergroundCull.apply(builtChunks);
      } catch (Throwable var6) {
      }
   }
}

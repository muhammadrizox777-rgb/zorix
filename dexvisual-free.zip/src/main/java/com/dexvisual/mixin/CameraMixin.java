package com.dexvisual.mixin;

import com.dexvisual.util.Freelook;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({Camera.class})
public abstract class CameraMixin {
   private static final String UPDATE = "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V";
   private static final String SET_ROT = "Lnet/minecraft/client/render/Camera;setRotation(FF)V";

   public CameraMixin() {
   }

   @ModifyArg(
      method = {"update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"
      )},
      index = 0,
      require = 0
   )
   private float dexvisual$yaw(float yaw) {
      return Freelook.active ? Freelook.yaw : yaw;
   }

   @ModifyArg(
      method = {"update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"
      )},
      index = 1,
      require = 0
   )
   private float dexvisual$pitch(float pitch) {
      return Freelook.active ? Freelook.pitch : pitch;
   }
}

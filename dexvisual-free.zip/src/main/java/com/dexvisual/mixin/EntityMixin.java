package com.dexvisual.mixin;

import com.dexvisual.util.Freelook;
import com.dexvisual.util.Zoom;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Entity.class})
public abstract class EntityMixin {
   public EntityMixin() {
   }

   @Inject(
      method = {"changeLookDirection(DD)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$look(double dx, double dy, CallbackInfo ci) {
      Entity self = (Entity)this;
      if (self == MinecraftClient.getInstance().player) {
         if (Freelook.active) {
            Freelook.turn(dx, dy);
            ci.cancel();
         } else if (Zoom.active()) {
            float f = 0.15F / Zoom.factor();
            float oy = self.getYaw();
            float op = self.getPitch();
            self.setYaw(oy + (float)dx * f);
            self.setPitch(MathHelper.clamp(op + (float)dy * f, -90.0F, 90.0F));
            self.prevYaw = self.prevYaw + (self.getYaw() - oy);
            self.prevPitch = self.prevPitch + (self.getPitch() - op);
            ci.cancel();
         }
      }
   }
}

package com.dexvisual.mixin;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.cosmetics.Cosmetic;
import com.dexvisual.cosmetics.Cosmetics;
import com.dexvisual.module.Modules;
import com.dexvisual.util.HandShader;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerEntityRenderer.class})
public class PlayerEntityRendererMixin {
   private static final String ARM = "renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V";
   private static final String TEX = "getTexture(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;";
   private static final Identifier WHITE = Identifier.of("dexvisual", "textures/cosmetics/white.png");

   public PlayerEntityRendererMixin() {
   }

   private static Identifier dexvisual$preset(Identifier cur) {
      try {
         String id = Cosmetics.selectedId("skins");
         if (id != null && cur != null) {
            Cosmetic c = Cosmetics.find("skins", id);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (c == null || c.tex == null || mc.player == null) {
               return cur;
            } else {
               return !cur.equals(mc.player.getSkinTextures().comp_1626()) ? cur : Identifier.of("dexvisual", "textures/skins/" + c.tex + ".png");
            }
         } else {
            return cur;
         }
      } catch (Throwable var4) {
         return cur;
      }
   }

   @Inject(
      method = {"method_4216(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$skinPreset(PlayerEntityRenderState state, CallbackInfoReturnable<Identifier> cir) {
      Identifier now = dexvisual$preset((Identifier)cir.getReturnValue());
      if (now != cir.getReturnValue()) {
         cir.setReturnValue(now);
      }
   }

   private static int lerpWhite(int rgb, float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      int r = (int)((rgb >> 16 & 0xFF) * (1.0F - t) + 255.0F * t);
      int g = (int)((rgb >> 8 & 0xFF) * (1.0F - t) + 255.0F * t);
      int b = (int)((rgb & 0xFF) * (1.0F - t) + 255.0F * t);
      return r << 16 | g << 8 | b;
   }

   @Inject(
      method = {"renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V"},
      at = {@At("HEAD")},
      require = 0
   )
   private void dexvisual$handGlow(MatrixStack matrices, VertexConsumerProvider vcp, int light, Identifier tex, ModelPart arm, boolean sleeve, CallbackInfo ci) {
      try {
         if (Modules.HANDS == null || !Modules.HANDS.cfg().enabled || Modules.optimizing()) {
            return;
         }

         ModuleSettings s = Modules.HANDS.cfg();
         int rgb = HandShader.glowColor();
         float str = Math.max(0.2F, Math.min(2.0F, s.val <= 0.01F ? 1.0F : s.val));
         arm.pitch = 0.0F;
         arm.yaw = 0.0F;
         arm.roll = arm.pivotX < 0.0F ? 0.1F : -0.1F;
         VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityTranslucentEmissive(WHITE));
         int N = 18;
         float dMin = 0.02F;
         float dMax = 0.22F;
         arm.forEachCuboid(matrices, (entry, name, index, cuboid) -> {
            float cx = (cuboid.minX + cuboid.maxX) / 32.0F;
            float cy = (cuboid.minY + cuboid.maxY) / 32.0F;
            float cz = (cuboid.minZ + cuboid.maxZ) / 32.0F;
            float w = cuboid.maxX - cuboid.minX;
            float h = cuboid.maxY - cuboid.minY;
            float d = cuboid.maxZ - cuboid.minZ;

            for (int k = 0; k < 18; k++) {
               float t = k / 17.0F;
               float expand = 0.02F + 0.2F * (float)Math.pow(1.0F - t, 1.4F);
               float al;
               if (k == 17) {
                  al = 0.88F * str;
               } else if (k == 16) {
                  al = 0.74F * str;
               } else {
                  al = (0.025F + 0.6F * (float)Math.pow(t, 2.0)) * str;
               }

               al = Math.max(0.0F, Math.min(1.0F, al));
               int col = t > 0.8F ? lerpWhite(rgb, (t - 0.8F) / 0.2F * 0.4F) : rgb;
               int argb = Math.round(al * 255.0F) << 24 | col & 16777215;
               float sx = 1.0F + 2.0F * expand / w;
               float sy = 1.0F + 2.0F * expand / h;
               float sz = 1.0F + 2.0F * expand / d;
               matrices.push();
               matrices.translate(cx, cy, cz);
               matrices.scale(sx, sy, sz);
               matrices.translate(-cx, -cy, -cz);
               cuboid.renderCuboid(matrices.peek(), vc, 15728880, OverlayTexture.DEFAULT_UV, argb);
               matrices.pop();
            }
         });
         if (vcp instanceof Immediate imm) {
            imm.draw(RenderLayer.getEntityTranslucentEmissive(WHITE));
         }
      } catch (Throwable var16) {
      }
   }

   @ModifyVariable(
      method = {"renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V"},
      at = {@At("HEAD")},
      argsOnly = true,
      require = 0
   )
   private Identifier dexvisual$handTexture(Identifier original) {
      if (Modules.HANDS != null && Modules.HANDS.cfg().enabled) {
         Identifier id = HandShader.texture();
         return id == null ? dexvisual$preset(original) : id;
      } else {
         return dexvisual$preset(original);
      }
   }

   @ModifyVariable(
      method = {"renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V"},
      at = {@At("HEAD")},
      argsOnly = true,
      require = 0
   )
   private boolean dexvisual$handSleeve(boolean sleeveVisible) {
      return Modules.HANDS != null && Modules.HANDS.cfg().enabled ? false : sleeveVisible;
   }
}

package com.dexvisual.mixin;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import com.dexvisual.util.UiAnim;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.util.Formatting;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChatHud.class})
public class ChatHudMixin {
   public ChatHudMixin() {
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;IIIZ)V"},
      at = {@At("HEAD")},
      require = 0
   )
   private void dexvisual$head(DrawContext ctx, int tick, int mx, int my, boolean focused, CallbackInfo ci) {
      ModuleSettings s = Modules.CHAT.cfg();
      boolean anim = Modules.CHATANIM.cfg().enabled;
      if (s.enabled || anim) {
         float ax = 0.0F;
         float ay = MinecraftClient.getInstance().getWindow().getScaledHeight() - 35.0F;
         ctx.getMatrices().push();
         if (s.enabled) {
            ctx.getMatrices().translate(ax + s.offX, ay + s.offY, 0.0F);
            ctx.getMatrices().scale(s.scale, s.scale, 1.0F);
            ctx.getMatrices().translate(-ax, -ay, 0.0F);
         }

         if (anim) {
            float p = UiAnim.chat(focused);
            ctx.getMatrices().translate(-(1.0F - p) * 14.0F, (1.0F - p) * 9.0F, 0.0F);
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;IIIZ)V"},
      at = {@At("RETURN")},
      require = 0
   )
   private void dexvisual$return(DrawContext ctx, int tick, int mx, int my, boolean focused, CallbackInfo ci) {
      if (Modules.CHAT.cfg().enabled || Modules.CHATANIM.cfg().enabled) {
         ctx.getMatrices().pop();
      }
   }

   @ModifyVariable(
      method = {"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"},
      at = {@At("HEAD")},
      argsOnly = true,
      require = 0
   )
   private Text dexvisual$timestamp(Text message) {
      ModuleSettings s = Modules.CHAT.cfg();
      return (Text)(s.enabled && s.option
         ? Text.literal("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + "] ")
            .formatted(Formatting.field_1080)
            .append(message)
         : message);
   }
}

package com.dexvisual.mixin;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import com.dexvisual.util.Zoom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GameRenderer.class})
public class GameRendererMixin {
   public GameRendererMixin() {
   }

   @Inject(
      method = {"getFov(Lnet/minecraft/client/render/Camera;FZ)F"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
      cir.setReturnValue(Zoom.apply((Float)cir.getReturnValue()));
   }

   @Inject(
      method = {"getBasicProjectionMatrix(F)Lorg/joml/Matrix4f;"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void dexvisual$aspect(float fov, CallbackInfoReturnable<Matrix4f> cir) {
      if (Modules.ASPECT != null) {
         ModuleSettings s = Modules.ASPECT.cfg();
         if (s.enabled && !(s.val < 0.3F)) {
            MinecraftClient mc = MinecraftClient.getInstance();
            float actual = (float)mc.getWindow().getFramebufferWidth() / Math.max(1, mc.getWindow().getFramebufferHeight());
            Matrix4f m = (Matrix4f)cir.getReturnValue();
            m.scale(actual / s.val, 1.0F, 1.0F);
            cir.setReturnValue(m);
         }
      }
   }
}

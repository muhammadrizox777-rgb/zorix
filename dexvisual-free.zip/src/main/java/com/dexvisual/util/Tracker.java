package com.dexvisual.util;

import com.dexvisual.config.DexConfig;
import java.lang.management.ManagementFactory;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class Tracker {
   public static final long SESSION_START = System.currentTimeMillis();
   private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
   private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
   private static boolean lDown;
   private static boolean rDown;
   public static boolean leftHeld;
   public static boolean rightHeld;
   public static int combo;
   public static int maxCombo;
   public static int kills;
   public static int hits;
   public static int streak;
   public static LivingEntity target;
   public static long lastAttackMs;
   public static long lastHitMs;
   public static float lastHealth;
   public static double lastReach;
   public static boolean counted;
   public static long hitFlashUntil;
   public static long previewHitUntil;
   public static final List<Tracker.Floating> FLOATS = new ArrayList<>();
   private static int prevHurt;
   public static double distance;
   private static double lx;
   private static double lz;
   private static boolean hasLast;
   private static final ArrayDeque<Float> FRAMES = new ArrayDeque<>();
   private static long lastFrameNs;
   public static int avgFps;
   public static int lowFps;
   public static float frameMs;
   public static float cpu = 0.0F;
   private static int cpuTimer;
   public static boolean openMenuNext;
   public static boolean openEditorNext;
   private static int saveTimer;

   private Tracker() {
   }

   public static void frame(MinecraftClient mc) {
      long now = System.nanoTime();
      if (lastFrameNs != 0L) {
         float ms = (float)(now - lastFrameNs) / 1000000.0F;
         if (ms < 1000.0F) {
            FRAMES.addLast(ms);
            if (FRAMES.size() > 400) {
               FRAMES.removeFirst();
            }

            frameMs = frameMs * 0.9F + ms * 0.1F;
         }
      }

      lastFrameNs = now;
      if (mc.currentScreen == null && mc.player != null) {
         long h = mc.getWindow().getHandle();
         boolean l = GLFW.glfwGetMouseButton(h, 0) == 1;
         boolean r = GLFW.glfwGetMouseButton(h, 1) == 1;
         long t = System.currentTimeMillis();
         if (l && !lDown) {
            LEFT.addLast(t);
         }

         if (r && !rDown) {
            RIGHT.addLast(t);
         }

         lDown = l;
         rDown = r;
         leftHeld = l;
         rightHeld = r;
      } else {
         rightHeld = false;
         leftHeld = false;
         rDown = false;
         lDown = false;
      }
   }

   private static int count(ArrayDeque<Long> q) {
      long now = System.currentTimeMillis();

      while (!q.isEmpty() && now - q.peekFirst() > 1000L) {
         q.removeFirst();
      }

      return q.size();
   }

   public static int cpsLeft() {
      return count(LEFT);
   }

   public static int cpsRight() {
      return count(RIGHT);
   }

   public static float[] recentFrames(int n) {
      Float[] all = FRAMES.toArray(new Float[0]);
      int from = Math.max(0, all.length - n);
      float[] out = new float[all.length - from];

      for (int i = from; i < all.length; i++) {
         out[i - from] = all[i];
      }

      return out;
   }

   public static void onAttack(LivingEntity e) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if (target != e) {
            target = e;
            lastHealth = e.getHealth();
            counted = false;
         }

         lastAttackMs = System.currentTimeMillis();
         lastReach = mc.player.distanceTo(e);
      }
   }

   public static void tick(MinecraftClient mc) {
      Notifications.tick();
      long now = System.currentTimeMillis();
      FLOATS.removeIf(f -> now - f.start > 1200L);
      if (++saveTimer >= 100) {
         saveTimer = 0;
         if (DexConfig.dirty) {
            DexConfig.get().save();
         }
      }

      if (mc.player != null && mc.world != null && FRAMES.size() > 20 && mc.player.age % 10 == 0) {
         float[] arr = new float[FRAMES.size()];
         int i = 0;
         float sum = 0.0F;

         for (float f : FRAMES) {
            arr[i++] = f;
            sum += f;
         }

         avgFps = Math.round(1000.0F / Math.max(0.1F, sum / arr.length));
         Arrays.sort(arr);
         int worst = Math.max(1, arr.length / 100);
         float ws = 0.0F;

         for (int k = 0; k < worst; k++) {
            ws += arr[arr.length - 1 - k];
         }

         lowFps = Math.round(1000.0F / Math.max(0.1F, ws / worst));
      }

      if (++cpuTimer >= 20) {
         cpuTimer = 0;
         cpu = sampleCpu();
      }

      if (mc.player != null && mc.world != null) {
         double px = mc.player.getX();
         double pz = mc.player.getZ();
         if (hasLast) {
            double d = Math.hypot(px - lx, pz - lz);
            if (d < 20.0) {
               distance += d;
            }
         }

         lx = px;
         lz = pz;
         hasLast = true;
         LivingEntity t = target;
         if (t != null) {
            float hp = t.getHealth();
            if (!t.isDead() && hp > 0.0F && hp < lastHealth - 0.01F && now - lastAttackMs < 2500L) {
               float d = lastHealth - hp;
               hits++;
               combo++;
               maxCombo = Math.max(maxCombo, combo);
               lastHitMs = now;
               hitFlashUntil = now + 250L;
               FLOATS.add(new Tracker.Floating("-" + String.format("%.1f", d), now));
            }

            lastHealth = hp;
            if (!counted && (t.isDead() || hp <= 0.0F || t.isRemoved()) && now - lastAttackMs < 5000L) {
               counted = true;
               kills++;
               streak++;
               Notifications.push("Kill", I18n.tr("You eliminated ") + t.getName().getString(), 16731501);
               KillFx.spawn(t);
            }

            if (now - lastAttackMs > 8000L && mc.targetedEntity != t) {
               target = null;
            }
         }

         if (combo > 0 && now - lastHitMs > 3000L) {
            combo = 0;
         }

         if (mc.player.hurtTime > 0 && prevHurt == 0) {
            combo = 0;
         }

         prevHurt = mc.player.hurtTime;
         if (mc.player.isDead()) {
            streak = 0;
         }
      } else {
         hasLast = false;
      }
   }

   private static float sampleCpu() {
      try {
         Object bean = ManagementFactory.getOperatingSystemMXBean();
         Class<?> cls = Class.forName("com.sun.management.OperatingSystemMXBean");
         if (cls.isInstance(bean)) {
            double v = (Double)cls.getMethod("getProcessCpuLoad").invoke(bean);
            if (v >= 0.0) {
               return (float)(v * 100.0);
            }
         }
      } catch (Throwable var4) {
      }

      return 0.0F;
   }

   public static String sessionTime() {
      long s = (System.currentTimeMillis() - SESSION_START) / 1000L;
      return s >= 3600L ? String.format("%dh %02dm %02ds", s / 3600L, s / 60L % 60L, s % 60L) : String.format("%dm %02ds", s / 60L, s % 60L);
   }

   public static String usedRam() {
      Runtime r = Runtime.getRuntime();
      return String.format("%.1f/%.1f GB", (r.totalMemory() - r.freeMemory()) / 1.0737418E9F, r.maxMemory() / 1.0737418E9F);
   }

   public static float ramPercent() {
      Runtime r = Runtime.getRuntime();
      return (float)(r.totalMemory() - r.freeMemory()) / (float)r.maxMemory();
   }

   public static final class Floating {
      public final String text;
      public final long start;

      public Floating(String text, long start) {
         this.text = text;
         this.start = start;
      }
   }
}

package com.dexvisual.util;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public final class Projector {
   private static final Matrix4f VIEW = new Matrix4f();
   private static final Matrix4f PROJ = new Matrix4f();
   private static Vec3d cam = Vec3d.ZERO;
   private static boolean valid;

   private Projector() {
   }

   public static void capture(WorldRenderContext ctx) {
      VIEW.set(ctx.positionMatrix());
      PROJ.set(ctx.projectionMatrix());
      cam = ctx.camera().getPos();
      valid = true;
   }

   public static int[] project(Vec3d p) {
      if (!valid) {
         return null;
      } else {
         MinecraftClient mc = MinecraftClient.getInstance();
         Vector4f v = new Vector4f((float)(p.x - cam.x), (float)(p.y - cam.y), (float)(p.z - cam.z), 1.0F);
         VIEW.transform(v);
         PROJ.transform(v);
         if (v.w <= 0.01F) {
            return null;
         } else {
            float nx = v.x / v.w;
            float ny = v.y / v.w;
            int sx = Math.round((nx * 0.5F + 0.5F) * mc.getWindow().getScaledWidth());
            int sy = Math.round((1.0F - (ny * 0.5F + 0.5F)) * mc.getWindow().getScaledHeight());
            return new int[]{sx, sy};
         }
      }
   }
}

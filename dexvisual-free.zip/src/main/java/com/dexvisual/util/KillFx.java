package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.cosmetics.Cosmetics;
import com.dexvisual.gui.Theme;
import com.dexvisual.module.Modules;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;

public final class KillFx {
   public static final String[] STYLES = new String[]{"Bloom Burst", "Shockwave", "Lightning", "Soul Rise", "Shadow Slash", "Ice Burst", "Fire Explosion"};
   private static final long[] LIFE = new long[]{1500L, 1350L, 1150L, 2200L, 1400L, 1300L, 1500L};
   private static final int MAX_ACTIVE = 3;
   public static final List<KillFx.Fx> LIST = new ArrayList<>();
   private static long pendingTest;

   private KillFx() {
   }

   private static int style() {
      return MathHelper.clamp(Math.round(Modules.KILLFX.cfg().val), 0, STYLES.length - 1);
   }

   private static int cosStyle() {
      String id = Cosmetics.selectedId("killfx");
      if (id == null) {
         return -1;
      } else {
         return switch (id) {
            case "shadowslash" -> 4;
            case "iceburst" -> 5;
            case "fireexplosion" -> 6;
            default -> -1;
         };
      }
   }

   public static boolean cosmeticOn() {
      return cosStyle() >= 0;
   }

   private static int styleColor(int style, boolean second, int fallback) {
      return switch (style) {
         case 4 -> second ? 5975200 : 10178047;
         case 5 -> second ? 14678271 : 5818623;
         case 6 -> second ? 16765498 : 16734730;
         default -> fallback;
      };
   }

   private static float speed() {
      return MathHelper.clamp(Modules.KILLFX.cfg().val2, 0.4F, 3.0F);
   }

   public static void spawn(LivingEntity e) {
      spawnAt(e.getX(), e.getY(), e.getZ(), e.getHeight());
   }

   private static void spawnAt(double x, double y, double z, float h) {
      if (Modules.KILLFX != null && !Modules.optimizing()) {
         int cs = cosStyle();
         if (Modules.KILLFX.cfg().enabled || cs >= 0) {
            long now = System.currentTimeMillis();

            for (KillFx.Fx f : LIST) {
               if (now - f.start < 600L && Math.abs(f.x - x) < 2.0 && Math.abs(f.z - z) < 2.0) {
                  return;
               }
            }

            while (LIST.size() >= 3) {
               LIST.remove(0);
            }

            int st = cs >= 0 ? cs : style();
            long life = (long)((float)LIFE[st] / speed());
            LIST.add(new KillFx.Fx(x, y, z, Math.max(0.6F, h), now, life, st, now ^ Double.doubleToLongBits(x * 31.7 + z)));
            if (!Modules.KILLFX.cfg().option) {
               sound(x, y, z, st);
            }
         }
      }
   }

   private static void sound(double x, double y, double z, int st) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null) {
         try {
            SoundEvent s = switch (st) {
               case 1 -> SoundEvents.field_14917;
               case 2 -> SoundEvents.field_14865;
               case 3 -> SoundEvents.field_26980;
               case 4 -> SoundEvents.field_14706;
               case 5 -> SoundEvents.field_15081;
               case 6 -> SoundEvents.field_15013;
               default -> SoundEvents.field_14709;
            };
            float vol = st == 2 ? 0.5F : 0.7F;
            float pitch = st == 3 ? 0.8F : (st == 1 ? 0.9F : 1.15F);
            mc.world.playSound(x, y, z, s, SoundCategory.field_15248, vol, pitch, false);
         } catch (Throwable var11) {
         }
      }
   }

   public static void test() {
      MinecraftClient mc = MinecraftClient.getInstance();
      mc.setScreen(null);
      pendingTest = System.currentTimeMillis() + 250L;
   }

   public static void tick(MinecraftClient mc) {
      long now = System.currentTimeMillis();
      LIST.removeIf(f -> now - f.start > f.life);
      if (pendingTest != 0L && now >= pendingTest) {
         pendingTest = 0L;
         if (mc.player != null && mc.world != null) {
            Vec3d look = mc.player.getRotationVec(1.0F);
            double x = mc.player.getX() + look.x * 4.0;
            double z = mc.player.getZ() + look.z * 4.0;
            spawnAt(x, mc.player.getY(), z, 1.8F);
         }
      }
   }

   private static float rnd(long seed, int i) {
      long h = seed * -7046029254386353131L + i * -4658895280553007687L;
      h ^= h >>> 31;
      h *= -7723592293110705685L;
      h ^= h >>> 29;
      return (float)(h >>> 40 & 16777215L) / 1.6777216E7F;
   }

   private static int[] colors() {
      ModuleSettings cfg = Modules.KILLFX.cfg();
      int c1 = cfg.option2 ? cfg.textColor & 16777215 : Theme.rgb(Theme.a1());
      int c2 = cfg.option2 ? Gfx.lerp(0xFF000000 | c1, -1, 0.5F) & 16777215 : Theme.rgb(Theme.a2());
      return new int[]{c1, c2};
   }

   private static int mix(int a, int b, float t) {
      return Gfx.lerp(0xFF000000 | a, 0xFF000000 | b, t) & 16777215;
   }

   private static float r(int rgb) {
      return (rgb >> 16 & 0xFF) / 255.0F;
   }

   private static float g(int rgb) {
      return (rgb >> 8 & 0xFF) / 255.0F;
   }

   private static float b(int rgb) {
      return (rgb & 0xFF) / 255.0F;
   }

   private static void box(VertexConsumer vc, MatrixStack ms, double x0, double y0, double z0, double x1, double y1, double z1, int rgb, float a) {
      if (!(a < 0.01F)) {
         VertexRendering.drawFilledBox(ms, vc, x0, y0, z0, x1, y1, z1, r(rgb), g(rgb), b(rgb), Math.min(1.0F, a));
      }
   }

   public static void world(Immediate imm, MatrixStack ms, MinecraftClient mc) {
      int[] col = colors();
      int c1 = col[0];
      int c2 = col[1];
      float size = MathHelper.clamp(Modules.KILLFX.cfg().scale, 0.4F, 3.0F);
      long now = System.currentTimeMillis();

      for (KillFx.Fx f : LIST) {
         float a = (float)(now - f.start) / (float)f.life;
         if (!(a < 0.0F) && !(a >= 1.0F)) {
            int p1 = styleColor(f.style, false, c1);
            int p2 = styleColor(f.style, true, c2);
            switch (f.style) {
               case 0:
                  bloom(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 1:
                  shock(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 2:
                  lightning(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 3:
               default:
                  soul(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 4:
                  shadowSlash(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 5:
                  iceBurst(imm, ms, f, a, p1, p2, size, now);
                  break;
               case 6:
                  fireBlast(imm, ms, f, a, p1, p2, size, now);
            }
         }
      }
   }

   private static void wave(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, float delay, float maxR, int c1, int c2, float size, long now) {
      float k = (a - delay) / (1.0F - delay);
      if (!(k <= 0.0F) && !(k >= 1.0F)) {
         float radius = (0.3F + maxR * Gfx.ease(k)) * size;
         float alpha = (float)Math.pow(1.0F - k, 1.4);
         WorldOverlay.ring(imm, ms, f.x, f.y, f.z, radius, 0.2F * (1.0F - 0.6F * k) * size, c1, c2, alpha * 0.9F, now);
      }
   }

   private static void sparks(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, int count) {
      float s = a * (float)f.life / 1000.0F;
      float drag = (1.0F - (float)Math.exp(-2.5F * s)) / 2.5F;
      float alpha = (float)Math.pow(1.0F - a, 1.2);
      if (!(alpha < 0.02F)) {
         float half = 0.04F * (1.0F - 0.6F * a) * size;
         VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

         for (int i = 0; i < count; i++) {
            float ang = rnd(f.seed, i * 3) * (float) (Math.PI * 2);
            float sp = (1.2F + rnd(f.seed, i * 3 + 1) * 3.4F) * size;
            float up = 2.2F + rnd(f.seed, i * 3 + 2) * 4.2F;
            double x = f.x + MathHelper.cos(ang) * sp * drag;
            double z = f.z + MathHelper.sin(ang) * sp * drag;
            double y = f.y + f.h * 0.5 + up * s - 4.5 * s * s;
            if (y < f.y + 0.03) {
               y = f.y + 0.03;
            }

            int rgb = (i & 1) == 0 ? mix(c1, 16777215, 0.55F) : mix(c2, 16777215, 0.25F);
            box(vc, ms, x - half, y - half, z - half, x + half, y + half, z + half, rgb, alpha);
         }

         imm.draw(RenderLayer.getDebugFilledBox());
      }
   }

   private static void bloom(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      double cy = f.y + f.h * 0.55;
      float grow = Gfx.ease(Math.min(1.0F, a * 1.6F));
      float fade = (float)Math.pow(1.0F - a, 1.6);
      float half0 = (0.18F + 1.25F * grow) * size;
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

      for (int l = 0; l < 3; l++) {
         float h = half0 * (1.0F - 0.28F * l);
         float ang = (float)now / (520.0F - l * 140.0F) * 57.2958F * (l % 2 == 0 ? 1.0F : -1.0F) * 0.12F;
         ms.push();
         ms.translate(f.x, cy, f.z);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ang));
         ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(45.0F));
         ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(35.0F + l * 20.0F));
         box(vc, ms, -h, -h, -h, h, h, h, mix(c1, 16777215, 0.3F + 0.3F * l), fade * (0.3F - l * 0.07F));
         ms.pop();
      }

      float core = 0.12F * (1.0F - a) * size;
      box(vc, ms, f.x - core, cy - core, f.z - core, f.x + core, cy + core, f.z + core, 16777215, fade * 0.9F);
      imm.draw(RenderLayer.getDebugFilledBox());
      wave(imm, ms, f, a, 0.0F, 3.2F, c1, c2, size, now);
      wave(imm, ms, f, a, 0.18F, 3.0F, c2, c1, size, now);
      sparks(imm, ms, f, a, c1, c2, size, 30);
   }

   private static void shock(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      wave(imm, ms, f, a, 0.0F, 4.2F, c1, c2, size, now);
      wave(imm, ms, f, a, 0.14F, 3.6F, c2, c1, size, now);
      wave(imm, ms, f, a, 0.28F, 3.0F, c1, c2, size, now);
      float fade = (float)Math.pow(1.0F - a, 2.0);
      float w = (0.25F + 0.3F * Gfx.ease(a)) * size;
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());
      box(vc, ms, f.x - w, f.y, f.z - w, f.x + w, f.y + f.h * (0.4 + 0.8 * Gfx.ease(a)), f.z + w, mix(c1, 16777215, 0.5F), fade * 0.35F);
      imm.draw(RenderLayer.getDebugFilledBox());
      sparks(imm, ms, f, a, c1, c2, size, 22);
   }

   private static void lightning(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      if (a < 0.42F) {
         float fade = 1.0F - a / 0.42F;
         float flick = (now / 55L & 1L) == 0L ? 1.0F : 0.65F;
         float al = fade * flick;
         int segs = 11;
         double top = f.y + 24.0;
         double segH = 24.0 / segs;
         double px = f.x;
         double pz = f.z;
         float w = 0.06F * size;
         VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

         for (int i = 0; i < segs; i++) {
            double y1 = top - i * segH;
            double y0 = y1 - segH;
            float amp = i >= segs - 1 ? 0.0F : 1.1F * (1.0F - (float)i / segs) * size;
            double nx = f.x + (rnd(f.seed, 100 + i) - 0.5F) * 2.0F * amp;
            double nz = f.z + (rnd(f.seed, 200 + i) - 0.5F) * 2.0F * amp;
            box(vc, ms, nx - w * 3.6, y0, nz - w * 3.6, nx + w * 3.6, y1, nz + w * 3.6, c1, al * 0.22F);
            box(vc, ms, nx - w, y0, nz - w, nx + w, y1, nz + w, 16777215, al);
            box(vc, ms, Math.min(px, nx) - w, y1 - w * 2.0F, Math.min(pz, nz) - w, Math.max(px, nx) + w, y1, Math.max(pz, nz) + w, 16777215, al);
            px = nx;
            pz = nz;
         }

         imm.draw(RenderLayer.getDebugFilledBox());
      }

      wave(imm, ms, f, a, 0.0F, 3.0F, c1, c2, size, now);
      sparks(imm, ms, f, a, c1, c2, size, 20);
   }

   private static void soul(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      float rise = Gfx.ease(Math.min(1.0F, a * 1.4F));
      float fade = a < 0.12F ? a / 0.12F : (float)Math.pow(1.0F - (a - 0.12F) / 0.88F, 1.3);
      float w = 0.2F * (1.0F - 0.55F * a) * size;
      double hgt = (1.2 + 7.5 * rise) * size;
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());
      box(vc, ms, f.x - w * 2.4, f.y, f.z - w * 2.4, f.x + w * 2.4, f.y + hgt, f.z + w * 2.4, c1, fade * 0.12F);
      box(vc, ms, f.x - w * 1.5, f.y, f.z - w * 1.5, f.x + w * 1.5, f.y + hgt, f.z + w * 1.5, mix(c1, 16777215, 0.3F), fade * 0.18F);
      box(vc, ms, f.x - w * 0.55, f.y, f.z - w * 0.55, f.x + w * 0.55, f.y + hgt, f.z + w * 0.55, 16777215, fade * 0.55F);
      int orbs = 10;

      for (int i = 0; i < orbs; i++) {
         float k = (float)i / orbs;
         float ang = k * 6.2832F * 1.5F + a * 9.0F;
         float rad = (0.55F - 0.25F * a) * size * (0.7F + 0.3F * (float)Math.sin(k * 6.0F));
         double y = f.y + 0.2 + (a * 3.0 + k * 2.6) * size * (0.6 + 0.4 * rise);
         double x = f.x + MathHelper.cos(ang) * rad;
         double z = f.z + MathHelper.sin(ang) * rad;
         float hs = 0.07F * size * (1.0F - 0.4F * k);
         box(vc, ms, x - hs, y - hs, z - hs, x + hs, y + hs, z + hs, mix(c2, 16777215, 0.5F), fade * 0.9F);
      }

      imm.draw(RenderLayer.getDebugFilledBox());
      wave(imm, ms, f, a, 0.0F, 2.4F, c1, c2, size, now);
   }

   private static void shadowSlash(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      double cy = f.y + f.h * 0.55;
      float fade = (float)Math.pow(1.0F - a, 1.5);
      float yaw = rnd(f.seed, 7) * 360.0F;
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

      for (int i = 0; i < 2; i++) {
         float sweep = Gfx.ease(Math.min(1.0F, Math.max(0.0F, a - i * 0.12F) * 2.6F));
         float len = (0.2F + 2.4F * sweep) * size;
         float th = 0.05F * (1.0F - 0.6F * a) * size;
         ms.push();
         ms.translate(f.x, cy, f.z);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
         ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i == 0 ? 35.0F : -35.0F));
         box(vc, ms, -len, -th * 5.0F, -th * 5.0F, len, th * 5.0F, th * 5.0F, c1, fade * 0.25F);
         box(vc, ms, -len, -th, -th, len, th, th, 16777215, fade * 0.95F);
         ms.pop();
      }

      for (int i = 0; i < 9; i++) {
         float ox = (rnd(f.seed, 300 + i) - 0.5F) * 1.2F * size;
         float oz = (rnd(f.seed, 400 + i) - 0.5F) * 1.2F * size;
         double y = f.y + 0.2 + (a * 2.4 + rnd(f.seed, 500 + i) * 0.8) * size;
         float hs = (0.12F + 0.3F * a) * size;
         box(vc, ms, f.x + ox - hs, y - hs, f.z + oz - hs, f.x + ox + hs, y + hs, f.z + oz + hs, c2, fade * 0.38F);
      }

      imm.draw(RenderLayer.getDebugFilledBox());
      wave(imm, ms, f, a, 0.0F, 2.6F, c1, c2, size, now);
      sparks(imm, ms, f, a, c1, c2, size, 18);
   }

   private static void iceBurst(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      float grow = Gfx.ease(Math.min(1.0F, a * 2.2F));
      float fade = (float)Math.pow(1.0F - a, 1.3);
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

      for (int i = 0; i < 14; i++) {
         float yaw = rnd(f.seed, i) * 360.0F;
         float tilt = 20.0F + rnd(f.seed, 40 + i) * 55.0F;
         float len = (0.6F + 1.7F * rnd(f.seed, 80 + i)) * grow * size;
         float w = (0.07F + 0.05F * rnd(f.seed, 120 + i)) * size;
         ms.push();
         ms.translate(f.x, f.y + 0.05, f.z);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
         ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(tilt));
         box(vc, ms, 0.0, -w * 1.8F, -w * 1.8F, len * 0.6F, w * 1.8F, w * 1.8F, c1, fade * 0.55F);
         box(vc, ms, len * 0.4F, -w, -w, len, w, w, mix(c2, 16777215, 0.4F), fade * 0.9F);
         ms.pop();
      }

      float core = (0.25F + 0.35F * grow) * (1.0F - a) * size;
      box(vc, ms, f.x - core, f.y + f.h * 0.5 - core, f.z - core, f.x + core, f.y + f.h * 0.5 + core, f.z + core, 16777215, fade * 0.8F);
      imm.draw(RenderLayer.getDebugFilledBox());
      wave(imm, ms, f, a, 0.0F, 3.4F, c1, c2, size, now);
      wave(imm, ms, f, a, 0.2F, 2.6F, c2, c1, size, now);
      sparks(imm, ms, f, a, c1, c2, size, 26);
   }

   private static void fireBlast(Immediate imm, MatrixStack ms, KillFx.Fx f, float a, int c1, int c2, float size, long now) {
      float grow = Gfx.ease(Math.min(1.0F, a * 1.8F));
      float fade = (float)Math.pow(1.0F - a, 1.4);
      double cy = f.y + f.h * 0.5 + 0.3 * grow;
      VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

      for (int l = 0; l < 3; l++) {
         float h = (0.25F + 1.5F * grow) * (1.0F - 0.27F * l) * size;
         ms.push();
         ms.translate(f.x, cy, f.z);
         ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)now / 9.0F * (l % 2 == 0 ? 1.0F : -1.0F)));
         ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(30.0F + l * 25.0F));
         box(vc, ms, -h, -h, -h, h, h, h, l == 0 ? c1 : (l == 1 ? mix(c1, c2, 0.5F) : c2), fade * (0.3F + 0.12F * l));
         ms.pop();
      }

      float core = 0.2F * (1.0F - a) * size;
      box(vc, ms, f.x - core, cy - core, f.z - core, f.x + core, cy + core, f.z + core, 16777215, fade * 0.9F);

      for (int i = 0; i < 7; i++) {
         float ox = (rnd(f.seed, 600 + i) - 0.5F) * 1.6F * size;
         float oz = (rnd(f.seed, 700 + i) - 0.5F) * 1.6F * size;
         double y = f.y + 0.4 + (a * 2.6 + rnd(f.seed, 800 + i) * 0.7) * size;
         float hs = (0.16F + 0.4F * a) * size;
         box(vc, ms, f.x + ox - hs, y - hs, f.z + oz - hs, f.x + ox + hs, y + hs, f.z + oz + hs, 2763310, fade * 0.38F);
      }

      imm.draw(RenderLayer.getDebugFilledBox());
      wave(imm, ms, f, a, 0.0F, 3.6F, c1, c2, size, now);
      wave(imm, ms, f, a, 0.12F, 3.0F, c2, c1, size, now);
      sparks(imm, ms, f, a, c1, c2, size, 34);
   }

   public static void hud(DrawContext c, MinecraftClient mc) {
      if (!LIST.isEmpty() && mc.world != null && mc.player != null) {
         ModuleSettings cfg = Modules.KILLFX.cfg();
         float flashK = MathHelper.clamp(cfg.val3, 0.0F, 1.0F);
         if (!(flashK < 0.02F)) {
            float size = MathHelper.clamp(cfg.scale, 0.4F, 3.0F);
            int[] col = colors();
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            long now = System.currentTimeMillis();

            for (KillFx.Fx f : LIST) {
               float a = (float)(now - f.start) / (float)f.life;
               if (!(a < 0.0F) && !(a >= 1.0F)) {
                  float env = a < 0.07F ? a / 0.07F : (float)Math.pow(1.0F - (a - 0.07F) / 0.93F, 2.0);

                  float str = switch (f.style) {
                     case 0 -> 1.0F;
                     default -> 0.3F;
                     case 2 -> 0.85F;
                     case 3 -> 0.45F;
                  };
                  if (f.style == 2) {
                     env = a < 0.42F ? (1.0F - a / 0.42F) * ((now / 55L & 1L) == 0L ? 1.0F : 0.7F) : 0.0F;
                  }

                  if (!(env < 0.01F)) {
                     Vec3d center = new Vec3d(f.x, f.y + f.h * 0.55, f.z);
                     double d = cam.distanceTo(center);
                     float near = MathHelper.clamp(4.5F / (float)Math.max(d, 0.5), 0.35F, 3.2F);
                     int[] p = Projector.project(center);
                     if (p != null) {
                        float rr = sh * 0.17F * near * size * (0.45F + 0.55F * Gfx.ease(Math.min(1.0F, a * 3.0F)));
                        glowDisc(c, p[0], p[1], Math.round(Math.min(rr, sh * 0.95F)), styleColor(f.style, false, col[0]), env * str * flashK, sw, sh);
                     }

                     float prox = MathHelper.clamp((near - 0.6F) / 2.6F, 0.0F, 1.0F);
                     if (prox > 0.02F && p != null) {
                        int al = Math.round(66.299995F * env * str * flashK * prox);
                        if (al > 2) {
                           c.fill(0, 0, sw, sh, al << 24 | 16777215);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static void glowDisc(DrawContext c, int cx, int cy, int r, int rgb, float strength, int sw, int sh) {
      if (r >= 4 && !(strength < 0.01F)) {
         int L = 14;
         int step = r > 160 ? 3 : 2;

         for (int i = 0; i < 14; i++) {
            float k = i / 13.0F;
            int rr = Math.round(r * (1.0F - 0.93F * k));
            int tint = mix(rgb, 16777215, k * k * 0.95F);
            int color = Gfx.argb(tint, strength * 0.11F);
            if (color >>> 24 != 0) {
               int y0 = Math.max(cy - rr, 0);
               int y1 = Math.min(cy + rr, sh);

               for (int y = y0; y < y1; y += step) {
                  int dy = y + step / 2 - cy;
                  int hw = (int)Math.sqrt(Math.max(0L, (long)rr * rr - (long)dy * dy));
                  int xa = Math.max(0, cx - hw);
                  int xb = Math.min(sw, cx + hw);
                  if (xb > xa) {
                     c.fill(xa, y, xb, Math.min(y + step, y1), color);
                  }
               }
            }
         }
      }
   }

   public static final class Fx {
      final double x;
      final double y;
      final double z;
      final float h;
      final long start;
      final long life;
      final int style;
      final long seed;

      Fx(double x, double y, double z, float h, long start, long life, int style, long seed) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.h = h;
         this.start = start;
         this.life = life;
         this.style = style;
         this.seed = seed;
      }
   }
}

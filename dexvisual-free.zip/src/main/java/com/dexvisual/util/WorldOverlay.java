package com.dexvisual.util;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.cosmetics.CosmeticRenderer;
import com.dexvisual.gui.Theme;
import com.dexvisual.module.Modules;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import org.joml.Matrix4f;

public final class WorldOverlay {
   private WorldOverlay() {
   }

   public static void render(WorldRenderContext ctx) {
MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && mc.player != null) {
         boolean block = Modules.BLOCKOVERLAY.cfg().enabled;
         boolean land = Modules.PARTICLES.cfg().enabled && !Modules.ParticlesModule.LIST.isEmpty();
         boolean jump = !Modules.optimizing() && Modules.JUMPCIRCLES.cfg().enabled && !Modules.JumpCirclesModule.CIRCLES.isEmpty();
         boolean hat = Modules.CHINAHAT != null && Modules.CHINAHAT.cfg().enabled;
         boolean kfx = !Modules.optimizing() && Modules.KILLFX != null && (Modules.KILLFX.cfg().enabled || KillFx.cosmeticOn()) && !KillFx.LIST.isEmpty();
         boolean cos = CosmeticRenderer.active();
         boolean art = Modules.ARTIHELPER != null && Modules.ARTIHELPER.cfg().enabled && Modules.ArtiHelperModule.worldActive(mc);
         if (block || land || jump || hat || kfx || cos || art) {
            if (ctx.consumers() instanceof Immediate imm) {
               MatrixStack ms = ctx.matrixStack();
               if (ms != null) {
                  Vec3d cam = ctx.camera().getPos();
                  ms.push();
                  ms.translate(-cam.x, -cam.y, -cam.z);

                  try {
                     if (block && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == Type.field_1332) {
                        BlockPos pos = bhr.getBlockPos();
                        BlockState st = mc.world.getBlockState(pos);
                        VoxelShape shape = st.getOutlineShape(mc.world, pos);
                        if (!shape.isEmpty()) {
                           Box b = shape.getBoundingBox().offset(pos).expand(0.003);
                           ModuleSettings m = Modules.BLOCKOVERLAY.cfg();
                           int rgb = DexConfig.get().themeSync && !m.ownColor ? Theme.rgb(Theme.a1()) : m.textColor;
                           float pulse = 0.85F + 0.15F * (float)Math.sin(System.currentTimeMillis() / 380.0);
                           draw(imm, ms, b, rgb, m.val * pulse, 0.95F);
                        }
                     }

                     if (land) {
                        long now = System.currentTimeMillis();

                        for (Modules.ParticlesModule.Landing l : Modules.ParticlesModule.LIST) {
                           if (!(l.ticks() / 20.0 - (now - l.stamp()) / 1000.0 < -0.3)) {
                              Vec3d p = l.pos();
                              draw(
                                 imm,
                                 ms,
                                 new Box(
                                    p.x - 0.35, p.y, p.z - 0.35, p.x + 0.35, p.y + 0.06, p.z + 0.35
                                 ),
                                 l.color(),
                                 0.45F,
                                 1.0F
                              );
                           }
                        }
                     }

                     if (art) {
                        artiHelper(imm, ms, mc);
                     }

                     if (jump) {
                        jumpCircles(imm, ms);
                     }

                     if (hat) {
                        chinaHats(imm, ms, mc);
                     }

                     if (kfx) {
                        KillFx.world(imm, ms, mc);
                     }

                     if (cos) {
                        CosmeticRenderer.render(imm, ms, mc, ctx.camera());
                     }
                  } catch (Throwable var23) {
                  } finally {
                     ms.pop();
                  }
               }
            }
         }
      }
   
   }

   private static void artiHelper(Immediate imm, MatrixStack ms, MinecraftClient mc) {
      ModuleSettings cfg = Modules.ARTIHELPER.cfg();
      long now = System.currentTimeMillis();
      int hk = Modules.ArtiHelperModule.heldKind(mc.player);
      if (hk >= 0) {
         Box b = Modules.ArtiHelperModule.areaFor(hk, mc.player, cfg).expand(0.01);
         draw(imm, ms, b, (hk == 0 ? cfg.textColor : cfg.borderColor) & 16777215, 0.05F, 0.9F);
      }

      for (Modules.ArtiHelperModule.Timer t : Modules.ArtiHelperModule.TIMERS) {
         float left = (float)(t.end - now) / 1000.0F;
         if (!(left < -0.3F)) {
            int rgb = (t.kind == 0 ? cfg.textColor : cfg.borderColor) & 16777215;
            float pulse = 1.0F;
            if (left < 3.0F) {
               rgb = 16731501;
               pulse = 0.6F + 0.4F * (float)Math.sin(now / 90.0);
            }

            draw(imm, ms, t.box.expand(0.01), rgb, 0.07F * pulse, Math.max(0.3F, pulse));
         }
      }
   }

   private static void draw(Immediate imm, MatrixStack ms, Box b, int rgb, float fill, float line) {
      float r = (rgb >> 16 & 0xFF) / 255.0F;
      float g = (rgb >> 8 & 0xFF) / 255.0F;
      float bl = (rgb & 0xFF) / 255.0F;
      if (fill > 0.01F) {
         VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());
         VertexRendering.drawFilledBox(ms, vc, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, Math.min(1.0F, fill));
         imm.draw(RenderLayer.getDebugFilledBox());
      }

      VertexConsumer lc = imm.getBuffer(RenderLayer.getLines());
      VertexRendering.drawBox(ms, lc, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, line);
      imm.draw(RenderLayer.getLines());
   }

   private static void jumpCircles(Immediate imm, MatrixStack ms) {
      ModuleSettings cfg = Modules.JUMPCIRCLES.cfg();
      int c1 = cfg.option2 ? cfg.textColor & 16777215 : Theme.rgb(Theme.a1());
      int c2 = cfg.option2 ? Gfx.lerp(0xFF000000 | c1, -1, 0.5F) & 16777215 : Theme.rgb(Theme.a2());
      long now = System.currentTimeMillis();
      float size = Math.max(0.3F, cfg.scale);

      for (Modules.JumpCirclesModule.Circle c : Modules.JumpCirclesModule.CIRCLES) {
         float age = (float)(now - c.start()) / (float)c.life();
         if (!(age < 0.0F) && !(age >= 1.0F)) {
            float alpha = (float)Math.pow(1.0F - age, 1.4);
            float r = (0.25F + 1.35F * Gfx.ease(age)) * size;
            ring(imm, ms, c.x(), c.y(), c.z(), r, 0.24F, c1, c2, alpha * 0.2F, now);
            ring(imm, ms, c.x(), c.y(), c.z(), r, 0.07F * (1.0F - 0.5F * age), c1, c2, alpha, now);
         }
      }
   }

   static void ring(Immediate imm, MatrixStack ms, double cx, double cy, double cz, float radius, float thick, int c1, int c2, float alpha, long now) {
      if (!(alpha < 0.01F)) {
         VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());
         float t = thick / 2.0F;
         int n = Math.max(24, Math.min(260, (int)Math.ceil((Math.PI * 2) * radius / (t * 1.8F))));

         for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2.0 / n;
            float k = 0.5F + 0.5F * (float)Math.sin(a * 2.0 + now / 400.0);
            int rgb = Gfx.lerp(0xFF000000 | c1, 0xFF000000 | c2, k) & 16777215;
            double px = cx + Math.cos(a) * radius;
            double pz = cz + Math.sin(a) * radius;
            VertexRendering.drawFilledBox(
               ms,
               vc,
               px - t,
               cy + 0.02,
               pz - t,
               px + t,
               cy + 0.035,
               pz + t,
               (rgb >> 16 & 0xFF) / 255.0F,
               (rgb >> 8 & 0xFF) / 255.0F,
               (rgb & 0xFF) / 255.0F,
               Math.min(1.0F, alpha)
            );
         }

         imm.draw(RenderLayer.getDebugFilledBox());
      }
   }

   private static void chinaHats(Immediate imm, MatrixStack ms, MinecraftClient mc) {
      ModuleSettings cfg = Modules.CHINAHAT.cfg();
      int c1 = cfg.option2 ? cfg.textColor & 16777215 : Theme.rgb(Theme.a1());
      int c2 = cfg.option2 ? Gfx.lerp(0xFF000000 | c1, -1, 0.5F) & 16777215 : Theme.rgb(Theme.a2());
      float td = mc.getRenderTickCounter().getTickDelta(false);
      float size = Math.max(0.5F, cfg.scale);
      long now = System.currentTimeMillis();
      if (!mc.options.getPerspective().isFirstPerson()) {
         hat(imm, ms, mc.player, td, size, c1, c2, now);
      }

      if (cfg.option) {
         for (PlayerEntity p : mc.world.getPlayers()) {
            if (p != mc.player && !p.isInvisible() && !p.isSpectator() && !(p.squaredDistanceTo(mc.player) > 4096.0)) {
               hat(imm, ms, p, td, size, c1, c2, now);
            }
         }
      }
   }

   private static void hat(Immediate imm, MatrixStack ms, PlayerEntity p, float td, float size, int c1, int c2, long now) {
      Vec3d pos = p.getLerpedPos(td);
      double top = pos.y + p.getHeight() - 0.02;
      float R = 0.62F * size;
      float H = 0.3F * size;
      int n = 48;
      float pulse = 0.9F + 0.1F * (float)Math.sin(now / 500.0);
      int apex = Gfx.lerp(0xFF000000 | c1, -1, 0.4F) & 16777215;
      Matrix4f m = ms.peek().getPositionMatrix();

      for (int pass = 0; pass < 2; pass++) {
         VertexConsumer vc = imm.getBuffer(RenderLayer.getDebugFilledBox());

         for (int k = 0; k <= n; k++) {
            int i = pass == 0 ? k : n - k;
            double a = i * Math.PI * 2.0 / n;
            float kk = 0.5F + 0.5F * (float)Math.sin(a * 2.0 + now / 600.0);
            int rgb = Gfx.lerp(0xFF000000 | c1, 0xFF000000 | c2, kk) & 16777215;
            vc.vertex(m, (float)(pos.x + Math.cos(a) * R), (float)top, (float)(pos.z + Math.sin(a) * R))
               .color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, (int)(120.0F * pulse));
            vc.vertex(m, (float)pos.x, (float)(top + H), (float)pos.z)
               .color(apex >> 16 & 0xFF, apex >> 8 & 0xFF, apex & 0xFF, (int)(165.0F * pulse));
         }

         imm.draw(RenderLayer.getDebugFilledBox());
      }

      ring(imm, ms, pos.x, top - 0.02, pos.z, R, 0.035F * size, c1, c2, 0.85F, now);
   }
}

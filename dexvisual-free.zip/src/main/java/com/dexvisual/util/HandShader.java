package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;

public final class HandShader {
   public static final Identifier ID = Identifier.of("dexvisual", "hand_shader");
   private static NativeImageBackedTexture tex;
   private static NativeImage img;
   private static long last;
   public static final int DEFAULT_GLOW = 4063152;
   private static final int SKIN = 15257776;

   private HandShader() {
   }

   public static Identifier texture() {
      long now = System.currentTimeMillis();

      try {
         if (tex == null) {
            img = new NativeImage(64, 64, false);
            tex = new NativeImageBackedTexture(img);
            MinecraftClient.getInstance().getTextureManager().registerTexture(ID, tex);
            last = 0L;
         }

         if (now - last > 33L && (last == 0L || !Modules.optimizing())) {
            last = now;
            paint(now);
            tex.upload();
         }
      } catch (Throwable var3) {
         return null;
      }

      return ID;
   }

   private static int mix(int a, int b, float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      int r = (int)((a >> 16 & 0xFF) * (1.0F - t) + (b >> 16 & 0xFF) * t);
      int g = (int)((a >> 8 & 0xFF) * (1.0F - t) + (b >> 8 & 0xFF) * t);
      int bl = (int)((a & 0xFF) * (1.0F - t) + (b & 0xFF) * t);
      return r << 16 | g << 8 | bl;
   }

   public static boolean slim() {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         return mc.player != null && "SLIM".equals(String.valueOf(mc.player.getSkinTextures().comp_1629()));
      } catch (Throwable var1) {
         return false;
      }
   }

   public static int glowColor() {
      try {
         ModuleSettings st = Modules.HANDS.cfg();
         return (st.ownColor ? st.textColor : 4063152) & 16777215;
      } catch (Throwable var1) {
         return 4063152;
      }
   }

   private static void face(int u, int v, int w, int h, int glow, float pulse, int alpha) {
      for (int y = 0; y < h; y++) {
         for (int x = 0; x < w; x++) {
            int d = Math.min(Math.min(x, w - 1 - x), Math.min(y, h - 1 - y));
            float shade = 1.0F - 0.07F * ((float)y / Math.max(1, h - 1));
            int base = mix(0, 15257776, shade);
            img.setColorArgb(u + x, v + y, alpha << 24 | base);
         }
      }
   }

   private static void arm(int u0, int v0, boolean slim, int glow, float pulse, int alpha) {
      int fw = slim ? 3 : 4;
      face(u0 + 4, v0, fw, 4, glow, pulse, alpha);
      face(u0 + 4 + fw, v0, fw, 4, glow, pulse, alpha);
      face(u0, v0 + 4, 4, 12, glow, pulse, alpha);
      face(u0 + 4, v0 + 4, fw, 12, glow, pulse, alpha);
      face(u0 + 4 + fw, v0 + 4, 4, 12, glow, pulse, alpha);
      face(u0 + 8 + fw, v0 + 4, fw, 12, glow, pulse, alpha);
   }

   private static void paint(long now) {
      int glow = glowColor();
      float pulse = 1.0F;
      int alpha = 255;

      for (int y = 0; y < 64; y++) {
         for (int x = 0; x < 64; x++) {
            img.setColorArgb(x, y, alpha << 24 | 15257776);
         }
      }

      boolean slim = slim();
      arm(40, 16, slim, glow, pulse, alpha);
      arm(32, 48, slim, glow, pulse, alpha);
   }
}

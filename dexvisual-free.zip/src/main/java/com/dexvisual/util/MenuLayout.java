package com.dexvisual.util;

public record MenuLayout(int px, int py, int pw, int ph, int sbw, boolean compact) {
   public static MenuLayout compute(int width, int height, float scale) {
      width = Math.max(1, width);
      height = Math.max(1, height);
      float s = !Float.isNaN(scale) && !(scale <= 0.0F) ? Math.max(0.7F, Math.min(1.3F, scale)) : 1.0F;
      int availW = Math.max(1, width - 8);
      int availH = Math.max(1, height - 8);
      float tw = Math.max(520.0F, Math.min(900.0F, width * 0.66F)) * s;
      float th = Math.max(300.0F, Math.min(600.0F, height * 0.78F)) * s;
      int pw = Math.min(Math.round(tw), availW);
      int ph = Math.min(Math.round(th), availH);
      int px = (width - pw) / 2;
      int py = (height - ph) / 2;
      boolean compact = pw < 480;
      int sbw = compact ? 40 : (pw >= 700 ? 124 : 108);
      return new MenuLayout(px, py, pw, ph, sbw, compact);
   }
}

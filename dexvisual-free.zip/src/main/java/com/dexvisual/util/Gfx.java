package com.dexvisual.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public final class Gfx {
   public static float alpha = 1.0F;

   private Gfx() {
   }

   public static int argb(int rgb, float a) {
      int al = Math.round(MathHelper.clamp(a, 0.0F, 1.0F) * 255.0F);
      return al << 24 | rgb & 16777215;
   }

   public static int ga(int argb) {
      if (alpha >= 0.999F) {
         return argb;
      } else {
         int a = Math.round((argb >>> 24 & 0xFF) * alpha);
         return a << 24 | argb & 16777215;
      }
   }

   public static int lerp(int c1, int c2, float t) {
      int a = MathHelper.lerp(t, c1 >>> 24 & 0xFF, c2 >>> 24 & 0xFF);
      int r = MathHelper.lerp(t, c1 >> 16 & 0xFF, c2 >> 16 & 0xFF);
      int g = MathHelper.lerp(t, c1 >> 8 & 0xFF, c2 >> 8 & 0xFF);
      int b = MathHelper.lerp(t, c1 & 0xFF, c2 & 0xFF);
      return a << 24 | r << 16 | g << 8 | b;
   }

   private static float cov(float v) {
      return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
   }

   private static int scaleA(int color, float k) {
      int a = Math.round((color >>> 24 & 0xFF) * k);
      return a << 24 | color & 16777215;
   }

   private static void dot(DrawContext c, int x, int y, int color, float k) {
      if (!(k < 0.04F)) {
         c.fill(x, y, x + 1, y + 1, k >= 0.97F ? color : scaleA(color, k));
      }
   }

   private static void cornerRow(DrawContext c, int x, int rowY, int w, int r, int i, int color) {
      int jf = r;

      for (int j = 0; j < r; j++) {
         float d = (float)Math.hypot(r - j - 0.5, r - i - 0.5);
         float k = cov(r + 0.5F - d);
         if (k >= 0.9F) {
            jf = j;
            break;
         }

         dot(c, x + j, rowY, color, k);
         dot(c, x + w - 1 - j, rowY, color, k);
      }

      if (w - 2 * jf > 0) {
         c.fill(x + jf, rowY, x + w - jf, rowY + 1, color);
      }
   }

   public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
      rrect(c, x, y, w, h, r, color, color);
   }

   public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int top, int bottom) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         top = ga(top);
         bottom = ga(bottom);
         if (r == 0) {
            if (top == bottom) {
               c.fill(x, y, x + w, y + h, top);
            } else {
               for (int i = 0; i < h; i++) {
                  c.fill(x, y + i, x + w, y + i + 1, lerp(top, bottom, (float)i / Math.max(1, h - 1)));
               }
            }
         } else {
            if (top == bottom) {
               for (int i = 0; i < r; i++) {
                  cornerRow(c, x, y + i, w, r, i, top);
                  cornerRow(c, x, y + h - 1 - i, w, r, i, top);
               }

               if (h - 2 * r > 0) {
                  c.fill(x, y + r, x + w, y + h - r, top);
               }
            } else {
               for (int i = 0; i < h; i++) {
                  int col = lerp(top, bottom, (float)i / Math.max(1, h - 1));
                  if (i < r) {
                     cornerRow(c, x, y + i, w, r, i, col);
                  } else if (i >= h - r) {
                     cornerRow(c, x, y + i, w, r, h - 1 - i, col);
                  } else {
                     c.fill(x, y + i, x + w, y + i + 1, col);
                  }
               }
            }
         }
      }
   }

   public static void rborder(DrawContext c, int x, int y, int w, int h, int r, int thick, int color) {
      for (int k = 0; k < Math.max(1, thick); k++) {
         rborder1(c, x + k, y + k, w - 2 * k, h - 2 * k, Math.max(0, r - k), color);
      }
   }

   private static void rborder1(DrawContext c, int x, int y, int w, int h, int r, int color) {
      if (w > 0 && h > 0) {
         color = ga(color);
         if (r <= 0) {
            c.drawBorder(x, y, w, h, color);
         } else {
            r = Math.min(r, Math.min(w, h) / 2);
            if (w - 2 * r > 0) {
               c.fill(x + r, y, x + w - r, y + 1, color);
               c.fill(x + r, y + h - 1, x + w - r, y + h, color);
            }

            if (h - 2 * r > 0) {
               c.fill(x, y + r, x + 1, y + h - r, color);
               c.fill(x + w - 1, y + r, x + w, y + h - r, color);
            }

            for (int i = 0; i < r; i++) {
               for (int j = 0; j < r; j++) {
                  float d = (float)Math.hypot(r - j - 0.5, r - i - 0.5);
                  float k = cov(r + 0.5F - d) - cov(r - 0.5F - d);
                  if (!(k < 0.04F)) {
                     dot(c, x + j, y + i, color, k);
                     dot(c, x + w - 1 - j, y + i, color, k);
                     dot(c, x + j, y + h - 1 - i, color, k);
                     dot(c, x + w - 1 - j, y + h - 1 - i, color, k);
                  }
               }
            }
         }
      }
   }

   public static void gradFill(DrawContext c, int x, int y, int w, int h, int r, int c1, int c2, int dir) {
      if (w > 0 && h > 0) {
         if (dir >= 2 && h <= 8) {
            int from = dir == 2 ? c1 : c2;
            int to = dir == 2 ? c2 : c1;
            int step = w > 160 ? 3 : 2;

            for (int i = 0; i < w; i += step) {
               int x1 = Math.min(w, i + step);
               c.fill(x + i, y, x + x1, y + h, ga(lerp(from, to, (float)i / Math.max(1, w - 1))));
            }
         } else {
            if (dir != 1 && dir != 3) {
               rrect(c, x, y, w, h, r, c1, c2);
            } else {
               rrect(c, x, y, w, h, r, c2, c1);
            }
         }
      }
   }

   public static void circle(DrawContext c, int cx, int cy, int rad, int color) {
      rrect(c, cx - rad, cy - rad, rad * 2, rad * 2, rad, color);
   }

   public static void glow(DrawContext c, int x, int y, int w, int h, int r, int rgb, float strength) {
      for (int k = 5; k >= 1; k--) {
         rrect(c, x - k, y - k, w + 2 * k, h + 2 * k, r + k, argb(rgb, 0.035F * strength * (6 - k) / 2.0F));
      }
   }

   public static void text(DrawContext c, String s, int x, int y, int color, boolean shadow) {
      color = ga(color);
      if ((color >>> 24 & 0xFF) >= 5) {
         c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, shadow);
      }
   }

   public static void textC(DrawContext c, String s, int cx, int y, int color, boolean shadow) {
      text(c, s, cx - tw(s) / 2, y, color, shadow);
   }

   public static void textR(DrawContext c, String s, int rx, int y, int color, boolean shadow) {
      text(c, s, rx - tw(s), y, color, shadow);
   }

   public static int tw(String s) {
      return MinecraftClient.getInstance().textRenderer.getWidth(s);
   }

   public static boolean in(int mx, int my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   public static float ease(float t) {
      t = MathHelper.clamp(t, 0.0F, 1.0F);
      return 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
   }

   public static float easeBack(float t) {
      t = MathHelper.clamp(t, 0.0F, 1.0F) - 1.0F;
      float c1 = 1.70158F;
      float c3 = c1 + 1.0F;
      return 1.0F + c3 * t * t * t + c1 * t * t;
   }

   public static int waveWidth(String s, int spacing) {
      int w = 0;

      for (int i = 0; i < s.length(); i++) {
         w += tw(String.valueOf(s.charAt(i))) + spacing;
      }

      return Math.max(0, w - spacing);
   }

   public static int waveText(DrawContext c, String s, int x, int y, int spacing, int c1, int c2, float a) {
      float t = (float)System.currentTimeMillis() / 650.0F;
      int cx = x;

      for (int i = 0; i < s.length(); i++) {
         String ch = String.valueOf(s.charAt(i));
         float k = 0.5F + 0.5F * (float)Math.sin(t - i * 0.6F);
         int rgb = lerp(0xFF000000 | c1 & 16777215, 0xFF000000 | c2 & 16777215, k) & 16777215;
         int halo = argb(rgb, 0.14F * a);
         text(c, ch, cx - 1, y, halo, false);
         text(c, ch, cx + 1, y, halo, false);
         text(c, ch, cx, y - 1, halo, false);
         text(c, ch, cx, y + 1, halo, false);
         text(c, ch, cx, y, argb(rgb, a), true);
         cx += tw(ch) + spacing;
      }

      return cx - x - spacing;
   }

   public static void line(DrawContext c, int x0, int y0, int x1, int y1, int th, int color) {
      color = ga(color);
      if ((color >>> 24 & 0xFF) >= 5) {
         MinecraftClient mc = MinecraftClient.getInstance();
         int sw = mc.getWindow().getScaledWidth();
         int sh = mc.getWindow().getScaledHeight();
         if ((x0 >= 0 || x1 >= 0) && (x0 <= sw || x1 <= sw) && (y0 >= 0 || y1 >= 0) && (y0 <= sh || y1 <= sh)) {
            int dx = x1 - x0;
            int dy = y1 - y0;
            int n = Math.min(1500, Math.max(Math.abs(dx), Math.abs(dy)));
            int h = th / 2;
            int step = Math.max(1, th / 2);
            if (n == 0) {
               c.fill(x0 - h, y0 - h, x0 - h + th, y0 - h + th, color);
            } else {
               for (int i = 0; i <= n; i += step) {
                  int x = x0 + dx * i / n;
                  int y = y0 + dy * i / n;
                  c.fill(x - h, y - h, x - h + th, y - h + th, color);
               }
            }
         }
      }
   }
}

package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

public final class Zoom {
   private static boolean active;
   private static boolean prevSmooth;
   private static float level = 4.0F;
   private static float cur = 1.0F;
   private static long lastNs;

   private Zoom() {
   }

   public static boolean active() {
      return active;
   }

   public static float factor() {
      return Math.max(1.0F, cur);
   }

   public static void tick(MinecraftClient mc, KeyBinding key) {
      ModuleSettings s = Modules.ZOOM == null ? null : Modules.ZOOM.cfg();
      boolean want = s != null && s.enabled && mc.player != null && mc.currentScreen == null && key.isPressed();
      if (want && !active) {
         level = MathHelper.clamp(s.val <= 0.01F ? 4.0F : s.val, 1.5F, 12.0F);
         prevSmooth = mc.options.smoothCameraEnabled;
      }

      if (want && s.option) {
         mc.options.smoothCameraEnabled = true;
      }

      if (!want && active && s != null && s.option) {
         mc.options.smoothCameraEnabled = prevSmooth;
      }

      active = want;
   }

   public static boolean scroll(double v) {
      ModuleSettings s = Modules.ZOOM == null ? null : Modules.ZOOM.cfg();
      if (active && s != null && s.option2 && v != 0.0) {
         level = MathHelper.clamp(level * (v > 0.0 ? 1.15F : 0.86956525F), 1.5F, 12.0F);
         s.val = level;
         return true;
      } else {
         return false;
      }
   }

   public static float apply(float fov) {
      long now = System.nanoTime();
      float dt = lastNs == 0L ? 0.016F : Math.min(0.1F, (float)(now - lastNs) / 1.0E9F);
      lastNs = now;
      float target = active ? level : 1.0F;
      cur = cur + (target - cur) * Math.min(1.0F, dt * 12.0F);
      if (!active && cur < 1.01F) {
         cur = 1.0F;
         return fov;
      } else {
         double half = Math.toRadians(fov) / 2.0;
         return (float)Math.max(2.0, Math.toDegrees(2.0 * Math.atan(Math.tan(half) / cur)));
      }
   }
}

package com.dexvisual.util;

import com.dexvisual.config.DexConfig;
import com.dexvisual.module.HudModule;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class I18n {
   public static final String[] LANG_NAMES = new String[]{"O'zbekcha", "English", "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"};
   private static final Map<String, String> UZ = new HashMap<>();
   private static final Map<String, String> RU = new HashMap<>();
   private static final Map<String, String[]> MOD = new HashMap<>();
   private static final Map<String, String[]> MOD_RU = new HashMap<>();

   private I18n() {
   }

   public static String lang() {
      String l = DexConfig.get().language;
      return !"en".equals(l) && !"ru".equals(l) ? "uz" : l;
   }

   public static boolean uz() {
      return "uz".equals(lang());
   }

   public static boolean ru() {
      return "ru".equals(lang());
   }

   public static int langIndex() {
      String l = lang();
      return "uz".equals(l) ? 0 : ("en".equals(l) ? 1 : 2);
   }

   public static void setLang(int i) {
      DexConfig.get().language = i == 1 ? "en" : (i == 2 ? "ru" : "uz");
      DexConfig.markDirty();
   }

   public static void toggle() {
      setLang((langIndex() + 1) % LANG_NAMES.length);
   }

   public static String[] raw(String en) {
      return new String[]{UZ.get(en), RU.get(en)};
   }

   public static boolean hasModule(String id) {
      return MOD.containsKey(id) && MOD_RU.containsKey(id);
   }

   public static String langName() {
      return LANG_NAMES[langIndex()];
   }

   public static String tr(String en) {
      if (en == null) {
         return null;
      } else {
         String l = lang();
         if ("en".equals(l)) {
            return en;
         } else {
            String u = ("ru".equals(l) ? RU : UZ).get(en);
            return u != null ? u : en;
         }
      }
   }

   public static String fmt(String en, Object... args) {
      try {
         return String.format(Locale.ROOT, tr(en), args);
      } catch (Exception var3) {
         return tr(en);
      }
   }

   public static String t(String uzText, String en) {
      return uz() ? uzText : en;
   }

   public static String t(String uzText, String en, String ruText) {
      return uz() ? uzText : (ru() ? ruText : en);
   }

   private static String[] modTr(HudModule m) {
      Map<String, String[]> t = ru() ? MOD_RU : (uz() ? MOD : null);
      return t == null ? null : t.get(m.id);
   }

   public static String modName(HudModule m) {
      String[] p = modTr(m);
      return p != null ? p[0] : m.name;
   }

   public static String modDesc(HudModule m) {
      String[] p = modTr(m);
      return p != null ? p[1] : m.description;
   }

   private static void mod(String id, String name, String desc) {
      MOD.put(id, new String[]{name, desc});
   }

   static void modRu(String id, String name, String desc) {
      MOD_RU.put(id, new String[]{name, desc});
   }

   static void putUz(String... kv) {
      for (int i = 0; i + 1 < kv.length; i += 2) {
         UZ.put(kv[i], kv[i + 1]);
      }
   }

   static void putRu(String... kv) {
      for (int i = 0; i + 1 < kv.length; i += 2) {
         RU.put(kv[i], kv[i + 1]);
      }
   }

   private static void put(String... kv) {
      for (int i = 0; i + 1 < kv.length; i += 2) {
         UZ.put(kv[i], kv[i + 1]);
      }
   }

   static {
      mod("fps", "FPS hisoblagich", "Soniyasiga kadrlar soni");
      mod("cps", "CPS hisoblagich", "Soniyasiga bosishlar (chap | o'ng)");
      mod("ping", "Ping", "Server kechikishi");
      mod("coords", "Koordinatalar", "XYZ joylashuv va biom");
      mod("direction", "Yo'nalish", "Qarash yo'nalishi va burchagi");
      mod("clock", "Soat", "Haqiqiy vaqt soati");
      mod("memory", "FPS / RAM ma'lumot", "FPS va xotira sarfi");
      mod("session", "Sessiya statistikasi", "O'yin vaqti, o'ldirishlar, zarbalar, masofa");
      mod("combo", "Kombo hisoblagich", "Zarba yemasdan ketma-ket zarbalar");
      mod("kills", "Kill hisoblagich", "Kill soni va joriy seriya");
      mod("reach", "Reach ko'rsatkich", "Oxirgi hujum masofasi");
      mod("damage", "Zarar ko'rsatkich", "Nishon yonida uchuvchi zarar raqamlari");
      mod("crosshair", "Nishon muharriri", "Oddiy nishonni o'zingiznikiga almashtiring");
      mod("togglesprint", "Sprintni ushlab turish", "Sprint tugmasini bir marta bosing, yugurish davom etadi");
      mod("togglesneak", "Sneakni ushlab turish", "Sneak tugmasini bir marta bosing, cho'kkalash davom etadi");
      mod("chatanim", "Chat animatsiyasi", "Chat ochilganda silliq chiqadi");
      mod("tabanim", "Tab animatsiyasi", "Tab bosilganda o'yinchilar ro'yxati silliq chiqadi");
      mod("scoreboard", "Scoreboard sozlash", "Yon scoreboardni kattalashtiring, siljiting yoki yashiring");
      mod("tablist", "Tablist sozlash", "O'yinchilar ro'yxatini kattalashtiring va siljiting");
      mod("chat", "Chat sozlash", "Chatni kattalashtiring, siljiting va vaqt qo'shing");
      mod("perf", "Samaradorlik monitori", "FPS, 1% low, kadr vaqti, RAM, CPU va grafik");
      mod("keystrokes", "Tugmalar", "WASD, sichqoncha tugmalari (CPS bilan) va probel");
      mod("armor", "Zirh holati", "Kiyilgan zirh va uning chidamliligi");
      mod("potion", "Potion effektlari", "Faol effektlar va taymerlar");
      mod("itemcounter", "Buyum hisoblagich", "Qo'ldagi buyumning umumiy soni");
      mod("durability", "Chidamlilik", "Qo'ldagi buyumning chidamliligi");
      mod("target", "Nishon HUD", "Nishon kartasi: bosh, ism, HP va jonli salomatlik chizig'i");
      mod("waypoints", "Nuqtalar", "Nuqtalar ro'yxati va masofani ko'rsatuvchi belgilar (/dexwp add <ism> [x y z])");
      mod("notifications", "Bildirishnomalar", "Yoqish, kill va profillar uchun xabarlar");
      mod("watermark", "Logotip", "Ping va FPS bilan DEX VISUAL belgisi (yuqori chap)");
      mod("hands", "Qo'l shaderi", "Skiningiz saqlangan holda qo'l atrofida aylanuvchi chiroyli bulutli aura va neon jilo");
      mod("autosprint", "Avto sprint", "Oldinga bosganda o'zi yuguradi (sprint tugmasi shart emas)");
      mod(
         "optimize",
         "Optimizatsiya",
         "FPS oshirish: render masofasi 8 chunk, yer osti chunklar yashiriladi, animatsiyalar o'chadi (o'chirsangiz hammasi tiklanadi)"
      );
      mod("aspect", "Ekran nisbati", "O'yin ko'rinishini gorizontal cho'zish (masalan 4:3)");
      mod("fullbright", "To'liq yorug'lik", "Qorong'uda aniq ko'ring (night vision)");
      mod("customsky", "Maxsus osmon", "Silliq aylanuvchi bulutlar va chiroyli realistik osmon");
      mod("particles", "Zarrachalar", "Snaryadlar tushadigan joy va taymer (perl, o'q, potion, trident)");
      mod("blockoverlay", "Blok belgisi", "Qaragan blokingiz rangli to'ldirish va chiziq bilan ko'rinadi");
      mod("cooldowns", "Cooldownlar", "Buyum cooldownlari (perl, gapple, chorus...) taymer bilan");
      mod("inventory", "Inventar", "Inventaringiz HUDda ixcham to'r ko'rinishida");
      mod("artihelper", "Arti Helper", "Trapka yoki Plast ushlaganingizda uning joyi ramka bilan ko'rinadi, ishlatganingizda tugashigacha taymer chiqadi");
      mod("targetesp", "Nishon ESP", "Nishonni burchak qavslari yoki atrofida aylanuvchi yorqin iz (Orbit) bilan belgilaydi. O'ng tugma bilan qulflanadi.");
      mod("chinahat", "Xitoy shlyapa", "Boshingiz ustida yarqiroq konus shlyapa (3-shaxsda ko'rinadi)");
      mod("freelook", "Erkin qarash", "Tugmani ushlab turing: personaj burilmasdan atrofga qarang");
      mod("zoom", "Zoom", "Tugmani ushlab turib silliq yaqinlashing, g'ildirak bilan darajani o'zgartiring");
      mod("motionblur", "Harakat xiraligi", "120 Hz kabi silliq tasvir: tez burilganda yumshoq iz qoladi");
      mod("killeffect", "Kill effekti", "O'yinchini yo'q qilganingizda yorug'lik portlashi: bloom, to'lqin, chaqmoq yoki ruh");
      mod("jumpcircles", "Sakrash halqalari", "Sakragan joyingizda kengayuvchi yorqin halqa");
      put(
         "Modules",
         "Modullar",
         "Themes",
         "Mavzular",
         "Visual",
         "Vizual",
         "Chat",
         "Chat",
         "Edit HUD",
         "HUD tahrirlash",
         "Enabled",
         "Yoqilgan",
         "Disabled",
         "O'chiq",
         "Search modules",
         "Modul qidirish",
         "Home",
         "Bosh sahifa",
         "Visuals",
         "Vizual",
         "HUD",
         "HUD",
         "Misc",
         "Boshqa",
         "Cosmetics",
         "Kosmetika",
         "Configs",
         "Konfiglar",
         "Profile",
         "Profil",
         "Settings",
         "Sozlamalar",
         "Utilities",
         "Qo'shimcha",
         "Overview of your game and client",
         "O'yin va klient haqida umumiy ma'lumot",
         "Visual modules: effects, camera and world",
         "Vizual modullar: effektlar, kamera va dunyo",
         "On-screen info panels",
         "Ekrandagi ma'lumot panellari",
         "Utilities and performance tools",
         "Qo'shimcha va tezlik vositalari",
         "Make your experience unique. Customize your menu and game.",
         "O'yiningizni noyob qiling. Menyu va o'yinni sozlang.",
         "Save, load and share your settings",
         "Sozlamalarni saqlang, yuklang va ulashing",
         "Switch between your setting profiles",
         "Sozlama profillari orasida almashing",
         "Interface, HUD editor and keybinds",
         "Interfeys, HUD muharriri va tugmalar",
         "Quick Settings",
         "Tezkor sozlamalar",
         "Menu Key",
         "Menyu tugmasi",
         "Language",
         "Til",
         "Theme",
         "Mavzu",
         "Status",
         "Holat",
         "License active",
         "Litsenziya faol",
         "No license",
         "Litsenziya yo'q",
         "Stand Out",
         "Ajralib turing",
         "Not just a client - it's a style.",
         "Klient emas - bu uslub.",
         "Skins",
         "Skinlar",
         "Items",
         "Buyumlar",
         "Effects",
         "Effektlar",
         "UI",
         "Interfeys",
         "Menu Skin",
         "Menyu skini",
         "Choose your favorite style.",
         "Sevimli uslubingizni tanlang.",
         "Default",
         "Standart",
         "Neon",
         "Neon",
         "Dark Red",
         "To'q qizil",
         "Galaxy",
         "Galaktika",
         "Transparent",
         "Shaffof",
         "Custom",
         "Maxsus",
         "Your style",
         "Sizning uslubingiz",
         "Preview",
         "Ko'rinish",
         "How your menu will look in-game.",
         "Menyu o'yinda shunday ko'rinadi.",
         "Extra Settings",
         "Qo'shimcha sozlamalar",
         "Additional customization options.",
         "Qo'shimcha sozlash imkoniyatlari.",
         "Enable smooth animations.",
         "Silliq animatsiyalarni yoqish.",
         "Play sounds on menu events.",
         "Menyu hodisalarida ovoz chalish.",
         "Make your menu colors dynamic.",
         "Menyu ranglarini jonli qilish.",
         "Cosmetics Info",
         "Kosmetika haqida",
         "Animated Effects",
         "Animatsiyali effektlar",
         "Sound Effects",
         "Ovoz effektlari",
         "Rainbow Mode",
         "Kamalak rejimi",
         "Custom color",
         "Maxsus rang",
         "Show cosmetics",
         "Kosmetikani ko'rsatish",
         "Share mine (DV users)",
         "Meniki boshqalarga ko'rinsin (DV)",
         "See others' cosmetics",
         "Boshqalar kosmetikasini ko'rish",
         "Wing size",
         "Qanot o'lchami",
         "Pet size",
         "Hayvon o'lchami",
         "Particle amount",
         "Zarrachalar miqdori",
         "Remove all",
         "Hammasini olib tashlash",
         "Tap to equip, tap again to remove. Wings / hats / backpacks show in third person (F5).",
         "Kiyish uchun bosing, olish uchun yana bosing. Qanot / shlyapa / ryukzak 3-shaxsda (F5) ko'rinadi.",
         "Theme color",
         "Mavzu rangi",
         "Panel opacity",
         "Panel shaffofligi",
         "Menu animation",
         "Menyu animatsiyasi",
         "Apply theme to all modules",
         "Mavzuni barcha modullarga qo'llash",
         "Search...",
         "Qidirish...",
         "No modules found",
         "Modul topilmadi",
         "Click a card to toggle  |  \"...\" or right-click for settings",
         "Yoqish uchun kartani bosing  |  sozlama uchun o'ng tugma",
         "< Back",
         "< Orqaga",
         "Crosshair",
         "Nishon muharriri",
         "Open Crosshair Editor",
         "Nishon muharririni ochish",
         "Press key...",
         "Tugmani bosing...",
         "Enabled",
         "Yoqilgan",
         "Scale",
         "Kattalik",
         "Opacity",
         "Shaffoflik",
         "Background",
         "Fon",
         "Background color",
         "Fon rangi",
         "Background opacity",
         "Fon shaffofligi",
         "Border",
         "Chegara",
         "Border color",
         "Chegara rangi",
         "Border width",
         "Chegara qalinligi",
         "Corner radius",
         "Burchak yumaloqligi",
         "Text color",
         "Matn rangi",
         "Text shadow",
         "Matn soyasi",
         "Animation",
         "Animatsiya",
         "Position X",
         "X o'rni",
         "Position Y",
         "Y o'rni",
         "Animation speed",
         "Animatsiya tezligi",
         "Light strength",
         "Yorug'lik kuchi",
         "Size",
         "O'lcham",
         "Hat color",
         "Shlyapa rangi",
         "Ring color",
         "Halqa rangi",
         "Zoom level",
         "Zoom darajasi",
         "Strength",
         "Kuch",
         "Turn boost",
         "Burilish kuchi",
         "Style",
         "Uslub",
         "Screen flash",
         "Ekran chaqnashi",
         "Effect color",
         "Effekt rangi",
         "Test effect",
         "Effektni sinash",
         "Line thickness",
         "Chiziq qalinligi",
         "Glow strength",
         "Nur kuchi",
         "Glow intensity",
         "Nur yorqinligi",
         "Glow radius",
         "Nur radiusi",
         "Outline thickness",
         "Kontur qalinligi",
         "Glow color",
         "Nur rangi",
         "Pulse animation",
         "Pulsatsiya animatsiyasi",
         "Health-based colors",
         "Salomatlikka qarab rang",
         "Show target name",
         "Nishon ismini ko'rsatish",
         "Show target health",
         "Nishon salomatligini ko'rsatish",
         "Bracket arm length",
         "Qavs uzunligi",
         "Brackets color",
         "Qavs rangi",
         "Fill opacity",
         "To'ldirish shaffofligi",
         "Color",
         "Rang",
         "Item",
         "Buyum",
         "Aspect ratio",
         "Ekran nisbati",
         "Time of day",
         "Kun vaqti",
         "Loop speed",
         "Aylanish tezligi",
         "Rotation speed",
         "Aylanish tezligi",
         "Brightness",
         "Yorqinlik",
         "Keep vanilla sun & moon",
         "Oddiy quyosh va oyni saqlash",
         "Realistic custom skybox with smooth rotating clouds.",
         "Silliq aylanuvchi bulutli realistik chiroyli osmon.",
         "Offset X",
         "X siljish",
         "Offset Y",
         "Y siljish",
         "Toggle key",
         "Yoqish tugmasi",
         "Reset this module",
         "Modulni asliga qaytarish",
         "Number color",
         "Raqam rangi",
         "Hide scoreboard",
         "Scoreboardni yashirish",
         "Chat timestamps",
         "Chat vaqti",
         "Glow, rays and sparkles work with any held item. Color follows the theme color.",
         "Nur va uchqunlar har qanday buyum bilan ishlaydi. Rang mavzu rangiga mos.",
         "Cone hat above your head. Switch to third person (F5) to see it.",
         "Boshingiz ustidagi konus shlyapa. Ko'rish uchun 3-shaxsga (F5) o'ting.",
         "Ring appears where you jump (only your own jumps).",
         "Halqa sakragan joyingizda paydo bo'ladi (faqat o'z sakrashingiz).",
         "Hold the Zoom key (default C, change it in Controls > DEX VISUAL).",
         "Zoom tugmasini ushlab turing (odatda C, Controls > DEX VISUAL da o'zgartiriladi).",
         "Hold the Freelook key (default Left Alt) and move the mouse: the camera turns, your character does not.",
         "Freelook tugmasini (odatda Left Alt) ushlab sichqonchani suring: kamera buriladi, personaj emas.",
         "Soft trail that grows when you turn the camera fast. The HUD stays sharp. Off while Optimization is on.",
         "Kamerani tez burganda yumshoq iz paydo bo'ladi. HUD aniq qoladi. Optimizatsiya yoqiq bo'lsa ishlamaydi.",
         "Plays where you eliminate a player. Test closes the menu and shows it in front of you.",
         "O'yinchini yo'q qilgan joyda ishlaydi. Sinash menyuni yopadi va effektni oldingizda ko'rsatadi.",
         "Right-click a player to lock the ESP on them.",
         "ESP ni qulflash uchun o'yinchini o'ng tugma bilan bosing.",
         "Set the key in Options > Controls > DEX VISUAL (Item Swap).",
         "Tugmani Options > Controls > DEX VISUAL (Item Swap) da belgilang.",
         "Tracks pearls, arrows, potions, tridents (yours and others').",
         "Perl, o'q, potion va tridentlarni kuzatadi (sizniki va boshqalarniki).",
         "1.33 = 4:3 stretched, 1.78 = 16:9 (normal).",
         "1.33 = 4:3 cho'zilgan, 1.78 = 16:9 (oddiy).",
         "Overview",
         "Umumiy ko'rinish",
         "Player & Server",
         "O'yinchi va server",
         "System",
         "Tizim",
         "Quick toggles",
         "Tez yoqish",
         "World",
         "Dunyo",
         "Save / import",
         "Saqlash / import",
         "Config name",
         "Konfig nomi",
         "Save current settings",
         "Joriy sozlamalarni saqlash",
         "Import (clipboard)",
         "Import (buferdan)",
         "Saved configs",
         "Saqlangan konfiglar",
         "No saved configs yet. Type a name and press Save.",
         "Hali konfig yo'q. Nom yozing va Saqlash ni bosing.",
         "Load",
         "Yuklash",
         "Overwrite",
         "Ustiga yozish",
         "Export",
         "Eksport",
         "Delete",
         "O'chirish",
         "Files: .minecraft/config/dexvisual-configs/",
         "Fayllar: .minecraft/config/dexvisual-configs/",
         "Create / rename",
         "Yaratish / nomini o'zgartirish",
         "Profile name",
         "Profil nomi",
         "Create profile",
         "Profil yaratish",
         "Type a name above, then use Create or Rename on a profile.",
         "Yuqoriga nom yozing, so'ng Yaratish yoki Nomini o'zgartirish ni bosing.",
         "Your profiles",
         "Profillaringiz",
         "Rename",
         "Nomini o'zgartirish",
         "Copy",
         "Nusxa",
         "Crosshair editor",
         "Nishon muharriri",
         "Presets",
         "Tayyor sozlamalar",
         "Classic",
         "Klassik",
         "Dot",
         "Nuqta",
         "Tight",
         "Tor",
         "Circle",
         "Doira",
         "Position",
         "Joylashuv",
         "Lock position",
         "O'rinni qulflash",
         "Center crosshair",
         "Nishonni markazlash",
         "Drag it in the HUD Editor; right-click there to lock.",
         "HUD muharririda suring; qulflash uchun o'ng tugma.",
         "Crosshair style",
         "Nishon uslubi",
         "Thickness",
         "Qalinlik",
         "Gap",
         "Oraliq",
         "Outline",
         "Kontur",
         "Center dot",
         "Markaz nuqta",
         "Soft glow",
         "Yumshoq nur",
         "Dynamic (expands while moving)",
         "Dinamik (harakatda kengayadi)",
         "Crosshair color",
         "Nishon rangi",
         "Uses the global theme color while \"Apply theme\" is on.",
         "\"Mavzuni qo'llash\" yoqiq bo'lsa umumiy mavzu rangi ishlatiladi.",
         "Custom presets",
         "Shaxsiy presetlar",
         "Save current crosshair as preset",
         "Nishonni preset sifatida saqlash",
         "Enable custom crosshair (currently off)",
         "Maxsus nishonni yoqish (hozir o'chiq)",
         "General",
         "Umumiy",
         "HUD visible",
         "HUD ko'rinadi",
         "Notification time (s)",
         "Xabar vaqti (s)",
         "HUD Editor",
         "HUD muharriri",
         "Snap to edges & elements",
         "Chekka va elementlarga yopishish",
         "Show alignment guides",
         "Yo'naltiruvchi chiziqlar",
         "Snap distance",
         "Yopishish masofasi",
         "Interface",
         "Interfeys",
         "Reset custom colors (follow theme)",
         "Maxsus ranglarni tiklash (mavzuga mos)",
         "Keybinds (module toggle keys)",
         "Tugmalar (modul tugmalari)",
         "Menu key is in Options > Controls > DEX VISUAL.",
         "Menyu tugmasi Options > Controls > DEX VISUAL da.",
         "Reset",
         "Tiklash",
         "Reset HUD layout & styles",
         "HUD joylashuvi va uslublarini tiklash",
         "Reset ALL settings",
         "BARCHA sozlamalarni tiklash",
         "Animations",
         "Animatsiyalar",
         "HUD animations",
         "HUD animatsiyalari",
         "Chat animation",
         "Chat animatsiyasi",
         "Tab animation",
         "Tab animatsiyasi",
         "Each module has its own animation: NONE / FADE / SLIDE / POP.",
         "Har bir modulning o'z animatsiyasi bor: NONE / FADE / SLIDE / POP.",
         "Info",
         "Ma'lumot",
         "Controls",
         "Boshqaruv",
         "HUD Editor tips",
         "HUD muharriri maslahatlari",
         "New waypoint",
         "Yangi nuqta",
         "Waypoint name",
         "Nuqta nomi",
         "Add waypoint at my position",
         "Nuqtani joylashuvimga qo'shish",
         "Add by coordinates",
         "Koordinata bo'yicha qo'shish",
         "Add waypoint at X Y Z",
         "X Y Z nuqtasini qo'shish",
         "Show waypoints on HUD",
         "Nuqtalarni HUDda ko'rsatish",
         "Saved waypoints",
         "Saqlangan nuqtalar",
         "Twilight sky (stars, moon, glowing sunset)",
         "Kechki osmon (yulduz, oy, yonayotgan quyosh botishi)",
         "Shooting stars",
         "Uchar yulduzlar"
      );
      I18nExtra.fill();
   }
}

package com.dexvisual.util;

import com.dexvisual.gui.Theme;
import com.dexvisual.gui.Widgets;
import net.minecraft.item.ItemStack;
import net.minecraft.client.gui.DrawContext;

public final class CardUi {
   public static final int PAD = 6;
   public static final int HEADER = 20;
   public static final int ROW = 19;

   private CardUi() {
   }

   public static int rows(int n) {
      return 20 + n * 19 + 3;
   }

   public static int single() {
      return 27;
   }

   public static void panel(DrawContext c, int w, int h, float al) {
      int a1 = Theme.rgb(Theme.a1());
      Gfx.glow(c, 0, 0, w, h, 8, a1, 0.35F * al);
      Gfx.rrect(c, 0, 0, w, h, 8, Gfx.argb(790039, 0.93F * al), Gfx.argb(986397, 0.93F * al));
      Gfx.rrect(c, 8, 1, Math.max(0, w - 16), 1, 0, Gfx.argb(16777215, 0.07F * al));
      Gfx.rborder(c, 0, 0, w, h, 8, 1, Gfx.argb(16777215, 0.08F * al));
   }

   public static void icon(DrawContext c, ItemStack s, int x, int y, float scale) {
      if (s != null && !s.isEmpty()) {
         c.getMatrices().push();
         c.getMatrices().translate(x, y, 0.0F);
         c.getMatrices().scale(scale, scale, 1.0F);
         c.drawItem(s, 0, 0);
         c.getMatrices().pop();
      }
   }

   public static void header(DrawContext c, int w, ItemStack icon, String title, String badge, float al) {
      icon(c, icon, 6, 4, 0.75F);
      Gfx.text(c, title, 23, 6, Gfx.argb(15264757, al), false);
      if (badge != null) {
         int bw = Math.max(14, Gfx.tw(badge) + 8);
         Gfx.rrect(c, w - 6 - bw, 4, bw, 12, 4, Gfx.argb(16777215, 0.1F * al));
         Gfx.textC(c, badge, w - 6 - bw / 2, 6, Gfx.argb(16777215, al), false);
      }
   }

   public static void row(DrawContext c, int w, int y, ItemStack icon, String name, String right, int rightRgb, float prog, int barRgb, float al, boolean shadow) {
      icon(c, icon, 6, y, 0.75F);
      int rw = right == null ? 0 : Gfx.tw(right) + 6;
      Gfx.text(c, Widgets.fit(name, w - 12 - 17 - rw), 23, y + 1, Gfx.argb(16777215, al), shadow);
      if (right != null) {
         Gfx.textR(c, right, w - 6, y + 1, Gfx.argb(rightRgb, 0.92F * al), false);
      }

      if (prog >= 0.0F) {
         int bx = 23;
         int bw = w - 12 - 17;
         Gfx.rrect(c, bx, y + 12, bw, 2, 1, Gfx.argb(16777215, 0.1F * al));
         Gfx.rrect(c, bx, y + 12, Math.max(2, Math.round(bw * Math.min(1.0F, prog))), 2, 1, Gfx.argb(barRgb, al));
      }
   }
}

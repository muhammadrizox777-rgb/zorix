package com.dexvisual.util;

import java.util.Locale;

public final class ColorUtil {
   private ColorUtil() {
   }

   public static int parseHex(String s) {
      if (s == null) {
         return -1;
      } else {
         s = s.trim();
         if (s.startsWith("#")) {
            s = s.substring(1);
         }

         if (s.length() == 3) {
            s = "" + s.charAt(0) + s.charAt(0) + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2);
         }

         if (s.length() != 6) {
            return -1;
         } else {
            int v = 0;

            for (int i = 0; i < 6; i++) {
               int d = Character.digit(s.charAt(i), 16);
               if (d < 0) {
                  return -1;
               }

               v = v << 4 | d;
            }

            return v;
         }
      }
   }

   public static String toHex(int rgb) {
      return String.format(Locale.ROOT, "#%06X", rgb & 16777215);
   }

   public static int normalizeOptional(int c) {
      return c < 0 ? -1 : c & 16777215;
   }

   public static int mix(int a, int b, float t) {
      t = clamp01(t);
      int r = Math.round((a >> 16 & 0xFF) * (1.0F - t) + (b >> 16 & 0xFF) * t);
      int g = Math.round((a >> 8 & 0xFF) * (1.0F - t) + (b >> 8 & 0xFF) * t);
      int bl = Math.round((a & 0xFF) * (1.0F - t) + (b & 0xFF) * t);
      return r << 16 | g << 8 | bl;
   }

   public static float clamp01(float v) {
      return Float.isNaN(v) ? 0.0F : (v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v));
   }

   public static float clamp(float v, float lo, float hi, float fallback) {
      if (!Float.isNaN(v) && !Float.isInfinite(v)) {
         return v < lo ? lo : (v > hi ? hi : v);
      } else {
         return fallback;
      }
   }

   public static double luminance(int rgb) {
      double r = lin((rgb >> 16 & 0xFF) / 255.0);
      double g = lin((rgb >> 8 & 0xFF) / 255.0);
      double b = lin((rgb & 0xFF) / 255.0);
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
   }

   private static double lin(double c) {
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
   }

   public static double contrast(int a, int b) {
      double la = luminance(a);
      double lb = luminance(b);
      double hi = Math.max(la, lb);
      double lo = Math.min(la, lb);
      return (hi + 0.05) / (lo + 0.05);
   }

   public static int readable(int fg, int bg, double minRatio) {
      if (contrast(fg, bg) >= minRatio) {
         return fg & 16777215;
      } else {
         return contrast(16777215, bg) >= contrast(0, bg) ? 16777215 : 0;
      }
   }

   public static int hsv(float h, float s, float v) {
      h -= (float)Math.floor(h);
      s = clamp01(s);
      v = clamp01(v);
      int i = (int)Math.floor(h * 6.0F);
      float f = h * 6.0F - i;
      float p = v * (1.0F - s);
      float q = v * (1.0F - f * s);
      float t = v * (1.0F - (1.0F - f) * s);
      float r;
      float g;
      float b;
      switch (Math.floorMod(i, 6)) {
         case 0:
            r = v;
            g = t;
            b = p;
            break;
         case 1:
            r = q;
            g = v;
            b = p;
            break;
         case 2:
            r = p;
            g = v;
            b = t;
            break;
         case 3:
            r = p;
            g = q;
            b = v;
            break;
         case 4:
            r = t;
            g = p;
            b = v;
            break;
         default:
            r = v;
            g = p;
            b = q;
      }

      return Math.round(r * 255.0F) << 16 | Math.round(g * 255.0F) << 8 | Math.round(b * 255.0F);
   }

   public static float[] toHsv(int rgb) {
      float r = (rgb >> 16 & 0xFF) / 255.0F;
      float g = (rgb >> 8 & 0xFF) / 255.0F;
      float b = (rgb & 0xFF) / 255.0F;
      float max = Math.max(r, Math.max(g, b));
      float min = Math.min(r, Math.min(g, b));
      float d = max - min;
      float h;
      if (d == 0.0F) {
         h = 0.0F;
      } else if (max == r) {
         h = (g - b) / d % 6.0F;
      } else if (max == g) {
         h = (b - r) / d + 2.0F;
      } else {
         h = (r - g) / d + 4.0F;
      }

      h = (h / 6.0F + 1.0F) % 1.0F;
      return new float[]{h, max == 0.0F ? 0.0F : d / max, max};
   }
}

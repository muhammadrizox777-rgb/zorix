package com.dexvisual.util;

import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class ModuleSearch {
   public static final int SORT_NAME = 0;
   public static final int SORT_CATEGORY = 1;
   public static final int SORT_ENABLED = 2;
   public static final int SORT_FAVORITES = 3;
   public static final int SORT_RECENT = 4;
   public static final String ALL = "All";
   public static final String FAV = "Favorites";
   public static final String RECENT = "Recent";
   public static final Map<String, String> ALIASES = Map.ofEntries(
      Map.entry("fps", "frames framerate kadr \u043a\u0430\u0434\u0440\u044b"),
      Map.entry("cps", "clicks click speed bosish \u043a\u043b\u0438\u043a\u0438"),
      Map.entry("ping", "latency lag kechikish \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043f\u0438\u043d\u0433"),
      Map.entry("coords", "coordinates xyz position biome koordinata \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b"),
      Map.entry("crosshair", "reticle aim nishon \u043f\u0440\u0438\u0446\u0435\u043b"),
      Map.entry("targetesp", "esp highlight outline brackets nishon \u043f\u043e\u0434\u0441\u0432\u0435\u0442\u043a\u0430"),
      Map.entry("target", "enemy hp health card \u0446\u0435\u043b\u044c"),
      Map.entry("keystrokes", "wasd keys input tugma \u043a\u043b\u0430\u0432\u0438\u0448\u0438"),
      Map.entry("armor", "durability zirh \u0431\u0440\u043e\u043d\u044f"),
      Map.entry("potion", "effects status \u044d\u0444\u0444\u0435\u043a\u0442\u044b \u0437\u0435\u043b\u044c\u044f"),
      Map.entry("togglesprint", "sprint run yugurish \u0431\u0435\u0433"),
      Map.entry("autosprint", "sprint run yugurish \u0431\u0435\u0433"),
      Map.entry("fullbright", "gamma night vision dark yorug \u043d\u043e\u0447\u043d\u043e\u0435 \u0437\u0440\u0435\u043d\u0438\u0435"),
      Map.entry("zoom", "optifine scope yaqinlash \u043f\u0440\u0438\u0431\u043b\u0438\u0436\u0435\u043d\u0438\u0435"),
      Map.entry("freelook", "camera look third person kamera \u043e\u0431\u0437\u043e\u0440"),
      Map.entry("motionblur", "blur smooth xira \u0440\u0430\u0437\u043c\u044b\u0442\u0438\u0435"),
      Map.entry("optimize", "performance boost lag fps tezlik \u043e\u043f\u0442\u0438\u043c\u0438\u0437\u0430\u0446\u0438\u044f"),
      Map.entry("chat", "message timestamp xabar \u0447\u0430\u0442"),
      Map.entry("killeffect", "kill burst lightning o'ldirish \u0443\u0431\u0438\u0439\u0441\u0442\u0432\u043e"),
      Map.entry("waypoints", "marker home coordinates nuqta \u043c\u0435\u0442\u043a\u0438"),
      Map.entry("customsky", "sky osmon bulut cloud clouds customsky \u043d\u0435\u0431\u043e \u043e\u0431\u043b\u0430\u043a\u0430"),
      Map.entry("hands", "shader glow viewmodel qo'l \u0440\u0443\u043a\u0438")
   );

   private ModuleSearch() {
   }

   public static String norm(String s) {
      if (s == null) {
         return "";
      } else {
         String n = Normalizer.normalize(s, Form.NFD).replaceAll("\\p{M}+", "");
         n = n.replace('\u02bb', '\'').replace('\u2019', '\'').replace('`', '\'').replace('\u02bc', '\'');
         return n.toLowerCase(Locale.ROOT).trim();
      }
   }

   public static boolean matches(ModuleSearch.Item m, String query) {
      String q = norm(query);
      if (q.isEmpty()) {
         return true;
      } else {
         String hay = norm(
            m.name() + " " + m.locName() + " " + m.desc() + " " + m.locDesc() + " " + m.id() + " " + m.category() + " " + ALIASES.getOrDefault(m.id(), "")
         );

         for (String w : q.split("\\s+")) {
            if (!hay.contains(w)) {
               return false;
            }
         }

         return true;
      }
   }

   private static int rank(ModuleSearch.Item m, String query) {
      String q = norm(query);
      if (q.isEmpty()) {
         return 0;
      } else {
         String nm = norm(m.name()) + " " + norm(m.locName());
         if (nm.startsWith(q) || nm.contains(" " + q)) {
            return 0;
         } else {
            return nm.contains(q) ? 1 : 2;
         }
      }
   }

   public static List<ModuleSearch.Item> apply(List<ModuleSearch.Item> all, String query, String filter, int sort, Set<String> favorites, List<String> recent) {
      boolean searching = !norm(query).isEmpty();
      List<ModuleSearch.Item> out = new ArrayList<>();

      for (ModuleSearch.Item m : all) {
         if (matches(m, query)
            && (
               searching
                  || (!"Favorites".equals(filter) || favorites.contains(m.id()))
                     && (!"Recent".equals(filter) || recent.contains(m.id()))
                     && ("All".equals(filter) || "Favorites".equals(filter) || "Recent".equals(filter) || m.category().equals(filter))
            )) {
            out.add(m);
         }
      }

      Comparator<ModuleSearch.Item> byName = Comparator.comparing(i -> norm(i.locName()));

      Comparator<ModuleSearch.Item> cmp = switch (sort) {
         case 1 -> Comparator.comparing(ModuleSearch.Item::category).thenComparing(byName);
         case 2 -> Comparator.<ModuleSearch.Item, Boolean>comparing(i -> !i.enabled()).thenComparing(byName);
         case 3 -> Comparator.<ModuleSearch.Item, Boolean>comparing(i -> !favorites.contains(i.id())).thenComparing(byName);
         case 4 -> Comparator.<ModuleSearch.Item>comparingInt(i -> {
            int k = recent.indexOf(i.id());
            return k < 0 ? Integer.MAX_VALUE : k;
         }).thenComparing(byName);
         default -> byName;
      };
      if (searching) {
         cmp = Comparator.<ModuleSearch.Item>comparingInt(i -> rank(i, query)).thenComparing(cmp);
      }

      out.sort(cmp);
      return out;
   }

   public record Item(String id, String name, String locName, String desc, String locDesc, String category, boolean enabled) {
   }
}

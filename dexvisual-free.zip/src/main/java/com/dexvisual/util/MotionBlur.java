package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import org.lwjgl.opengl.GL11;

public final class MotionBlur {
   private static final Identifier ID = Identifier.of("dexvisual", "motion_blur");
   private static NativeImageBackedTexture tex;
   private static int tw;
   private static int th;
   private static boolean has;
   private static float lastYaw;
   private static float lastPitch;
   private static float rot;
   private static long lastNs;
   private static Object lastWorld;

   private MotionBlur() {
   }

   public static void frame(DrawContext ctx) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (Modules.MOTIONBLUR != null && Modules.MOTIONBLUR.cfg().enabled && mc.player != null && mc.world != null) {
         ModuleSettings s = Modules.MOTIONBLUR.cfg();
         Framebuffer fb = mc.getFramebuffer();
         int w = fb.viewportWidth > 0 ? fb.viewportWidth : fb.textureWidth;
         int h = fb.viewportHeight > 0 ? fb.viewportHeight : fb.textureHeight;
         if (w > 0 && h > 0) {
            if (tex == null || w != tw || h != th) {
               if (tex != null) {
                  tex.close();
               }

               tex = new NativeImageBackedTexture(new NativeImage(w, h, false));
               tex.upload();
               tex.setFilter(true, false);
               mc.getTextureManager().registerTexture(ID, tex);
               tw = w;
               th = h;
               has = false;
            }

            long now = System.nanoTime();
            float dt = lastNs == 0L ? 0.016F : (float)(now - lastNs) / 1.0E9F;
            lastNs = now;
            Camera cam = mc.gameRenderer.getCamera();
            float yaw = cam.getYaw();
            float pitch = cam.getPitch();
            float inst = (float)Math.hypot(MathHelper.wrapDegrees(yaw - lastYaw), pitch - lastPitch);
            lastYaw = yaw;
            lastPitch = pitch;
            rot = rot + (inst - rot) * 0.15F;
            boolean newWorld = lastWorld != mc.world;
            lastWorld = mc.world;
            if (has && !newWorld) {
               float strength = MathHelper.clamp(s.val <= 0.01F ? 0.7F : s.val, 0.2F, 0.88F);
               float boost = Math.max(0.2F, s.scale);
               float turnBoost = MathHelper.clamp(rot * boost * 0.03F, 0.0F, 0.14F);
               float targetAlpha = Math.min(0.85F, strength + turnBoost);
               float p = (float)Math.pow(targetAlpha, MathHelper.clamp(dt * 60.0F, 0.5F, 1.8F));
               if (p > 0.02F) {
                  int a = MathHelper.clamp(Math.round(p * 255.0F), 1, 255);
                  ctx.drawTexture(RenderLayer::getGuiTextured, ID, 0, 0, 0.0F, h, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), w, -h, w, h, a << 24 | 16777215);
                  ctx.draw();
               }
            }

            int prev = GL11.glGetInteger(32873);
            GL11.glBindTexture(3553, tex.getGlId());
            GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, w, h);
            GL11.glBindTexture(3553, prev);
            has = true;
         }
      } else {
         has = false;
      }
   }
}

package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;

public final class Freelook {
   public static boolean active;
   public static float yaw;
   public static float pitch;
   private static boolean toggled;
   private static Perspective before;

   private Freelook() {
   }

   public static void tick(MinecraftClient mc, KeyBinding key) {
      ModuleSettings s = Modules.FREELOOK == null ? null : Modules.FREELOOK.cfg();
      boolean want;
      if (s != null && s.option) {
         while (key.wasPressed()) {
            toggled = !toggled;
         }

         want = toggled;
      } else {
         while (key.wasPressed()) {
         }

         want = key.isPressed();
         toggled = false;
      }

      want = want && s != null && s.enabled && mc.player != null && mc.currentScreen == null;
      if (want && !active) {
         before = mc.options.getPerspective();
         yaw = mc.player.getYaw();
         pitch = mc.player.getPitch();
         mc.options.setPerspective(Perspective.field_26665);
         active = true;
      } else if (!want && active) {
         active = false;
         toggled = false;
         if (before != null) {
            mc.options.setPerspective(before);
         }
      }
   }

   public static void turn(double dx, double dy) {
      yaw += (float)(dx * 0.15);
      pitch = Math.max(-90.0F, Math.min(90.0F, pitch + (float)(dy * 0.15)));
   }
}

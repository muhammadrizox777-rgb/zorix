package com.dexvisual.util;

import com.dexvisual.config.DexConfig;
import com.dexvisual.module.Modules;

public final class UiAnim {
   private static final float MAX_DT = 0.033333335F;
   private static float tabP;
   private static float chatP;
   private static long tabLastNs;
   private static long chatLastNs;
   private static boolean chatWas;

   private UiAnim() {
   }

   private static float dur() {
      return 0.3F / Math.max(0.3F, DexConfig.get().animSpeed);
   }

   private static float easeOut(float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      float u = 1.0F - t;
      return 1.0F - u * u * u * u;
   }

   public static float tab() {
      if (Modules.optimizing()) {
         return 1.0F;
      } else {
         long now = System.nanoTime();
         float dt;
         if (now - tabLastNs > 250000000L) {
            tabP = 0.0F;
            dt = 0.016666668F;
         } else {
            dt = Math.min((float)(now - tabLastNs) / 1.0E9F, 0.033333335F);
         }

         tabLastNs = now;
         tabP = Math.min(1.0F, tabP + dt / dur());
         return easeOut(tabP);
      }
   }

   public static float chat(boolean focused) {
      if (Modules.optimizing()) {
         return 1.0F;
      } else {
         long now = System.nanoTime();
         if (!focused) {
            chatWas = false;
            chatP = 1.0F;
            chatLastNs = now;
            return 1.0F;
         } else {
            float dt;
            if (!chatWas) {
               chatP = 0.0F;
               dt = 0.016666668F;
               chatWas = true;
            } else {
               dt = Math.min((float)(now - chatLastNs) / 1.0E9F, 0.033333335F);
            }

            chatLastNs = now;
            chatP = Math.min(1.0F, chatP + dt / dur());
            return easeOut(chatP);
         }
      }
   }
}

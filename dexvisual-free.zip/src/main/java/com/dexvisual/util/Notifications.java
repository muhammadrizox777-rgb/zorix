package com.dexvisual.util;

import com.dexvisual.config.DexConfig;
import com.dexvisual.module.Modules;
import java.util.ArrayList;
import java.util.List;

public final class Notifications {
   public static final List<Notifications.Note> NOTES = new ArrayList<>();

   private Notifications() {
   }

   public static void push(String title, String message) {
      push(title, message, 7113983);
   }

   public static void push(String title, String message, int color) {
      if (Modules.NOTIFICATIONS != null && Modules.NOTIFICATIONS.cfg().enabled) {
         NOTES.add(new Notifications.Note(title, message, System.currentTimeMillis(), color));

         while (NOTES.size() > 5) {
            NOTES.remove(0);
         }
      }
   }

   public static void tick() {
      long life = DexConfig.get().notifSeconds * 1000L;
      NOTES.removeIf(n -> System.currentTimeMillis() - n.time() > life);
   }

   public record Note(String title, String message, long time, int color) {
   }
}

package com.dexvisual.util;

import com.dexvisual.module.Modules;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import java.util.List;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.client.render.chunk.ChunkBuilder.BuiltChunk;

public final class UndergroundCull {
   private static final Long2IntOpenHashMap SURFACE = new Long2IntOpenHashMap();
   private static final int BELOW_SURFACE = 12;
   private static final int BELOW_CAMERA = 16;

   private UndergroundCull() {
   }

   private static int minSurface(ClientWorld w, int cx, int cz) {
      int x = cx << 4;
      int z = cz << 4;
      int m = w.getTopY(Type.field_13200, x + 8, z + 8);
      m = Math.min(m, w.getTopY(Type.field_13200, x + 1, z + 1));
      m = Math.min(m, w.getTopY(Type.field_13200, x + 14, z + 1));
      m = Math.min(m, w.getTopY(Type.field_13200, x + 1, z + 14));
      return Math.min(m, w.getTopY(Type.field_13200, x + 14, z + 14));
   }

   public static void apply(List<BuiltChunk> list) {
      if (Modules.optimizing() && !Modules.OPTIMIZE.cfg().option && !list.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         ClientWorld w = mc.world;
         if (w != null && mc.player != null) {
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            int camSurface = w.getTopY(Type.field_13200, MathHelper.floor(cam.x), MathHelper.floor(cam.z));
            if (!(cam.y < camSurface - 4)) {
               int limit = MathHelper.floor(cam.y) - 16;
               SURFACE.clear();
               list.removeIf(c -> {
                  BlockPos o = c.getOrigin();
                  int top = o.getY() + 16;
                  if (top > limit) {
                     return false;
                  } else {
                     long key = ChunkPos.toLong(o.getX() >> 4, o.getZ() >> 4);
                     int s;
                     if (SURFACE.containsKey(key)) {
                        s = SURFACE.get(key);
                     } else {
                        s = minSurface(w, o.getX() >> 4, o.getZ() >> 4);
                        SURFACE.put(key, s);
                     }

                     return top < s - 12;
                  }
               });
            }
         }
      }
   }
}

package com.dexvisual.util;

import com.dexvisual.config.ModuleSettings;
import com.dexvisual.module.Modules;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.TriState;
import net.minecraft.client.render.RenderLayer.MultiPhaseParameters;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.RenderPhase.Texture;
import org.joml.Matrix4f;

public final class CustomSkyRenderer extends RenderPhase {
   public static final Identifier SKY_TEX = Identifier.of("dexvisual", "textures/sky/cloud1.png");
   public static final RenderLayer SKY_LAYER = RenderLayer.of(
      "dexvisual_custom_sky",
      VertexFormats.POSITION_TEXTURE_COLOR,
      DrawMode.field_27382,
      1536,
      false,
      false,
      MultiPhaseParameters.builder()
         .program(POSITION_TEXTURE_COLOR_PROGRAM)
         .texture(new Texture(SKY_TEX, TriState.field_52395, false))
         .transparency(TRANSLUCENT_TRANSPARENCY)
         .writeMaskState(COLOR_MASK)
         .cull(DISABLE_CULLING)
         .build(false)
   );

   private CustomSkyRenderer() {
      super("dexvisual_sky", () -> {}, () -> {});
   }

   public static void render(MatrixStack matrices, Immediate immediate, float tickDelta) {
      if (Modules.CUSTOMSKY != null && Modules.CUSTOMSKY.cfg().enabled) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world != null) {
            ModuleSettings s = Modules.CUSTOMSKY.cfg();
            float speed = s.val <= 0.001F ? 1.0F : s.val;
            float brightness = s.scale <= 0.001F ? 1.0F : s.scale;
            float opacity = s.val2 <= 0.001F ? 1.0F : s.val2;
            long time = System.currentTimeMillis();
            float rot = (float)(time * 0.004 * speed % 360.0);
            matrices.push();
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rot));
            VertexConsumer buffer = immediate.getBuffer(SKY_LAYER);
            Matrix4f mat = matrices.peek().getPositionMatrix();
            float D = 100.0F;
            int r = Math.min(255, Math.max(0, Math.round(255.0F * brightness)));
            int g = Math.min(255, Math.max(0, Math.round(255.0F * brightness)));
            int b = Math.min(255, Math.max(0, Math.round(255.0F * brightness)));
            int a = Math.min(255, Math.max(0, Math.round(255.0F * opacity)));
            float u0 = 0.0F;
            float u1 = 0.33333334F;
            float u2 = 0.6666667F;
            float u3 = 1.0F;
            float v0 = 0.0F;
            float v1 = 0.5F;
            float v2 = 1.0F;
            buffer.vertex(mat, -D, D, -D).texture(u1, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, D, D).texture(u1, v0).color(r, g, b, a);
            buffer.vertex(mat, D, D, D).texture(u2, v0).color(r, g, b, a);
            buffer.vertex(mat, D, D, -D).texture(u2, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, D, -D).texture(u1, v1).color(r, g, b, a);
            buffer.vertex(mat, D, D, -D).texture(u2, v1).color(r, g, b, a);
            buffer.vertex(mat, D, -D, -D).texture(u2, v2).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, -D).texture(u1, v2).color(r, g, b, a);
            buffer.vertex(mat, -D, D, D).texture(u0, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, D, -D).texture(u1, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, -D).texture(u1, v2).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, D).texture(u0, v2).color(r, g, b, a);
            buffer.vertex(mat, D, D, -D).texture(u2, v1).color(r, g, b, a);
            buffer.vertex(mat, D, D, D).texture(u3, v1).color(r, g, b, a);
            buffer.vertex(mat, D, -D, D).texture(u3, v2).color(r, g, b, a);
            buffer.vertex(mat, D, -D, -D).texture(u2, v2).color(r, g, b, a);
            buffer.vertex(mat, D, D, D).texture(u2, v0).color(r, g, b, a);
            buffer.vertex(mat, -D, D, D).texture(u3, v0).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, D).texture(u3, v1).color(r, g, b, a);
            buffer.vertex(mat, D, -D, D).texture(u2, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, -D).texture(u0, v0).color(r, g, b, a);
            buffer.vertex(mat, D, -D, -D).texture(u1, v0).color(r, g, b, a);
            buffer.vertex(mat, D, -D, D).texture(u1, v1).color(r, g, b, a);
            buffer.vertex(mat, -D, -D, D).texture(u0, v1).color(r, g, b, a);
            matrices.pop();
            immediate.draw(SKY_LAYER);
         }
      }
   }
}

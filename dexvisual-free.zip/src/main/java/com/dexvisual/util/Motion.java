package com.dexvisual.util;

public final class Motion {
   public static final float MAX_DT = 0.05F;

   private Motion() {
   }

   public static float dt(long[] lastNs) {
      long now = System.nanoTime();
      float d = lastNs[0] == 0L ? 0.016666668F : (float)(now - lastNs[0]) / 1.0E9F;
      lastNs[0] = now;
      return step(d);
   }

   public static float step(float d) {
      return !Float.isNaN(d) && !(d < 0.0F) ? Math.min(d, 0.05F) : 0.0F;
   }

   public static float easeOut(float t) {
      t = ColorUtil.clamp01(t);
      float u = 1.0F - t;
      return 1.0F - u * u * u;
   }

   public static float approach(float cur, float target, float dt, float speed, boolean animated) {
      if (animated && !Float.isNaN(cur) && !Float.isInfinite(cur)) {
         float k = 1.0F - (float)Math.exp(-Math.max(0.0F, speed) * step(dt));
         float v = cur + (target - cur) * k;
         return Math.abs(target - v) < 0.002F ? target : v;
      } else {
         return target;
      }
   }

   public static float progress(long startMs, long nowMs, float durationSec) {
      return durationSec <= 0.0F ? 1.0F : ColorUtil.clamp01((float)(nowMs - startMs) / 1000.0F / durationSec);
   }

   public static float duration(float base, float speed, boolean reduced) {
      float s = ColorUtil.clamp(speed, 0.3F, 2.5F, 1.0F);
      return (reduced ? base * 0.5F : base) / s;
   }
}

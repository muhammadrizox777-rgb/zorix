package com.dexvisual.config;

import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.util.ColorUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.loader.api.FabricLoader;

public class DexConfig {
   public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static DexConfig inst;
   public static volatile boolean dirty = false;
   static final String PVP = "watermark,cps,ping,keystrokes,armor,potion,target,combo,reach,damage,crosshair,notifications,togglesprint,hands,targetesp,jumpcircles";
   public Map<String, ModuleSettings> modules = new LinkedHashMap<>();
   public CrosshairSettings crosshair = new CrosshairSettings();
   public List<CrosshairSettings> crosshairPresets = new ArrayList<>();
   public List<Profile> profiles = new ArrayList<>();
   public List<Waypoint> waypoints = new ArrayList<>();
   public Map<String, String> optBackup;
   public String activeProfile = "PvP";
   public boolean hudVisible = true;
   public boolean snap = true;
   public boolean guides = true;
   public int snapDist = 5;
   public boolean menuAnim = true;
   public List<String> favorites = new ArrayList<>();
   public boolean hudAnim = true;
   public float animSpeed = 1.0F;
   public int accent = 0;
   public int themeColor = 7113983;
   public boolean cosmeticsOn = true;
   public boolean shareCosmetics = true;
   public boolean showOthers = true;
   public Map<String, String> cosmetics = new LinkedHashMap<>();
   public float wingSize = 1.0F;
   public float petSize = 1.0F;
   public float fxAmount = 1.0F;
   public boolean themeSync = true;
   public float panelOpacity = 0.6F;
   public int notifSeconds = 4;
   public String language = "uz";
   public int menuSkin = 0;
   public boolean menuSound = true;
   public boolean rainbow = false;
   public UiSettings ui = new UiSettings();
   private static String lastSaved = "";
   public static volatile String saveError = null;
   public static volatile String recoveredFrom = null;

   public DexConfig() {
   }

   public static DexConfig get() {
      if (inst == null) {
         load();
      }

      return inst;
   }

   private static Path path() {
      return FabricLoader.getInstance().getConfigDir().resolve("dexvisual.json");
   }

   public static void replace(DexConfig c) {
      inst = c;
      c.init();
      dirty = true;
   }

   public static void load() {
      Path p = path();

      try {
         if (Files.exists(p)) {
            String text = Files.readString(p);
            inst = (DexConfig)GSON.fromJson(text, DexConfig.class);
            if (inst != null) {
               lastSaved = text;
            }
         }
      } catch (Exception var4) {
         System.err.println("[DEX VISUAL] Could not read config, using defaults: " + var4);

         try {
            Path bad = p.resolveSibling("dexvisual.json.corrupt-" + System.currentTimeMillis());
            Files.move(p, bad, StandardCopyOption.REPLACE_EXISTING);
            recoveredFrom = bad.getFileName().toString();
         } catch (Exception var3) {
         }

         inst = null;
      }

      if (inst == null) {
         inst = new DexConfig();
      }

      inst.init();
   }

   private void init() {
      if (this.modules == null) {
         this.modules = new LinkedHashMap<>();
      }

      if (this.crosshair == null) {
         this.crosshair = new CrosshairSettings();
      }

      if (this.crosshairPresets == null) {
         this.crosshairPresets = new ArrayList<>();
      }

      if (this.profiles == null) {
         this.profiles = new ArrayList<>();
      }

      if (this.waypoints == null) {
         this.waypoints = new ArrayList<>();
      }

      if (this.favorites == null) {
         this.favorites = new ArrayList<>();
      }

      if (this.ui == null) {
         this.ui = new UiSettings();
      }

      this.ui.sanitize();
      if (!"uz".equals(this.language) && !"en".equals(this.language) && !"ru".equals(this.language)) {
         this.language = "uz";
      }

      this.themeColor &= 16777215;
      this.panelOpacity = ColorUtil.clamp(this.panelOpacity, 0.3F, 1.0F, 0.6F);
      this.animSpeed = ColorUtil.clamp(this.animSpeed, 0.3F, 2.5F, 1.0F);
      if (this.profiles.isEmpty()) {
         this.createDefaultProfiles();
         this.applyProfile("PvP");
      }
   }

   public void save() {
      try {
         this.syncActive();
         String json = GSON.toJson(this);
         if (json.equals(lastSaved)) {
            dirty = false;
            saveError = null;
            return;
         }

         Path p = path();
         Path tmp = p.resolveSibling("dexvisual.json.tmp");
         Files.writeString(tmp, json);
         if (Files.exists(p)) {
            Files.copy(p, p.resolveSibling("dexvisual.json.bak"), StandardCopyOption.REPLACE_EXISTING);
         }

         Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
         lastSaved = json;
         dirty = false;
         saveError = null;
      } catch (Exception var4) {
         saveError = String.valueOf(var4.getMessage());
         System.err.println("[DEX VISUAL] Could not save config: " + var4);
      }
   }

   public static void markDirty() {
      dirty = true;
   }

   public ModuleSettings module(HudModule m) {
      return this.modules.computeIfAbsent(m.id, k -> m.defaults());
   }

   private void createDefaultProfiles() {
      String[][] sets = new String[][]{
         {"PvP", "watermark,cps,ping,keystrokes,armor,potion,target,combo,reach,damage,crosshair,notifications,togglesprint,hands,targetesp,jumpcircles"},
         {"Survival", "watermark,coords,direction,clock,armor,potion,durability,itemcounter,waypoints,notifications,togglesprint,togglesneak,crosshair,hands"},
         {"BedWars", "watermark,cps,ping,armor,potion,kills,combo,itemcounter,target,damage,clock,session,notifications,crosshair,hands"},
         {"SkyWars", "watermark,cps,ping,keystrokes,armor,target,combo,kills,potion,damage,crosshair,notifications,hands"},
         {"Custom", "watermark,cps,ping,coords,notifications,crosshair"}
      };

      for (String[] set : sets) {
         Profile p = new Profile(set[0]);
         List<String> on = Arrays.asList(set[1].split(","));

         for (HudModule m : Modules.ALL) {
            ModuleSettings s = m.defaults();
            s.enabled = on.contains(m.id);
            p.modules.put(m.id, s);
         }

         this.profiles.add(p);
      }
   }

   public Profile profile(String name) {
      for (Profile p : this.profiles) {
         if (p.name.equalsIgnoreCase(name)) {
            return p;
         }
      }

      return null;
   }

   public void syncActive() {
      Profile p = this.profile(this.activeProfile);
      if (p != null) {
         p.modules = new LinkedHashMap<>();

         for (Entry<String, ModuleSettings> e : this.modules.entrySet()) {
            p.modules.put(e.getKey(), e.getValue().copy());
         }

         p.crosshair = this.crosshair.copy();
      }
   }

   public boolean applyProfile(String name) {
      Profile p = this.profile(name);
      if (p == null) {
         return false;
      } else {
         this.syncActive();
         this.modules = new LinkedHashMap<>();

         for (Entry<String, ModuleSettings> e : p.modules.entrySet()) {
            this.modules.put(e.getKey(), e.getValue().copy());
         }

         this.crosshair = p.crosshair == null ? new CrosshairSettings() : p.crosshair.copy();
         this.activeProfile = p.name;
         dirty = true;
         return true;
      }
   }

   public Profile createProfile(String name) {
      this.syncActive();
      Profile p = new Profile(this.uniqueName(name));

      for (Entry<String, ModuleSettings> e : this.modules.entrySet()) {
         p.modules.put(e.getKey(), e.getValue().copy());
      }

      p.crosshair = this.crosshair.copy();
      this.profiles.add(p);
      dirty = true;
      return p;
   }

   public Profile duplicateProfile(Profile src) {
      if (src.name.equals(this.activeProfile)) {
         this.syncActive();
      }

      Profile p = new Profile(this.uniqueName(src.name + " Copy"));

      for (Entry<String, ModuleSettings> e : src.modules.entrySet()) {
         p.modules.put(e.getKey(), e.getValue().copy());
      }

      p.crosshair = src.crosshair.copy();
      this.profiles.add(p);
      dirty = true;
      return p;
   }

   public void renameProfile(Profile p, String name) {
      name = name.trim();
      if (!name.isEmpty() && (this.profile(name) == null || this.profile(name) == p)) {
         if (p.name.equals(this.activeProfile)) {
            this.activeProfile = name;
         }

         p.name = name;
         dirty = true;
      }
   }

   public boolean deleteProfile(Profile p) {
      if (this.profiles.size() <= 1) {
         return false;
      } else {
         this.profiles.remove(p);
         if (p.name.equals(this.activeProfile)) {
            this.applyProfile(this.profiles.get(0).name);
         }

         dirty = true;
         return true;
      }
   }

   public String exportProfile(Profile p) {
      if (p.name.equals(this.activeProfile)) {
         this.syncActive();
      }

      return GSON.toJson(p);
   }

   public Profile importProfile(String json) {
      try {
         Profile p = (Profile)GSON.fromJson(json, Profile.class);
         if (p != null && p.modules != null && !p.modules.isEmpty()) {
            if (p.name == null || p.name.isBlank()) {
               p.name = "Imported";
            }

            p.name = this.uniqueName(p.name);
            if (p.crosshair == null) {
               p.crosshair = new CrosshairSettings();
            }

            this.profiles.add(p);
            dirty = true;
            return p;
         } else {
            return null;
         }
      } catch (Exception var3) {
         return null;
      }
   }

   public String uniqueName(String base) {
      base = base != null && !base.isBlank() ? base.trim() : "Profile";
      String n = base;
      int i = 2;

      while (this.profile(n) != null) {
         n = base + " " + i++;
      }

      return n;
   }

   public void resetModules(boolean keepEnabled) {
      for (HudModule m : Modules.ALL) {
         ModuleSettings old = this.modules.get(m.id);
         ModuleSettings d = m.defaults();
         d.enabled = keepEnabled && old != null ? old.enabled : m.defaultOn;
         d.key = old != null ? old.key : -1;
         this.modules.put(m.id, d);
      }

      dirty = true;
   }

   public void resetAll() {
      this.resetModules(false);
      this.crosshair = new CrosshairSettings();
      this.crosshairPresets.clear();
      this.hudVisible = true;
      this.snap = true;
      this.guides = true;
      this.snapDist = 5;
      this.menuAnim = true;
      this.hudAnim = true;
      this.animSpeed = 1.0F;
      this.accent = 0;
      this.panelOpacity = 0.6F;
      this.notifSeconds = 4;
      this.themeColor = 7113983;
      this.themeSync = true;
      this.menuSkin = 0;
      this.rainbow = false;
      this.ui.resetAppearance();
      this.ui.activePreset = "";
      this.applyDefaultEnabled();
      dirty = true;
   }

   private void applyDefaultEnabled() {
      List<String> on = Arrays.asList(
         "watermark,cps,ping,keystrokes,armor,potion,target,combo,reach,damage,crosshair,notifications,togglesprint,hands,targetesp,jumpcircles".split(",")
      );

      for (HudModule m : Modules.ALL) {
         this.module(m).enabled = on.contains(m.id);
      }
   }

   public Waypoint addWaypoint(String name, double x, double y, double z, String dim) {
      Waypoint w = new Waypoint(name, x, y, z, dim);
      int[] cols = new int[]{7113983, 10513663, 4184319, 16739508, 4652980, 16762967};
      w.color = cols[this.waypoints.size() % cols.length];
      this.waypoints.add(w);
      dirty = true;
      return w;
   }
}

package com.dexvisual.config;

public class ModuleSettings {
   public boolean enabled = false;
   public boolean ownColor;
   public float x = 0.02F;
   public float y = 0.02F;
   public float scale = 1.0F;
   public float opacity = 1.0F;
   public boolean background = true;
   public int bgColor = 724244;
   public float bgOpacity = 0.28F;
   public boolean border = true;
   public int borderColor = 7113983;
   public int borderWidth = 1;
   public int radius = 6;
   public int textColor = 16777215;
   public boolean shadow = true;
   public String animation = "POP";
   public boolean option = false;
   public boolean option2 = false;
   public boolean option3 = false;
   public float val = 0.5F;
   public float val2 = 1.0F;
   public int lineW = 3;
   public float val3 = 0.5F;
   public float val4 = 0.6F;
   public float offX = 0.0F;
   public float offY = 0.0F;
   public float glowRadius = 1.0F;
   public int glowColor = 16727450;
   public boolean glowPulse = true;
   public boolean glowHealthColor = false;
   public boolean glowName = true;
   public boolean glowHealthText = true;
   public int key = -1;

   public ModuleSettings() {
   }

   public ModuleSettings copy() {
      return (ModuleSettings)DexConfig.GSON.fromJson(DexConfig.GSON.toJson(this), ModuleSettings.class);
   }
}

package com.dexvisual.config;

public class CrosshairSettings {
   public String name = null;
   public boolean ownColor;
   public String style = "CROSS";
   public int size = 6;
   public int thickness = 1;
   public int gap = 3;
   public boolean outline = true;
   public boolean dot = false;
   public boolean dynamic = false;
   public int color = 4652980;
   public float opacity = 1.0F;
   public int hitColor = 16731501;
   public boolean hitFlash = true;
   public boolean glow = true;
   public boolean hitMarker = true;
   public int offX = 0;
   public int offY = 0;
   public boolean lockPos = false;

   public CrosshairSettings() {
   }

   public CrosshairSettings copy() {
      return (CrosshairSettings)DexConfig.GSON.fromJson(DexConfig.GSON.toJson(this), CrosshairSettings.class);
   }
}

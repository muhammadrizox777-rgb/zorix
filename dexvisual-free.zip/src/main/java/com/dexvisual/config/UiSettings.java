package com.dexvisual.config;

import com.dexvisual.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;

public class UiSettings {
   public static final int MAX_RECENT = 12;
   public static final float SCALE_MIN = 0.7F;
   public static final float SCALE_MAX = 1.3F;
   public boolean themeAccent = false;
   public int accent2 = -1;
   public int bgColor = -1;
   public int panelColor = -1;
   public int sidebarColor = -1;
   public int textColor = -1;
   public int mutedColor = -1;
   public int borderColor = -1;
   public int selectedColor = -1;
   public float backdrop = 0.2F;
   public float cardOpacity = 0.55F;
   public boolean gradient = true;
   public int gradientDir = 0;
   public float uiScale = 0.0F;
   public boolean reducedMotion = false;
   public int sort = 3;
   public List<String> recent = new ArrayList<>();
   public String activePreset = "";

   public UiSettings() {
   }

   public void sanitize() {
      this.accent2 = ColorUtil.normalizeOptional(this.accent2);
      this.bgColor = ColorUtil.normalizeOptional(this.bgColor);
      this.panelColor = ColorUtil.normalizeOptional(this.panelColor);
      this.sidebarColor = ColorUtil.normalizeOptional(this.sidebarColor);
      this.textColor = ColorUtil.normalizeOptional(this.textColor);
      this.mutedColor = ColorUtil.normalizeOptional(this.mutedColor);
      this.borderColor = ColorUtil.normalizeOptional(this.borderColor);
      this.selectedColor = ColorUtil.normalizeOptional(this.selectedColor);
      this.backdrop = ColorUtil.clamp(this.backdrop, 0.0F, 0.8F, 0.2F);
      this.cardOpacity = ColorUtil.clamp(this.cardOpacity, 0.2F, 1.0F, 0.55F);
      this.gradientDir = Math.floorMod(this.gradientDir, 4);
      if (this.uiScale != 0.0F) {
         this.uiScale = ColorUtil.clamp(this.uiScale, 0.7F, 1.3F, 0.0F);
      }

      this.sort = Math.floorMod(this.sort, 5);
      if (this.recent == null) {
         this.recent = new ArrayList<>();
      }

      List<String> clean = new ArrayList<>();

      for (String s : this.recent) {
         if (s != null && !s.isBlank() && !clean.contains(s) && clean.size() < 12) {
            clean.add(s);
         }
      }

      this.recent = clean;
      if (this.activePreset == null) {
         this.activePreset = "";
      }
   }

   public boolean touchRecent(String id) {
      if (id != null && !id.isBlank()) {
         if (!this.recent.isEmpty() && this.recent.get(0).equals(id)) {
            return false;
         } else {
            this.recent.remove(id);
            this.recent.add(0, id);

            while (this.recent.size() > 12) {
               this.recent.remove(this.recent.size() - 1);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public UiSettings copyAppearance() {
      UiSettings u = new UiSettings();
      u.themeAccent = this.themeAccent;
      u.accent2 = this.accent2;
      u.bgColor = this.bgColor;
      u.panelColor = this.panelColor;
      u.sidebarColor = this.sidebarColor;
      u.textColor = this.textColor;
      u.mutedColor = this.mutedColor;
      u.borderColor = this.borderColor;
      u.selectedColor = this.selectedColor;
      u.backdrop = this.backdrop;
      u.cardOpacity = this.cardOpacity;
      u.gradient = this.gradient;
      u.gradientDir = this.gradientDir;
      u.uiScale = this.uiScale;
      u.reducedMotion = this.reducedMotion;
      return u;
   }

   public void applyAppearance(UiSettings src) {
      this.themeAccent = src.themeAccent;
      this.accent2 = src.accent2;
      this.bgColor = src.bgColor;
      this.panelColor = src.panelColor;
      this.sidebarColor = src.sidebarColor;
      this.textColor = src.textColor;
      this.mutedColor = src.mutedColor;
      this.borderColor = src.borderColor;
      this.selectedColor = src.selectedColor;
      this.backdrop = src.backdrop;
      this.cardOpacity = src.cardOpacity;
      this.gradient = src.gradient;
      this.gradientDir = src.gradientDir;
      this.uiScale = src.uiScale;
      this.reducedMotion = src.reducedMotion;
      this.sanitize();
   }

   public void resetAppearance() {
      this.applyAppearance(new UiSettings());
   }
}

package com.dexvisual.config;

import com.dexvisual.util.ColorUtil;

public class DesignPreset {
   public String name;
   public int themeColor = -1;
   public float panelOpacity = 0.6F;
   public int menuSkin = 0;
   public UiSettings ui = new UiSettings();

   public DesignPreset() {
   }

   public DesignPreset(String name) {
      this.name = name;
   }

   public DesignPreset validated() {
      if (this.name != null && !this.name.isBlank()) {
         this.name = DesignStore.cleanName(this.name);
         if (this.ui == null) {
            this.ui = new UiSettings();
         }

         this.ui.sanitize();
         if (this.themeColor >= 0) {
            this.themeColor &= 16777215;
         } else {
            this.themeColor = -1;
         }

         this.panelOpacity = ColorUtil.clamp(this.panelOpacity, 0.3F, 1.0F, 0.6F);
         if (this.menuSkin < 0) {
            this.menuSkin = 0;
         }

         return this;
      } else {
         return null;
      }
   }
}

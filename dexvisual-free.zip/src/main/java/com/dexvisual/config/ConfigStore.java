package com.dexvisual.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class ConfigStore {
   private ConfigStore() {
   }

   private static Path dir() throws IOException {
      Path d = FabricLoader.getInstance().getConfigDir().resolve("dexvisual-configs");
      Files.createDirectories(d);
      return d;
   }

   private static String safe(String name) {
      String n = name == null ? "" : name.trim().replaceAll("[^A-Za-z0-9 _-]", "_");
      return n.isEmpty() ? "config" : n;
   }

   public static List<String> list() {
      List<String> out = new ArrayList<>();

      try (Stream<Path> st = Files.list(dir())) {
         st.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
            String f = p.getFileName().toString();
            out.add(f.substring(0, f.length() - 5));
         });
      } catch (Exception var6) {
      }

      Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
      return out;
   }

   public static boolean save(String name) {
      try {
         DexConfig cfg = DexConfig.get();
         cfg.syncActive();
         Files.writeString(dir().resolve(safe(name) + ".json"), DexConfig.GSON.toJson(cfg));
         return true;
      } catch (Exception var2) {
         return false;
      }
   }

   public static String read(String name) {
      try {
         return Files.readString(dir().resolve(safe(name) + ".json"));
      } catch (Exception var2) {
         return "";
      }
   }

   public static boolean load(String name) {
      try {
         DexConfig c = (DexConfig)DexConfig.GSON.fromJson(read(name), DexConfig.class);
         if (c == null) {
            return false;
         } else {
            if (c.ui == null) {
               c.ui = DexConfig.get().ui;
            }

            DexConfig.replace(c);
            return true;
         }
      } catch (Exception var2) {
         return false;
      }
   }

   public static boolean delete(String name) {
      try {
         return Files.deleteIfExists(dir().resolve(safe(name) + ".json"));
      } catch (Exception var2) {
         return false;
      }
   }

   public static String importJson(String json, String name) {
      try {
         DexConfig c = (DexConfig)DexConfig.GSON.fromJson(json, DexConfig.class);
         if (c != null && c.modules != null && !c.modules.isEmpty()) {
            String n = safe(name != null && !name.isBlank() ? name : "imported");
            Files.writeString(dir().resolve(n + ".json"), json);
            return n;
         } else {
            return null;
         }
      } catch (Exception var4) {
         return null;
      }
   }
}

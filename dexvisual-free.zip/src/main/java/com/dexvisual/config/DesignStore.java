package com.dexvisual.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class DesignStore {
   public static final int MAX_NAME = 24;

   private DesignStore() {
   }

   private static Path dir() throws IOException {
      Path d = FabricLoader.getInstance().getConfigDir().resolve("dexvisual-designs");
      Files.createDirectories(d);
      return d;
   }

   public static String cleanName(String name) {
      String n = name == null ? "" : name.trim().replaceAll("[^\\p{L}\\p{N} _-]", "_");
      if (n.length() > 24) {
         n = n.substring(0, 24).trim();
      }

      return n;
   }

   private static DesignPreset b(String name, int theme, int skin, float panel, int accent2, int bg, int panelC, int side, int dir) {
      DesignPreset p = new DesignPreset(name);
      p.themeColor = theme;
      p.menuSkin = skin;
      p.panelOpacity = panel;
      p.ui.accent2 = accent2;
      p.ui.bgColor = bg;
      p.ui.panelColor = panelC;
      p.ui.sidebarColor = side;
      p.ui.gradient = true;
      p.ui.gradientDir = dir;
      p.ui.themeAccent = true;
      return p;
   }

   public static List<DesignPreset> builtIns() {
      List<DesignPreset> l = new ArrayList<>();
      l.add(b("DEX Classic", 7113983, 0, 0.6F, -1, -1, -1, -1, 0));
      l.add(b("Aurora", 4184319, 1, 0.65F, 4652980, 267292, 469558, 267292, 2));
      l.add(b("Ember", 16739405, 2, 0.7F, 16762967, 1574409, 2820624, 1574409, 1));
      l.add(b("Nebula", 12616956, 3, 0.7F, 16739508, 722212, 2756429, 722212, 0));
      l.add(b("Onyx Premium", 16777215, 0, 0.75F, 5592405, 131586, 526344, 328965, 3));
      l.add(b("Diamond HUD", 4388323, 1, 0.65F, 4364021, 70426, 140595, 72228, 0));
      l.add(b("Crimson Pro", 16722474, 2, 0.8F, 16747562, 1310977, 3015170, 1704193, 2));
      l.add(b("Frost Glass", 8238335, 4, 0.5F, 16777215, -1, -1, -1, 0));
      return l;
   }

   public static boolean isBuiltIn(String name) {
      for (DesignPreset p : builtIns()) {
         if (p.name.equalsIgnoreCase(name)) {
            return true;
         }
      }

      return false;
   }

   public static DesignPreset builtIn(String name) {
      for (DesignPreset p : builtIns()) {
         if (p.name.equalsIgnoreCase(name)) {
            return p;
         }
      }

      return null;
   }

   public static List<String> listCustom() {
      List<String> out = new ArrayList<>();

      try (Stream<Path> st = Files.list(dir())) {
         st.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
            String f = p.getFileName().toString();
            out.add(f.substring(0, f.length() - 5));
         });
      } catch (Exception var6) {
      }

      Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
      return out;
   }

   public static DesignPreset read(String name) {
      try {
         DesignPreset p = (DesignPreset)DexConfig.GSON.fromJson(Files.readString(dir().resolve(cleanName(name) + ".json")), DesignPreset.class);
         return p == null ? null : p.validated();
      } catch (Exception var2) {
         return null;
      }
   }

   public static boolean write(DesignPreset p) {
      try {
         DesignPreset v = p.validated();
         if (v == null) {
            return false;
         } else {
            Path target = dir().resolve(v.name + ".json");
            Path tmp = dir().resolve(v.name + ".json.tmp");
            Files.writeString(tmp, DexConfig.GSON.toJson(v));
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            return true;
         }
      } catch (Exception var4) {
         return false;
      }
   }

   public static boolean delete(String name) {
      try {
         return Files.deleteIfExists(dir().resolve(cleanName(name) + ".json"));
      } catch (Exception var2) {
         return false;
      }
   }

   public static boolean rename(String from, String to) {
      try {
         String t = cleanName(to);
         if (!t.isEmpty() && !isBuiltIn(t)) {
            DesignPreset p = read(from);
            if (p == null) {
               return false;
            } else if (Files.exists(dir().resolve(t + ".json")) && !t.equalsIgnoreCase(cleanName(from))) {
               return false;
            } else {
               p.name = t;
               if (!write(p)) {
                  return false;
               } else {
                  if (!t.equalsIgnoreCase(cleanName(from))) {
                     delete(from);
                  }

                  return true;
               }
            }
         } else {
            return false;
         }
      } catch (Exception var4) {
         return false;
      }
   }

   public static DesignPreset parse(String json) {
      try {
         if (json != null && !json.isBlank() && json.length() <= 20000) {
            DesignPreset p = (DesignPreset)DexConfig.GSON.fromJson(json, DesignPreset.class);
            return p == null ? null : p.validated();
         } else {
            return null;
         }
      } catch (Exception var2) {
         return null;
      }
   }

   public static String export(DesignPreset p) {
      return DexConfig.GSON.toJson(p);
   }

   public static DesignPreset capture(String name) {
      DexConfig c = DexConfig.get();
      DesignPreset p = new DesignPreset(name);
      p.themeColor = c.themeColor & 16777215;
      p.panelOpacity = c.panelOpacity;
      p.menuSkin = c.menuSkin;
      p.ui = c.ui.copyAppearance();
      return p;
   }

   public static void apply(DesignPreset p) {
      DexConfig c = DexConfig.get();
      if (p.themeColor >= 0) {
         c.themeColor = p.themeColor;
      }

      c.panelOpacity = p.panelOpacity;
      c.menuSkin = p.menuSkin;
      c.ui.applyAppearance(p.ui);
      c.ui.activePreset = p.name;
      DexConfig.markDirty();
   }
}

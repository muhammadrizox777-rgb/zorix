package com.dexvisual;

import com.dexvisual.config.DexConfig;
import com.dexvisual.gui.ChatEditor;
import com.dexvisual.gui.MenuScreen;
import com.dexvisual.gui.TitleBrand;
import com.dexvisual.hud.HudRenderer;
import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.net.SyncNet;
import com.dexvisual.util.Freelook;
import com.dexvisual.util.Notifications;
import com.dexvisual.util.Projector;
import com.dexvisual.util.Tracker;
import com.dexvisual.util.WorldOverlay;
import com.dexvisual.util.Zoom;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.AfterTranslucent;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.BlockOutline;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.util.InputUtil.Type;

public class DexVisualClient implements ClientModInitializer {
   public static final String MOD_ID = "dexvisual";
   private static KeyBinding menuKey;
   private static KeyBinding hudKey;
   private static KeyBinding sprintKey;
   private static KeyBinding sneakKey;
   private static KeyBinding freelookKey;
   private static KeyBinding zoomKey;
   private final Map<String, Boolean> keyDown = new HashMap<>();

   public DexVisualClient() {
   }

   public static String menuKeyName() {
      return menuKey == null ? "Right Shift" : menuKey.getBoundKeyLocalizedText().getString();
   }

   public static boolean menuKeyMatches(int key, int sc) {
      return menuKey != null ? menuKey.matchesKey(key, sc) : key == 344;
   }

   public void onInitializeClient() {
      DexConfig.get();
      SyncNet.init();
      menuKey = registerKey("key.dexvisual.menu", Type.field_1668, 344, "key.categories.dexvisual");
      hudKey = registerKey("key.dexvisual.hud", Type.field_1668, 72, "key.categories.dexvisual");
      sprintKey = registerKey("key.dexvisual.sprint", Type.field_1668, -1, "key.categories.dexvisual");
      sneakKey = registerKey("key.dexvisual.sneak", Type.field_1668, -1, "key.categories.dexvisual");
      freelookKey = registerKey("key.dexvisual.freelook", Type.field_1668, 342, "key.categories.dexvisual");
      zoomKey = registerKey("key.dexvisual.zoom", Type.field_1668, 67, "key.categories.dexvisual");
      WorldRenderEvents.BLOCK_OUTLINE.register((BlockOutline)(wctx, octx) -> !Modules.BLOCKOVERLAY.cfg().enabled);
      WorldRenderEvents.AFTER_TRANSLUCENT.register((AfterTranslucent)wctx -> {
         Projector.capture(wctx);
         WorldOverlay.render(wctx);
      });
      HudRenderCallback.EVENT.register((HudRenderCallback)(ctx, tickCounter) -> {
         MinecraftClient mc = MinecraftClient.getInstance();
         Tracker.frame(mc);
         if (!mc.options.hudHidden) {
            HudRenderer.render(ctx, mc, false);
         }
      });
      UseEntityCallback.EVENT
         .register(
            (UseEntityCallback)(player, world, hand, entity, hit) -> {
               if (world.isClient
                  && hand == Hand.field_5808
                  && entity instanceof PlayerEntity le
                  && !le.isInvisible()
                  && Modules.TARGETESP.cfg().enabled
                  && !Modules.TARGETESP.cfg().option) {
                  Modules.TargetEspModule.toggleLock(le);
               }

               return ActionResult.PASS;
            }
         );
      UseItemCallback.EVENT.register((UseItemCallback)(player, world, hand) -> {
         if (world.isClient) {
            Modules.ARTIHELPER.onUse(player, hand);
         }

         return ActionResult.PASS;
      });
      UseBlockCallback.EVENT.register((UseBlockCallback)(player, world, hand, hit) -> {
         if (world.isClient) {
            Modules.ARTIHELPER.onUse(player, hand);
         }

         return ActionResult.PASS;
      });
      ScreenEvents.AFTER_INIT.register((AfterInit)(client, screen, sw, sh) -> {
         if (screen instanceof ChatScreen) {
            ChatEditor.hook(screen);
         }

         if (screen instanceof TitleScreen) {
            ScreenEvents.afterRender(screen).register((AfterRender)(s, ctx, mx, my, td) -> TitleBrand.render(ctx, s, mx, my));
            ScreenMouseEvents.allowMouseClick(screen).register((AllowMouseClick)(s, mx, my, btn) -> !TitleBrand.click(s, mx, my, btn));
         }
      });
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hit) -> {
         if (world.isClient && entity instanceof LivingEntity le) {
            Tracker.onAttack(le);
         }

         return ActionResult.PASS;
      });
      ClientTickEvents.END_CLIENT_TICK.register(this::tick);
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)c -> DexConfig.get().save());
      this.registerCommands();
   }

   private void tick(MinecraftClient mc) {
      Tracker.tick(mc);

      for (HudModule m : Modules.ALL) {
         m.tick(mc);
      }

      if (freelookKey != null) {
         Freelook.tick(mc, freelookKey);
      }

      if (zoomKey != null) {
         Zoom.tick(mc, zoomKey);
      }

      boolean openMenu = false;
      if (menuKey != null) {
         while (menuKey.wasPressed()) {
            openMenu = true;
         }
      }

      if (openMenu && !(mc.currentScreen instanceof MenuScreen) && !(mc.currentScreen instanceof ChatScreen)) {
         mc.setScreen(new MenuScreen());
      }

      if (hudKey != null) {
         while (hudKey.wasPressed()) {
            DexConfig c = DexConfig.get();
            c.hudVisible = !c.hudVisible;
            DexConfig.markDirty();
            Notifications.push("HUD", c.hudVisible ? "Visible" : "Hidden", c.hudVisible ? 4652980 : 16731501);
         }
      }

      if (sprintKey != null) {
         while (sprintKey.wasPressed()) {
            Modules.toggle(Modules.TOGGLESPRINT);
         }
      }

      if (sneakKey != null) {
         while (sneakKey.wasPressed()) {
            Modules.toggle(Modules.TOGGLESNEAK);
         }
      }

      if (mc.currentScreen == null && mc.player != null) {
         long handle = mc.getWindow().getHandle();

         for (HudModule m : Modules.ALL) {
            int key = m.cfg().key;
            if (key >= 0) {
               boolean down = InputUtil.isKeyPressed(handle, key);
               boolean was = this.keyDown.getOrDefault(m.id, false);
               if (down && !was) {
                  Modules.toggle(m);
               }

               this.keyDown.put(m.id, down);
            }
         }
      }
   }

   private static KeyBinding registerKey(String id, Type type, int code, String category) {
      KeyBinding kb = null;

      try {
         Constructor<KeyBinding> c = KeyBinding.class.getConstructor(String.class, Type.class, int.class, String.class);
         kb = c.newInstance(id, type, code, category);
      } catch (Throwable var15) {
      }

      if (kb == null) {
         try {
            Constructor<KeyBinding> c = KeyBinding.class.getConstructor(String.class, int.class, String.class);
            kb = c.newInstance(id, code, category);
         } catch (Throwable var14) {
         }
      }

      if (kb == null) {
         try {
            for (Constructor<?> c : KeyBinding.class.getConstructors()) {
               Class<?>[] params = c.getParameterTypes();
               if (params.length >= 4 && params[0] == String.class && params[1] == Type.class && params[2] == int.class) {
                  Class<?> catClass = params[3];
                  Object catObj = createCategory(catClass, category);
                  if (params.length == 4) {
                     kb = (KeyBinding)c.newInstance(id, type, code, catObj);
                     break;
                  }

                  if (params.length == 5 && params[4] == int.class) {
                     kb = (KeyBinding)c.newInstance(id, type, code, catObj, 0);
                     break;
                  }
               } else if (params.length == 3 && params[0] == String.class && params[1] == int.class) {
                  Class<?> catClassx = params[2];
                  Object catObjx = createCategory(catClassx, category);
                  kb = (KeyBinding)c.newInstance(id, code, catObjx);
                  break;
               }
            }
         } catch (Throwable var16) {
            System.err.println("[DexVisual] KeyBinding Category reflection failed: " + var16);
         }
      }

      if (kb == null) {
         try {
            kb = new KeyBinding(id, type, code, category);
         } catch (Throwable var13) {
            System.err.println("[DexVisual] Direct KeyBinding failed: " + var13);
         }
      }

      if (kb != null) {
         try {
            return KeyBindingHelper.registerKeyBinding(kb);
         } catch (Throwable var12) {
            return kb;
         }
      } else {
         return null;
      }
   }

   private static Object createCategory(Class<?> catClass, String category) {
      try {
         Identifier id = Identifier.of("dexvisual", "main");

         for (Constructor<?> c : catClass.getConstructors()) {
            if (c.getParameterTypes().length == 1) {
               Class<?> p0 = c.getParameterTypes()[0];
               if (Identifier.class.isAssignableFrom(p0) || p0.getName().contains("class_2960") || p0.getName().contains("Identifier")) {
                  return c.newInstance(id);
               }
            }
         }

         for (Method m : catClass.getMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getReturnType() == catClass && m.getParameterTypes().length == 1) {
               Class<?> p0 = m.getParameterTypes()[0];
               if (Identifier.class.isAssignableFrom(p0) || p0.getName().contains("class_2960") || p0.getName().contains("Identifier")) {
                  return m.invoke(null, id);
               }
            }
         }

         for (Method mx : catClass.getDeclaredMethods()) {
            if (Modifier.isStatic(mx.getModifiers())
               && mx.getReturnType() == catClass
               && mx.getParameterTypes().length == 1
               && mx.getParameterTypes()[0] == String.class) {
               mx.setAccessible(true);
               return mx.invoke(null, category);
            }
         }

         for (Field f : catClass.getFields()) {
            if (Modifier.isStatic(f.getModifiers()) && f.getType() == catClass) {
               return f.get(null);
            }
         }
      } catch (Throwable var8) {
         System.err.println("[DexVisual] createCategory failed: " + var8);
      }

      return null;
   }

   private void registerCommands() {
   }
}

package com.dexvisual.module;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule {
   public final String id;
   public final String name;
   public final String category;
   public final String description;
   public float defX;
   public float defY;
   public final boolean box;
   public final boolean defaultOn;
   public String optionLabel = null;
   public String optionLabel2 = null;
   public String optionLabel3 = null;
   public boolean container = true;

   protected HudModule(String id, String name, String category, String description, float x, float y, boolean box, boolean defaultOn) {
      this.id = id;
      this.name = name;
      this.category = category;
      this.description = description;
      this.defX = x;
      this.defY = y;
      this.box = box;
      this.defaultOn = defaultOn;
   }

   public HudModule option(String label) {
      this.optionLabel = label;
      return this;
   }

   public HudModule noContainer() {
      this.container = false;
      return this;
   }

   public ModuleSettings cfg() {
      return DexConfig.get().module(this);
   }

   public ModuleSettings defaults() {
      ModuleSettings s = new ModuleSettings();
      s.enabled = this.defaultOn;
      s.x = this.defX;
      s.y = this.defY;
      return s;
   }

   public int width(MinecraftClient mc, boolean preview) {
      return 0;
   }

   public int height(MinecraftClient mc, boolean preview) {
      return 0;
   }

   public void render(DrawContext ctx, MinecraftClient mc, int color, boolean preview) {
   }

   public void renderOverlay(DrawContext ctx, MinecraftClient mc) {
   }

   public void tick(MinecraftClient mc) {
   }

   public boolean isOn() {
      return this.cfg().enabled;
   }

   static {
      LOCKED.enabled = false;
   }
}

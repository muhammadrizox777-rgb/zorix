package com.dexvisual.module;

import com.dexvisual.util.Gfx;
import java.util.function.Function;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class TextModule extends HudModule {
   private final Function<MinecraftClient, String> live;
   private final String sample;

   public TextModule(String id, String name, String cat, String desc, float x, float y, String sample, Function<MinecraftClient, String> live) {
      super(id, name, cat, desc, x, y, true, false);
      this.live = live;
      this.sample = sample;
   }

   protected String text(MinecraftClient mc) {
      if (mc.player != null && mc.world != null) {
         try {
            String s = this.live.apply(mc);
            return s != null && !s.isEmpty() ? s : this.sample;
         } catch (Exception var3) {
            return this.sample;
         }
      } else {
         return this.sample;
      }
   }

   @Override
   public int width(MinecraftClient mc, boolean preview) {
      int w = 0;

      for (String l : this.text(mc).split("\n")) {
         w = Math.max(w, Gfx.tw(l));
      }

      return w;
   }

   @Override
   public int height(MinecraftClient mc, boolean preview) {
      return this.text(mc).split("\n").length * 10 - 1;
   }

   @Override
   public void render(DrawContext ctx, MinecraftClient mc, int color, boolean preview) {
      String[] lines = this.text(mc).split("\n");
      boolean sh = this.cfg().shadow;

      for (int i = 0; i < lines.length; i++) {
         Gfx.text(ctx, lines[i], 0, i * 10, color, sh);
      }
   }
}

package com.dexvisual.module;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.gui.Theme;
import com.dexvisual.gui.Widgets;
import com.dexvisual.hud.CrosshairRenderer;
import com.dexvisual.util.CardUi;
import com.dexvisual.util.Gfx;
import com.dexvisual.util.HandShader;
import com.dexvisual.util.I18n;
import com.dexvisual.util.KillFx;
import com.dexvisual.util.Notifications;
import com.dexvisual.util.Projector;
import com.dexvisual.util.Tracker;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.Hand;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.util.Arm;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.registry.Registries;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class Modules {
   public static final List<HudModule> ALL = new ArrayList<>();
   public static HudModule FPS = reg(
      new TextModule("fps", "FPS Counter", "Info", "Frames per second", 0.01F, 0.02F, "FPS: 240", mc -> "FPS: " + mc.getCurrentFps())
   );
   public static HudModule CPS = reg(
      new TextModule(
         "cps",
         "CPS Counter",
         "Info",
         "Clicks per second (left | right)",
         0.01F,
         0.09F,
         "CPS: 8 | 3",
         mc -> "CPS: " + Tracker.cpsLeft() + " | " + Tracker.cpsRight()
      )
   );
   public static HudModule PING = reg(new TextModule("ping", "Ping", "Info", "Server latency", 0.01F, 0.16F, "Ping: 24 ms", mc -> {
      int p = ping(mc);
      return p < 0 ? "Ping: --" : "Ping: " + p + " ms";
   }));
   public static HudModule COORDS = reg(
      new TextModule(
         "coords",
         "Coordinates",
         "Info",
         "XYZ position and biome",
         0.01F,
         0.23F,
         "XYZ: 128.4 64.0 -312.7\nBiome: Dark Forest",
         mc -> f("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()) + "\nBiome: " + biome(mc)
      )
   );
   public static HudModule DIRECTION = reg(
      new TextModule(
         "direction",
         "Direction",
         "Info",
         "Facing direction and yaw",
         0.01F,
         0.32F,
         "Facing: North (180)",
         mc -> "Facing: " + facing(mc.player.getYaw()) + " (" + Math.round(MathHelper.wrapDegrees(mc.player.getYaw())) + ")"
      )
   );
   public static HudModule CLOCK = reg(
      new TextModule(
         "clock", "Clock", "Info", "Real time clock", 0.01F, 0.39F, "12:00:00", mc -> LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
      )
   );
   public static HudModule MEMORY = reg(
      new TextModule(
         "memory",
         "FPS / RAM Info",
         "Info",
         "FPS and memory usage",
         0.01F,
         0.46F,
         "FPS: 240 | RAM: 1.4/4.0 GB",
         mc -> "FPS: " + mc.getCurrentFps() + " | RAM: " + Tracker.usedRam()
      )
   );
   public static HudModule SESSION = reg(
      new TextModule(
         "session",
         "Session Statistics",
         "Info",
         "Playtime, kills, hits, distance",
         0.01F,
         0.53F,
         "Session: 12m 03s\nKills: 3\nHits: 27\nBest combo: 8\nDistance: 1.2 km",
         mc -> "Session: "
            + Tracker.sessionTime()
            + "\nKills: "
            + Tracker.kills
            + "\nHits: "
            + Tracker.hits
            + "\nBest combo: "
            + Tracker.maxCombo
            + "\nDistance: "
            + f("%.2f km", Tracker.distance / 1000.0)
      )
   );
   public static HudModule PERF = reg(new Modules.PerfModule());
   public static HudModule KEYSTROKES = reg(new Modules.KeystrokesModule());
   public static HudModule TARGET = reg(new Modules.TargetModule());
   public static HudModule COMBO = reg(
      new TextModule("combo", "Combo Counter", "Combat", "Consecutive hits without being hit", 0.01F, 0.72F, "Combo: 7", mc -> "Combo: " + Tracker.combo)
   );
   public static HudModule KILLS = reg(
      new TextModule(
         "kills",
         "Kill Counter",
         "Combat",
         "Kills and current streak",
         0.01F,
         0.79F,
         "Kills: 3 | Streak: 2",
         mc -> "Kills: " + Tracker.kills + " | Streak: " + Tracker.streak
      )
   );
   public static HudModule REACH = reg(
      new TextModule(
         "reach",
         "Reach Display",
         "Combat",
         "Distance of your last attack",
         0.01F,
         0.86F,
         "Reach: 2.91",
         mc -> Tracker.lastReach <= 0.0 ? "Reach: --" : f("Reach: %.2f", Tracker.lastReach)
      )
   );
   public static HudModule DAMAGE = reg(new Modules.OverlayModule("damage", "Damage Indicator", "Combat", "Floating damage numbers near the crosshair") {
      @Override
      public void renderOverlay(DrawContext ctx, MinecraftClient mc) {
         long now = System.currentTimeMillis();
         int cx = mc.getWindow().getScaledWidth() / 2;
         int cy = mc.getWindow().getScaledHeight() / 2;
         int rgb = this.cfg().textColor == 16777215 ? 16733559 : this.cfg().textColor;

         for (Tracker.Floating fl : Tracker.FLOATS) {
            float age = (float)(now - fl.start) / 1200.0F;
            Gfx.text(ctx, fl.text, cx + 12, cy - 12 - (int)(age * 26.0F), Gfx.argb(rgb, 1.0F - age), true);
         }
      }
   });
   public static HudModule CROSSHAIR = reg(
      new Modules.OverlayModule("crosshair", "Crosshair Editor", "Combat", "Replace the vanilla crosshair with your custom one") {
         @Override
         public void renderOverlay(DrawContext ctx, MinecraftClient mc) {
            CrosshairRenderer.drawHud(ctx, mc);
         }
      }
   );
   public static HudModule ARMOR = reg(new Modules.ArmorModule());
   public static HudModule POTION = reg(new Modules.PotionModule());
   public static HudModule ITEMCOUNTER = reg(new Modules.ItemCounterModule());
   public static HudModule DURABILITY = reg(new Modules.DurabilityModule());
   public static HudModule TOGGLESPRINT = reg(
      new Modules.ToggleModule("togglesprint", "Toggle Sprint", "Press the sprint key once to keep sprinting", 0.13F, 0.02F, true)
   );
   public static HudModule TOGGLESNEAK = reg(
      new Modules.ToggleModule("togglesneak", "Toggle Sneak", "Press the sneak key once to keep sneaking", 0.13F, 0.09F, false)
   );
   public static HudModule NOTIFICATIONS = reg(new Modules.NotificationsModule());
   public static HudModule OPTIMIZE = reg(new Modules.OptimizeModule());
   public static HudModule AUTOSPRINT = reg(new Modules.AutoSprintModule());
   public static HudModule WAYPOINTS = null;
   public static HudModule SCOREBOARD = reg(
      new Modules.OverlayModule("scoreboard", "Custom Scoreboard", "Overlay", "Scale, move or hide the sidebar scoreboard").option("Hide scoreboard")
   );
   public static HudModule TABLIST = reg(new Modules.OverlayModule("tablist", "Custom Tablist", "Overlay", "Scale and move the player list"));
   public static HudModule CHAT = reg(
      new Modules.OverlayModule("chat", "Custom Chat", "Overlay", "Scale, move and timestamp the chat").option("Chat timestamps")
   );
   public static HudModule WATERMARK = reg(new Modules.WatermarkModule());
   public static HudModule HANDS = reg(new Modules.HandShaderModule());
   public static HudModule ASPECT = reg(new Modules.AspectModule());
   public static HudModule FULLBRIGHT = reg(new Modules.FullBrightModule());
   public static HudModule PARTICLES = reg(new Modules.ParticlesModule());
   public static HudModule CHATANIM = reg(new Modules.OverlayModule("chatanim", "Chat Animation", "Overlay", "Chat slides in smoothly when you open it"));
   public static HudModule TABANIM = reg(new Modules.OverlayModule("tabanim", "Tab Animation", "Overlay", "Player list pops in smoothly when you hold Tab"));
   public static HudModule CUSTOMSKY = reg(new Modules.CustomSkyModule());
   public static Modules.ArtiHelperModule ARTIHELPER = reg(new Modules.ArtiHelperModule());
   public static HudModule BLOCKOVERLAY = reg(new Modules.BlockOverlayModule());
   public static HudModule COOLDOWNS = reg(new Modules.CooldownsModule());
   public static HudModule TARGETESP = reg(new Modules.TargetEspModule());
   public static HudModule JUMPCIRCLES = reg(new Modules.JumpCirclesModule());
   public static HudModule INVENTORY = reg(new Modules.InventoryModule());
   public static HudModule CHINAHAT = reg(new Modules.ChinaHatModule());
   public static HudModule KILLFX = reg(new Modules.KillEffectModule());
   public static HudModule MOTIONBLUR = reg(new Modules.MotionBlurModule());
   public static HudModule FREELOOK = reg(new Modules.FreelookModule());
   public static HudModule ZOOM = reg(new Modules.ZoomModule());
   static final String[] DIRS = new String[]{"South", "South-West", "West", "North-West", "North", "North-East", "East", "South-East"};

   private Modules() {
   }

   public static boolean optimizing() {
      return OPTIMIZE != null && OPTIMIZE.cfg().enabled;
   }

   private static <T extends HudModule> T reg(T m) {
      ALL.add(m);
      return m;
   }

   private static void at(HudModule m, float x, float y) {
      m.defX = x;
      m.defY = y;
   }

   public static HudModule byId(String id) {
      for (HudModule m : ALL) {
         if (m.id.equals(id)) {
            return m;
         }
      }

      return null;
   }

   public static void set(HudModule m, boolean on) {
      ModuleSettings s = m.cfg();
      if (s.enabled != on) {
         s.enabled = on;
         DexConfig.markDirty();
         Notifications.push(I18n.modName(m), I18n.tr(on ? "Enabled" : "Disabled"), on ? 4652980 : 16731501);
      }
   }

   public static void toggle(HudModule m) {
      set(m, !m.cfg().enabled);
   }

   static String f(String fmt, Object... a) {
      return String.format(Locale.ROOT, fmt, a);
   }

   static int ping(MinecraftClient mc) {
      if (mc.getNetworkHandler() != null && mc.player != null) {
         PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         return e == null ? -1 : e.getLatency();
      } else {
         return -1;
      }
   }

   static String pretty(String s) {
      String[] p = s.split("_");
      StringBuilder b = new StringBuilder();

      for (String w : p) {
         if (!w.isEmpty()) {
            b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
         }
      }

      return b.toString().trim();
   }

   public static String biome(MinecraftClient mc) {
      return mc.world.getBiome(mc.player.getBlockPos()).getKey().map(k -> pretty(k.getValue().getPath())).orElse("Unknown");
   }

   public static String facing(float yaw) {
      float y = MathHelper.wrapDegrees(yaw);
      return DIRS[Math.floorMod(Math.round(y / 45.0F), 8)];
   }

   static int ratioColor(float r, int alphaSource) {
      int rgb = r > 0.5F ? 5635925 : (r > 0.25F ? 16777045 : 16733525);
      return alphaSource & 0xFF000000 | rgb;
   }

   static String roman(int n) {
      String[] r = new String[]{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
      return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
   }

   static {
      at(WATERMARK, 0.012F, 0.02F);
      at(PING, 0.012F, 0.12F);
      at(CPS, 0.012F, 0.19F);
      at(CLOCK, 0.012F, 0.26F);
      at(FPS, 0.012F, 0.33F);
      at(KEYSTROKES, 0.012F, 0.42F);
      at(SESSION, 0.012F, 0.68F);
      at(MEMORY, 0.2F, 0.12F);
      at(PERF, 0.2F, 0.19F);
      at(COORDS, 0.36F, 0.02F);
      at(DIRECTION, 0.4F, 0.115F);
      at(NOTIFICATIONS, 0.36F, 0.2F);
      at(POTION, 0.88F, 0.02F);
      at(ARMOR, 0.9F, 0.3F);
      at(TARGET, 0.37F, 0.63F);
      at(COMBO, 0.28F, 0.74F);
      at(KILLS, 0.44F, 0.74F);
      at(REACH, 0.62F, 0.74F);
      at(TOGGLESPRINT, 0.7F, 0.62F);
      at(TOGGLESNEAK, 0.7F, 0.68F);
      at(DURABILITY, 0.78F, 0.8F);
      at(ITEMCOUNTER, 0.78F, 0.88F);
      at(COOLDOWNS, 0.7F, 0.51F);
   }

   static class ArmorModule extends HudModule {
      static final EquipmentSlot[] SLOTS = new EquipmentSlot[]{EquipmentSlot.field_6169, EquipmentSlot.field_6174, EquipmentSlot.field_6172, EquipmentSlot.field_6166};

      ArmorModule() {
         super("armor", "Armor Status", "Gear", "Equipped armor with durability", 0.9F, 0.45F, true, false);
         this.noContainer();
      }

      List<ItemStack> stacks(MinecraftClient mc, boolean preview) {
         List<ItemStack> l = new ArrayList<>();
         if (mc.player != null) {
            for (EquipmentSlot s : SLOTS) {
               ItemStack st = mc.player.getEquippedStack(s);
               if (!st.isEmpty()) {
                  l.add(st);
               }
            }
         }

         if (l.isEmpty() && preview) {
            l.add(new ItemStack(Items.field_8805));
            l.add(new ItemStack(Items.field_8058));
            l.add(new ItemStack(Items.field_8348));
            l.add(new ItemStack(Items.field_8285));

            for (ItemStack sx : l) {
               sx.setDamage(14);
            }
         }

         return l;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.stacks(mc, p).isEmpty() ? 0 : 100;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         int n = this.stacks(mc, p).size();
         return n == 0 ? 0 : CardUi.rows(n);
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         float al = (color >>> 24 & 0xFF) / 255.0F;
         List<ItemStack> l = this.stacks(mc, preview);
         int w = 100;
         CardUi.panel(c, w, CardUi.rows(l.size()), al);
         CardUi.header(c, w, new ItemStack(Items.field_8523), "Armor", String.valueOf(l.size()), al);
         int i = 0;

         for (ItemStack s : l) {
            int y = 20 + i++ * 19;
            if (s.isDamageable()) {
               int left = s.getMaxDamage() - s.getDamage();
               float r = (float)left / s.getMaxDamage();
               int rgb = Modules.ratioColor(r, 0) & 16777215;
               CardUi.row(c, w, y, s, "", left + "/" + s.getMaxDamage(), rgb, r, rgb, al, this.cfg().shadow);
            } else {
               CardUi.row(c, w, y, s, "", null, 16777215, -1.0F, 0, al, this.cfg().shadow);
            }
         }
      }
   }

   public static class ArtiHelperModule extends Modules.OverlayModule {
      public static final List<Modules.ArtiHelperModule.Timer> TIMERS = new CopyOnWriteArrayList<>();
      private static long lastUse;

      ArtiHelperModule() {
         super("artihelper", "Arti Helper", "Overlay", "Shows the area of a Trap / Plast item while you hold it, and a countdown timer after you use it", true);
         this.optionLabel = "Show the timer floating over the area";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 15.0F;
         s.val2 = 20.0F;
         s.val3 = 3.0F;
         s.val4 = 3.0F;
         s.textColor = 16777215;
         s.borderColor = 4184319;
         s.option = true;
         return s;
      }

      public static int kindOf(ItemStack st) {
         if (st != null && !st.isEmpty() && st.get(DataComponentTypes.field_49631) != null) {
            String n = st.getName().getString().toLowerCase(Locale.ROOT);
            if (n.contains("trapdoor") || n.contains("trapped")) {
               return -1;
            } else if (n.contains("\u00c3\u2018\u00e2\u20ac\u0161\u00c3\u2018\u00e2\u201a\u00ac\u00c3\u0090\u00c2\u00b0\u00c3\u0090\u00c2\u00bf")
               || n.contains("trap")) {
               return 0;
            } else {
               return !n.contains(
                        "\u00c3\u0090\u00c2\u00bf\u00c3\u0090\u00c2\u00bb\u00c3\u0090\u00c2\u00b0\u00c3\u2018\u00c2\u0081\u00c3\u2018\u00e2\u20ac\u0161"
                     )
                     && !n.contains("plast")
                  ? -1
                  : 1;
            }
         } else {
            return -1;
         }
      }

      public static int heldKind(PlayerEntity p) {
         int k = kindOf(p.getMainHandStack());
         return k >= 0 ? k : kindOf(p.getOffHandStack());
      }

      public static Box areaFor(int kind, PlayerEntity p, ModuleSettings s) {
         double bx = Math.floor(p.getX()) + 0.5;
         double by = Math.floor(p.getY());
         double bz = Math.floor(p.getZ()) + 0.5;
         if (kind == 0) {
            double n = Math.max(1.0F, s.val3);
            double hx = n / 2.0;
            return new Box(bx - hx, by, bz - hx, bx + hx, by + n, bz + hx);
         } else {
            double w = Math.max(1.0F, s.val4);
            double hw = w / 2.0;
            float pitch = p.getPitch();
            if (pitch > 60.0F) {
               return new Box(bx - hw, by - 1.0, bz - hw, bx + hw, by, bz + hw);
            } else if (pitch < -60.0F) {
               return new Box(bx - hw, by + 2.0, bz - hw, bx + hw, by + 3.0, bz + hw);
            } else {
               Direction d = p.getHorizontalFacing();
               double cx = bx + d.getOffsetX() * 2;
               double cz = bz + d.getOffsetZ() * 2;
               double cy = by + 1.0;
               return d.getAxis() == Axis.field_11048
                  ? new Box(cx - 0.5, cy - hw, cz - hw, cx + 0.5, cy + hw, cz + hw)
                  : new Box(cx - hw, cy - hw, cz - 0.5, cx + hw, cy + hw, cz + 0.5);
            }
         }
      }

      public void onUse(PlayerEntity p, Hand hand) {
         if (this.cfg().enabled && p != null) {
            ItemStack st = p.getStackInHand(hand);
            int kind = kindOf(st);
            if (kind >= 0) {
               if (!p.getItemCooldownManager().isCoolingDown(st)) {
                  long now = System.currentTimeMillis();
                  if (now - lastUse >= 350L) {
                     lastUse = now;
                     ModuleSettings s = this.cfg();
                     float secs = Math.max(1.0F, kind == 0 ? s.val : s.val2);
                     TIMERS.removeIf(t -> t.kind == kind);
                     TIMERS.add(new Modules.ArtiHelperModule.Timer(kind, areaFor(kind, p, s), now, now + (long)(secs * 1000.0F)));
                  }
               }
            }
         }
      }

      @Override
      public void tick(MinecraftClient mc) {
         if (!TIMERS.isEmpty()) {
            long now = System.currentTimeMillis();
            TIMERS.removeIf(t -> now > t.end + 300L);
         }
      }

      public static boolean worldActive(MinecraftClient mc) {
         return !TIMERS.isEmpty() || mc.player != null && heldKind(mc.player) >= 0;
      }

      @Override
      public void renderOverlay(DrawContext c, MinecraftClient mc) {
         if (mc.player != null && mc.world != null && !TIMERS.isEmpty() && !mc.options.hudHidden) {
            long now = System.currentTimeMillis();
            ModuleSettings s = this.cfg();
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int row = 0;

            for (Modules.ArtiHelperModule.Timer t : TIMERS) {
               float left = (float)(t.end - now) / 1000.0F;
               if (!(left < 0.0F)) {
                  int rgb = (t.kind == 0 ? s.textColor : s.borderColor) & 16777215;
                  if (left < 3.0F) {
                     rgb = 16731501;
                  }

                  String a = (t.kind == 0 ? "Trapka" : "Plast") + " tugashiga: ";
                  String b = Modules.f("%.1f", left) + " sek";
                  int x = (sw - (Gfx.tw(a) + Gfx.tw(b))) / 2;
                  int y = sh - 62 - row * 12;
                  Gfx.text(c, a, x, y, -1, true);
                  Gfx.text(c, b, x + Gfx.tw(a), y, 0xFF000000 | rgb, true);
                  row++;
                  if (s.option) {
                     Vec3d top = new Vec3d(
                        (t.box.minX + t.box.maxX) / 2.0, t.box.maxY + 0.25, (t.box.minZ + t.box.maxZ) / 2.0
                     );
                     int[] p = Projector.project(top);
                     if (p != null) {
                        String lab = Modules.f("%.1fs", left);
                        int lw = Gfx.tw(lab) + 10;
                        Gfx.rrect(c, p[0] - lw / 2, p[1] - 7, lw, 13, 6, Gfx.argb(592402, 0.8F), Gfx.argb(1183522, 0.7F));
                        Gfx.rborder(c, p[0] - lw / 2, p[1] - 7, lw, 13, 6, 1, Gfx.argb(rgb, 0.7F));
                        Gfx.textC(c, lab, p[0], p[1] - 4, 0xFF000000 | rgb, false);
                     }
                  }
               }
            }
         }
      }

      public static final class Timer {
         public final int kind;
         public final Box box;
         public final long start;
         public final long end;

         Timer(int kind, Box box, long start, long end) {
            this.kind = kind;
            this.box = box;
            this.start = start;
            this.end = end;
         }
      }
   }

   public static class AspectModule extends Modules.OverlayModule {
      AspectModule() {
         super("aspect", "Aspect Ratio", "Overlay", "Stretch the game view horizontally (e.g. 4:3 stretched)");
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 1.33F;
         return s;
      }
   }

   public static class AutoSprintModule extends Modules.OverlayModule {
      private boolean applied;

      AutoSprintModule() {
         super("autosprint", "Auto Sprint", "Utility", "Sprint automatically while you hold forward (no sprint key needed)");
      }

      @Override
      public void tick(MinecraftClient mc) {
         if (mc.options != null) {
            ClientPlayerEntity p = mc.player;
            boolean can = this.cfg().enabled
               && p != null
               && mc.currentScreen == null
               && mc.options.forwardKey.isPressed()
               && !p.isSneaking()
               && !p.hasStatusEffect(StatusEffects.field_5919)
               && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying);
            if (can) {
               mc.options.sprintKey.setPressed(true);
               this.applied = true;
            } else if (this.applied) {
               mc.options.sprintKey.setPressed(false);
               this.applied = false;
            }
         }
      }
   }

   public static class BlockOverlayModule extends Modules.OverlayModule {
      BlockOverlayModule() {
         super("blockoverlay", "Block Overlay", "Overlay", "Colored fill + outline on the block you look at", true);
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 0.25F;
         return s;
      }
   }

   public static class ChinaHatModule extends Modules.OverlayModule {
      ChinaHatModule() {
         super("chinahat", "China Hat", "Overlay", "Glowing cone hat above your head (visible in third person)");
         this.optionLabel = "Also show on other players";
         this.optionLabel2 = "Use own color (ignore theme)";
      }
   }

   public static class CooldownsModule extends HudModule {
      private final Map<Item, Modules.CooldownsModule.Track> tracks = new HashMap<>();

      CooldownsModule() {
         super("cooldowns", "Cooldowns", "Combat", "Item cooldowns (pearl, gapple, chorus...) with timers", 0.7F, 0.51F, true, true);
         this.noContainer();
      }

      private List<Modules.CooldownsModule.Row> rows(MinecraftClient mc, boolean preview) {
         List<Modules.CooldownsModule.Row> rows = new ArrayList<>();
         if (mc.player != null) {
            ItemCooldownManager cd = mc.player.getItemCooldownManager();
            PlayerInventory inv = mc.player.getInventory();
            Set<Item> seen = new HashSet<>();
            long now = System.currentTimeMillis();

            for (int i = 0; i < inv.size(); i++) {
               ItemStack s = inv.getStack(i);
               if (!s.isEmpty() && seen.add(s.getItem())) {
                  if (!cd.isCoolingDown(s)) {
                     this.tracks.remove(s.getItem());
                  } else {
                     float p = cd.getCooldownProgress(s, 0.0F);
                     Modules.CooldownsModule.Track t = this.tracks.get(s.getItem());
                     if (t == null) {
                        t = new Modules.CooldownsModule.Track();
                        t.p0 = p;
                        t.t0 = now;
                        this.tracks.put(s.getItem(), t);
                     }

                     long dt = now - t.t0;
                     float secs = -1.0F;
                     if (dt > 150L && t.p0 - p > 0.01F) {
                        secs = p / ((t.p0 - p) / (float)dt) / 1000.0F;
                     }

                     rows.add(new Modules.CooldownsModule.Row(s, p, secs));
                  }
               }
            }
         }

         if (rows.isEmpty() && preview) {
            rows.add(new Modules.CooldownsModule.Row(new ItemStack(Items.field_8634), 0.62F, 1.2F));
            rows.add(new Modules.CooldownsModule.Row(new ItemStack(Items.field_8367), 0.35F, 4.8F));
         }

         return rows;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.rows(mc, p).isEmpty() ? 0 : 150;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         int n = this.rows(mc, p).size();
         return n == 0 ? 0 : CardUi.rows(n);
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         float al = (color >>> 24 & 0xFF) / 255.0F;
         List<Modules.CooldownsModule.Row> l = this.rows(mc, preview);
         int w = 150;
         int a1 = Theme.rgb(Theme.a1());
         CardUi.panel(c, w, CardUi.rows(l.size()), al);
         CardUi.header(c, w, new ItemStack(Items.field_8557), "Cooldowns", String.valueOf(l.size()), al);
         int i = 0;

         for (Modules.CooldownsModule.Row r : l) {
            CardUi.row(
               c,
               w,
               20 + i++ * 19,
               r.stack(),
               r.stack().getName().getString(),
               r.secs() < 0.0F ? ".." : Modules.f("%.1fs", r.secs()),
               16777215,
               r.prog(),
               a1,
               al,
               this.cfg().shadow
            );
         }
      }

      private record Row(ItemStack stack, float prog, float secs) {
      }

      private static class Track {
         float p0;
         long t0;

         private Track() {
         }
      }
   }

   public static class CustomSkyModule extends Modules.OverlayModule {
      CustomSkyModule() {
         super("customsky", "Custom Sky", "Visual", "Realistic beautiful skybox with soft rotating clouds");
         this.optionLabel = "Keep vanilla sun & moon";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 1.0F;
         s.scale = 1.0F;
         s.val2 = 1.0F;
         s.option = false;
         return s;
      }
   }

   static class DurabilityModule extends HudModule {
      DurabilityModule() {
         super("durability", "Durability", "Gear", "Durability of the item in your hand", 0.78F, 0.8F, true, false);
         this.noContainer();
      }

      ItemStack held(MinecraftClient mc, boolean preview) {
         ItemStack h = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandStack();
         if ((h.isEmpty() || !h.isDamageable()) && preview) {
            h = new ItemStack(Items.field_8802);
            h.setDamage(300);
         }

         return h;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         ItemStack h = this.held(mc, p);
         return !h.isEmpty() && h.isDamageable() ? 140 : 0;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         ItemStack h = this.held(mc, p);
         return !h.isEmpty() && h.isDamageable() ? CardUi.single() : 0;
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         ItemStack h = this.held(mc, preview);
         if (!h.isEmpty() && h.isDamageable()) {
            float al = (color >>> 24 & 0xFF) / 255.0F;
            int left = h.getMaxDamage() - h.getDamage();
            float r = (float)left / h.getMaxDamage();
            int rgb = Modules.ratioColor(r, 0) & 16777215;
            CardUi.panel(c, 140, CardUi.single(), al);
            CardUi.row(c, 140, 6, h, h.getName().getString(), left + "/" + h.getMaxDamage(), rgb, r, rgb, al, this.cfg().shadow);
         }
      }
   }

   public static class FreelookModule extends Modules.OverlayModule {
      FreelookModule() {
         super("freelook", "Freelook", "Overlay", "Hold the key to look around your character in third person without turning it");
         this.optionLabel = "Toggle mode (press once to start / stop)";
      }
   }

   public static class FullBrightModule extends Modules.OverlayModule {
      FullBrightModule() {
         super("fullbright", "Full Bright", "Overlay", "See clearly in the dark (client-side night vision)");
      }

      @Override
      public void tick(MinecraftClient mc) {
         if (mc.player != null) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.field_5925);
            if (this.cfg().enabled) {
               if (cur == null || cur.getDuration() < 2000) {
                  mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.field_5925, 100000, 0, false, false, false));
               }
            } else if (cur != null && cur.getDuration() > 50000) {
               mc.player.removeStatusEffect(StatusEffects.field_5925);
            }
         }
      }
   }

   public static class HandShaderModule extends Modules.OverlayModule {
      private Item lastMain;
      private Item lastOff;
      private long equipMain;
      private long equipOff;

      HandShaderModule() {
         super("hands", "Hand Shader", "Overlay", "Skin-colored hands with a glowing neon outline + a glowing light (rays, sparkles) around whatever you hold");
         this.optionLabel = "Disable rays";
         this.optionLabel2 = "Disable sparkles";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 1.0F;
         s.option = false;
         s.option2 = false;
         return s;
      }

      @Override
      public void renderOverlay(DrawContext c, MinecraftClient mc) {
         ModuleSettings s = this.cfg();
         if (!Modules.optimizing() && mc.player != null && mc.world != null && mc.currentScreen == null && !mc.player.isSpectator()) {
            if (mc.options.getPerspective().isFirstPerson()) {
               long now = System.currentTimeMillis();
               Item main = mc.player.getMainHandStack().getItem();
               Item off = mc.player.getOffHandStack().getItem();
               if (main != this.lastMain) {
                  this.lastMain = main;
                  this.equipMain = now;
               }

               if (off != this.lastOff) {
                  this.lastOff = off;
                  this.equipOff = now;
               }

               int sw = mc.getWindow().getScaledWidth();
               int sh = mc.getWindow().getScaledHeight();
               boolean right = mc.options.getMainArm().getValue() == Arm.field_6183;
               float swing = Math.min(1.0F, mc.player.getHandSwingProgress(mc.getRenderTickCounter().getTickDelta(false)));
               float flash = (float)Math.sin(swing * Math.PI);
               float t = (float)now / 1000.0F * Math.max(0.2F, s.scale);
               float str = Math.max(0.2F, Math.min(2.0F, s.val <= 0.01F ? 1.0F : s.val));
               float bMain = Math.max(0.0F, 1.0F - (float)(now - this.equipMain) / 700.0F);
               float bOff = Math.max(0.0F, 1.0F - (float)(now - this.equipOff) / 700.0F);
               boolean offSwing = mc.player.preferredHand == Hand.field_5810;
               light(c, sw, sh, right, str, t, bMain * bMain, offSwing ? 0.0F : flash, mc.player.isUsingItem() && !offSwing, 0.0F, s.option, s.option2);
               if (!mc.player.getOffHandStack().isEmpty()) {
                  light(
                     c, sw, sh, !right, str * 0.8F, t, bOff * bOff, offSwing ? flash : 0.0F, mc.player.isUsingItem() && offSwing, 1.7F, s.option, s.option2
                  );
               }
            }
         }
      }

      private static void light(
         DrawContext c,
         int sw,
         int sh,
         boolean right,
         float str,
         float t,
         float boost,
         float flash,
         boolean using,
         float seed,
         boolean noRays,
         boolean noSparkles
      ) {
         int cx = Math.round(sw * (right ? 0.78F : 0.22F) - (right ? 1 : -1) * flash * sw * 0.03F);
         int cy = Math.round(sh * 0.89F + flash * sh * 0.03F);
         float R = sh * 0.33F;
         int th = HandShader.glowColor();
         int th2 = Gfx.lerp(0xFF000000 | th, -1, 0.45F) & 16777215;
         float pulse = 0.85F + 0.15F * (float)Math.sin(t * 2.4F + seed);
         float inten = Math.min(2.0F, (pulse + boost * 0.6F + flash * 0.5F + (using ? 0.35F : 0.0F)) * str);
         if (!noRays) {
            for (int i = 0; i < 7; i++) {
               double a = Math.toRadians((i - 3) * 14.0 + Math.sin(t * 0.8F + i + seed) * 6.0);
               float len = R * (0.7F + 0.5F * (float)Math.sin(t * 1.3F + i * 1.7F + seed)) * (0.8F + 0.4F * Math.min(1.5F, inten));
               int x0 = cx + (int)Math.round(Math.sin(a) * R * 0.1);
               int y0 = cy - (int)Math.round(Math.cos(a) * R * 0.1);
               int x1 = cx + (int)Math.round(Math.sin(a) * len);
               int y1 = cy - (int)Math.round(Math.cos(a) * len);
               Gfx.line(c, x0, y0, x1, y1, 3, Gfx.argb(th2, Math.min(0.35F, 0.12F * inten)));
               Gfx.line(c, x0, y0, x1, y1, 1, Gfx.argb(16777215, Math.min(0.6F, 0.25F * inten)));
            }
         }

         if (!noSparkles) {
            for (int i = 0; i < 10; i++) {
               float u = (t * 0.35F + i * 0.1F + seed) % 1.0F;
               int px = cx + Math.round((float)Math.sin(i * 2.7F + t * 1.4F) * R * 0.55F * (0.4F + u));
               int py = cy - Math.round(u * R * 1.1F);
               float al = (float)Math.sin(u * Math.PI) * Math.min(1.0F, 0.8F * inten);
               int col = Gfx.ga(Gfx.argb(i % 2 == 0 ? 16777215 : th2, al));
               c.fill(px, py, px + 2, py + 2, col);
               if (i % 3 == 0) {
                  c.fill(px - 1, py, px + 3, py + 2, col);
                  c.fill(px, py - 1, px + 2, py + 3, col);
               }
            }
         }
      }
   }

   public static class InventoryModule extends HudModule {
      InventoryModule() {
         super("inventory", "Inventory", "Gear", "Your inventory as a compact grid on the HUD", 0.3F, 0.35F, true, false);
         this.noContainer();
         this.optionLabel = "Include hotbar row";
      }

      private int rowsN() {
         return this.cfg().option ? 4 : 3;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return 172;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return 20 + this.rowsN() * 18 + 6 - 1;
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         float al = (color >>> 24 & 0xFF) / 255.0F;
         int w = this.width(mc, preview);
         int h = this.height(mc, preview);
         CardUi.panel(c, w, h, al);
         CardUi.header(c, w, new ItemStack(Items.CHEST), "Inventory", null, al);
         int rows = this.rowsN();

         for (int r = 0; r < rows; r++) {
            for (int col = 0; col < 9; col++) {
               int x = 6 + col * 18;
               int y = 20 + r * 18;
               Gfx.rrect(c, x, y, 16, 16, 3, Gfx.argb(0, 0.38F * al));
               Gfx.rborder(c, x, y, 16, 16, 3, 1, Gfx.argb(16777215, 0.05F * al));
               ItemStack st = ItemStack.EMPTY;
               if (mc.player != null) {
                  int idx = r == 3 ? col : 9 + r * 9 + col;
                  st = mc.player.getInventory().getStack(idx);
               } else if (preview && r == 0 && col < 4) {
                  st = new ItemStack(new Item[]{Items.field_8634, Items.field_8463, Items.field_8288, Items.field_8802}[col]);
               }

               if (!st.isEmpty()) {
                  c.drawItem(st, x, y);
                  c.drawStackOverlay(mc.textRenderer, st, x, y);
               }
            }
         }
      }
   }

   static class ItemCounterModule extends HudModule {
      ItemCounterModule() {
         super("itemcounter", "Item Counter", "Gear", "Total amount of the item in your hand", 0.78F, 0.88F, true, false);
         this.noContainer();
      }

      ItemStack held(MinecraftClient mc, boolean preview) {
         ItemStack h = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandStack();
         return h.isEmpty() && preview ? new ItemStack(Items.field_8463) : h;
      }

      int count(MinecraftClient mc, ItemStack held) {
         if (mc.player == null) {
            return 12;
         } else {
            PlayerInventory inv = mc.player.getInventory();
            int n = 0;

            for (int i = 0; i < inv.size(); i++) {
               ItemStack s = inv.getStack(i);
               if (s.isOf(held.getItem())) {
                  n += s.getCount();
               }
            }

            return Math.max(n, mc.player.getMainHandStack().isEmpty() ? 12 : n);
         }
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.held(mc, p).isEmpty() ? 0 : 124;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return this.held(mc, p).isEmpty() ? 0 : CardUi.single();
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         ItemStack h = this.held(mc, preview);
         if (!h.isEmpty()) {
            float al = (color >>> 24 & 0xFF) / 255.0F;
            CardUi.panel(c, 124, CardUi.single(), al);
            CardUi.row(c, 124, 6, h, h.getName().getString(), "x" + this.count(mc, h), 16777215, -1.0F, 0, al, this.cfg().shadow);
         }
      }
   }

   public static class JumpCirclesModule extends Modules.OverlayModule {
      public static final List<Modules.JumpCirclesModule.Circle> CIRCLES = new ArrayList<>();
      private final Map<Integer, Boolean> ground = new HashMap<>();
      private final Map<Integer, Double> lastY = new HashMap<>();
      private final Map<Integer, Long> lastSpawn = new HashMap<>();

      JumpCirclesModule() {
         super("jumpcircles", "Jump Circles", "Overlay", "Glowing ring that expands on the ground where you jump", true);
         this.optionLabel2 = "Use own color (ignore theme)";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.scale = 1.0F;
         s.val2 = 1.0F;
         s.textColor = 10513663;
         return s;
      }

      @Override
      public void tick(MinecraftClient mc) {
         long now = System.currentTimeMillis();
         CIRCLES.removeIf(c -> now - c.start() > c.life());
         if (this.cfg().enabled && mc.world != null && mc.player != null) {
            if (this.ground.size() > 300) {
               this.ground.clear();
               this.lastY.clear();
               this.lastSpawn.clear();
            }

            for (ClientPlayerEntity p : List.of(mc.player)) {
               int id = p.getId();
               boolean g = p.isOnGround();
               Boolean prev = this.ground.put(id, g);
               Double py = this.lastY.put(id, p.getY());
               if (prev != null && prev && !g && (p.getVelocity().y > 0.1 || py != null && p.getY() - py > 0.03)) {
                  Long ls = this.lastSpawn.get(id);
                  if ((ls == null || now - ls > 450L) && CIRCLES.size() < 16) {
                     this.lastSpawn.put(id, now);
                     CIRCLES.add(
                        new Modules.JumpCirclesModule.Circle(
                           p.getX(), p.getY(), p.getZ(), now, (long)(950.0F / Math.max(0.3F, this.cfg().val2))
                        )
                     );
                  }
               }
            }
         } else {
            this.ground.clear();
            this.lastY.clear();
         }
      }

      public record Circle(double x, double y, double z, long start, long life) {
      }
   }

   static class KeystrokesModule extends HudModule {
      KeystrokesModule() {
         super("keystrokes", "Keystrokes", "Combat", "WASD, mouse buttons (with CPS) and space bar", 0.13F, 0.58F, true, false);
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return 60;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return 78;
      }

      void key(DrawContext c, int x, int y, int w, int h, String label, boolean down, int color, String sub) {
         int a = color >>> 24 & 0xFF;
         int rgb = DexConfig.get().themeSync && !this.cfg().ownColor ? Theme.rgb(Theme.a1()) : color & 16777215;
         Gfx.rrect(c, x, y, w, h, 3, down ? Gfx.argb(rgb, a / 255.0F * 0.8F) : Gfx.argb(0, a / 255.0F * 0.45F));
         Gfx.rborder(c, x, y, w, h, 3, 1, Gfx.argb(16777215, a / 255.0F * 0.18F));
         int tc = down ? color & 0xFF000000 | 724244 : color;
         if (sub == null) {
            Gfx.textC(c, label, x + w / 2, y + (h - 8) / 2, tc, false);
         } else {
            Gfx.textC(c, label, x + w / 2, y + 3, tc, false);
            Gfx.textC(c, sub, x + w / 2, y + 13, tc, false);
         }
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         GameOptions o = mc.options;
         this.key(c, 20, 0, 18, 18, "W", o.forwardKey.isPressed(), color, null);
         this.key(c, 0, 20, 18, 18, "A", o.leftKey.isPressed(), color, null);
         this.key(c, 20, 20, 18, 18, "S", o.backKey.isPressed(), color, null);
         this.key(c, 40, 20, 18, 18, "D", o.rightKey.isPressed(), color, null);
         this.key(c, 0, 40, 29, 24, "LMB", Tracker.leftHeld, color, String.valueOf(Tracker.cpsLeft()));
         this.key(c, 31, 40, 29, 24, "RMB", Tracker.rightHeld, color, String.valueOf(Tracker.cpsRight()));
         this.key(c, 0, 66, 60, 10, "", o.jumpKey.isPressed(), color, null);
         int al = color >>> 24 & 0xFF;
         c.fill(22, 70, 38, 72, Gfx.ga(Gfx.argb(16777215, al / 255.0F * 0.6F)));
      }
   }

   public static class KillEffectModule extends Modules.OverlayModule {
      KillEffectModule() {
         super("killeffect", "Kill Effect", "Overlay", "Cinematic burst of light where you eliminate a player: bloom, shockwave, lightning or soul rise", true);
         this.optionLabel = "Mute kill sound";
         this.optionLabel2 = "Use own color (ignore theme)";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 0.0F;
         s.val2 = 1.0F;
         s.val3 = 0.8F;
         s.scale = 1.0F;
         s.textColor = 7143348;
         return s;
      }

      @Override
      public void tick(MinecraftClient mc) {
         KillFx.tick(mc);
      }

      @Override
      public void renderOverlay(DrawContext ctx, MinecraftClient mc) {
         KillFx.hud(ctx, mc);
      }
   }

   public static class MotionBlurModule extends Modules.OverlayModule {
      MotionBlurModule() {
         super("motionblur", "Motion Blur", "Overlay", "Smooth 120 Hz look: the picture leaves a soft trail, strongest when you turn fast");
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 0.7F;
         s.scale = 1.0F;
         return s;
      }
   }

   static class NotificationsModule extends HudModule {
      NotificationsModule() {
         super("notifications", "Notifications", "Utility", "Toast notifications for toggles, kills and profiles", 0.74F, 0.02F, true, false);
         this.noContainer();
      }

      List<Notifications.Note> notes(boolean preview) {
         List<Notifications.Note> l = new ArrayList<>(Notifications.NOTES);
         if (l.isEmpty() && preview) {
            long n = System.currentTimeMillis();
            l.add(new Notifications.Note("DEX VISUAL", "Profile loaded: PvP", n, 10513663));
            l.add(new Notifications.Note("Kill", I18n.tr("You eliminated ") + "Steve", n, 16731501));
         }

         return l;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.notes(p).isEmpty() ? 0 : 140;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         int n = this.notes(p).size();
         return n == 0 ? 0 : n * 27 - 3;
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         long now = System.currentTimeMillis();
         long life = DexConfig.get().notifSeconds * 1000L;
         float base = (color >>> 24 & 0xFF) / 255.0F;
         int i = 0;
         List<Notifications.Note> l = this.notes(preview);

         for (int k = l.size() - 1; k >= 0; k--) {
            Notifications.Note n = l.get(k);
            long age = now - n.time();
            float fade = preview ? 1.0F : MathHelper.clamp(Math.min((float)age / 250.0F, (float)(life - age) / 400.0F), 0.0F, 1.0F);
            int y = i++ * 27;
            int sx = preview ? 0 : Math.round((1.0F - Gfx.ease((float)age / 280.0F)) * 28.0F);
            c.getMatrices().push();
            c.getMatrices().translate(sx, 0.0F, 0.0F);
            Gfx.glow(c, 0, y, 140, 24, 5, n.color(), base * fade * 0.6F);
            Gfx.rrect(c, 0, y, 140, 24, 5, Gfx.argb(724244, 0.85F * base * fade));
            Gfx.rrect(c, 0, y + 2, 3, 20, 1, Gfx.argb(n.color(), base * fade));
            Gfx.text(c, I18n.tr(n.title()), 9, y + 3, Gfx.argb(16777215, base * fade), false);
            Gfx.text(c, I18n.tr(n.message()), 9, y + 13, Gfx.argb(10133688, base * fade), false);
            c.getMatrices().pop();
         }
      }
   }

   public static class OptimizeModule extends Modules.OverlayModule {
      OptimizeModule() {
         super(
            "optimize",
            "Optimization",
            "Utility",
            "FPS boost: render distance 8 chunks, hides underground chunks, animations off and lighter graphics (everything is restored when you turn it off)"
         );
         this.optionLabel = "Keep underground visible (don't hide)";
         this.optionLabel2 = "Keep my render distance (don't set 8)";
      }

      @Override
      public void tick(MinecraftClient mc) {
         if (mc.options != null) {
            DexConfig d = DexConfig.get();
            boolean on = this.cfg().enabled;
            if (on && d.optBackup == null) {
               d.optBackup = new HashMap<>();
               apply(mc, d.optBackup, this.cfg().option2);
               DexConfig.markDirty();
               mc.options.write();
               Notifications.push("Optimization", "ON: 8 chunks, underground hidden, FPS boost", 4652980);
            } else if (!on && d.optBackup != null) {
               restore(mc, d.optBackup);
               d.optBackup = null;
               DexConfig.markDirty();
               mc.options.write();
               Notifications.push("Optimization", "OFF: settings restored", 16762967);
            }
         }
      }

      private static <T> void put(Map<String, String> b, String k, SimpleOption<T> o, T v) {
         T old = (T)o.getValue();
         b.put(k, old instanceof Enum<?> e ? e.name() : String.valueOf(old));
         o.setValue(v);
      }

      private static <T> void back(Map<String, String> b, String k, SimpleOption<T> o, Function<String, T> f) {
         String v = b.get(k);
         if (v != null) {
            try {
               o.setValue(f.apply(v));
            } catch (Exception var6) {
            }
         }
      }

      private static <E extends Enum<E>> void putEnum(Map<String, String> b, String k, SimpleOption<E> o, String name) {
         put(b, k, o, Enum.valueOf(((Enum)o.getValue()).getDeclaringClass(), name));
      }

      private static <E extends Enum<E>> void backEnum(Map<String, String> b, String k, SimpleOption<E> o) {
         String v = b.get(k);
         if (v != null) {
            try {
               o.setValue(Enum.valueOf(((Enum)o.getValue()).getDeclaringClass(), v));
            } catch (Exception var5) {
            }
         }
      }

      private static void apply(MinecraftClient mc, Map<String, String> b, boolean keepDist) {
         GameOptions o = mc.options;
         putEnum(b, "particles", o.getParticles(), "MINIMAL");
         put(b, "bob", o.getBobView(), false);
         put(b, "tilt", o.getDamageTiltStrength(), 0.0);
         put(b, "fovfx", o.getFovEffectScale(), 0.0);
         put(b, "distort", o.getDistortionEffectScale(), 0.0);
         put(b, "dark", o.getDarknessEffectScale(), 0.0);
         put(b, "shadows", o.getEntityShadows(), false);
         put(b, "clouds", o.getCloudRenderMode(), CloudRenderMode.field_18162);
         put(b, "gfx", o.getGraphicsMode(), GraphicsMode.field_25427);
         put(b, "ao", o.getAo(), false);
         put(b, "blend", o.getBiomeBlendRadius(), 0);
         put(b, "edist", o.getEntityDistanceScaling(), 0.5);
         put(b, "vsync", o.getEnableVsync(), false);
         put(b, "maxfps", o.getMaxFps(), 260);
         if (!keepDist) {
            put(b, "vd", o.getViewDistance(), 8);
            put(b, "sd", o.getSimulationDistance(), Math.min((Integer)o.getSimulationDistance().getValue(), 8));
         }
      }

      private static void restore(MinecraftClient mc, Map<String, String> b) {
         GameOptions o = mc.options;
         backEnum(b, "particles", o.getParticles());
         back(b, "bob", o.getBobView(), Boolean::parseBoolean);
         back(b, "tilt", o.getDamageTiltStrength(), Double::parseDouble);
         back(b, "fovfx", o.getFovEffectScale(), Double::parseDouble);
         back(b, "distort", o.getDistortionEffectScale(), Double::parseDouble);
         back(b, "dark", o.getDarknessEffectScale(), Double::parseDouble);
         back(b, "shadows", o.getEntityShadows(), Boolean::parseBoolean);
         back(b, "clouds", o.getCloudRenderMode(), CloudRenderMode::valueOf);
         back(b, "gfx", o.getGraphicsMode(), GraphicsMode::valueOf);
         back(b, "ao", o.getAo(), Boolean::parseBoolean);
         back(b, "blend", o.getBiomeBlendRadius(), Integer::parseInt);
         back(b, "edist", o.getEntityDistanceScaling(), Double::parseDouble);
         back(b, "vsync", o.getEnableVsync(), Boolean::parseBoolean);
         back(b, "maxfps", o.getMaxFps(), Integer::parseInt);
         back(b, "vd", o.getViewDistance(), Integer::parseInt);
         back(b, "sd", o.getSimulationDistance(), Integer::parseInt);
      }
   }

   public static class OverlayModule extends HudModule {
      public OverlayModule(String id, String name, String cat, String desc) {
         super(id, name, cat, desc, 0.0F, 0.0F, false, false);
      }

      public OverlayModule(String id, String name, String cat, String desc, boolean on) {
         super(id, name, cat, desc, 0.0F, 0.0F, false, on);
      }
   }

   public static class ParticlesModule extends Modules.OverlayModule {
      public static final List<Modules.ParticlesModule.Landing> LIST = new ArrayList<>();
      private long lastHit;

      ParticlesModule() {
         super("particles", "Particles", "Overlay", "Where projectiles land + countdown (pearls, arrows, potions, tridents)", true);
         this.optionLabel = "Disable landing particles";
         this.optionLabel2 = "Hit burst particles";
      }

      @Override
      public void tick(MinecraftClient mc) {
         LIST.clear();
         if (this.cfg().enabled && mc.player != null && mc.world != null) {
            long now = System.currentTimeMillis();
            int n = 0;

            for (Entity e : mc.world.getEntities()) {
               if (e instanceof ProjectileEntity pe) {
                  Vec3d v = e.getVelocity();
                  if (!(v.lengthSquared() < 0.02)) {
                     if (++n > 12) {
                        break;
                     }

                     Entity owner = pe.getOwner();
                     boolean own = owner == mc.player;
                     String label = e.getName().getString() + (owner != null && !own ? " - " + owner.getName().getString() : "");
                     Modules.ParticlesModule.Landing l = simulate(
                        mc, e.getPos(), v, e.getFinalGravity(), label, own ? Theme.rgb(Theme.a1()) : 16731501, own, now
                     );
                     if (l != null) {
                        LIST.add(l);
                     }
                  }
               }
            }

            Modules.ParticlesModule.Landing aim = aim(mc, now);
            if (aim != null) {
               LIST.add(aim);
            }

            if (!this.cfg().option && mc.player.age % 3 == 0) {
               for (Modules.ParticlesModule.Landing l : LIST) {
                  spawn(mc, l.pos());
               }
            }

            LivingEntity t = Tracker.target;
            if (this.cfg().option2 && t != null && Tracker.lastHitMs != this.lastHit) {
               this.lastHit = Tracker.lastHitMs;
               double ty = t.getY() + t.getHeight() * 0.6;

               for (int i = 0; i < 10; i++) {
                  mc.world
                     .addParticle(
                        ParticleTypes.field_11208,
                        t.getX() + (Math.random() - 0.5) * 0.6,
                        ty + (Math.random() - 0.5) * 0.5,
                        t.getZ() + (Math.random() - 0.5) * 0.6,
                        (Math.random() - 0.5) * 0.3,
                        0.15,
                        (Math.random() - 0.5) * 0.3
                     );
               }
            }
         }
      }

      private static void spawn(MinecraftClient mc, Vec3d l) {
         for (int i = 0; i < 10; i++) {
            double a = i / 10.0 * Math.PI * 2.0;
            mc.world
               .addParticle(ParticleTypes.field_11207, l.x + Math.cos(a) * 0.4, l.y + 0.05, l.z + Math.sin(a) * 0.4, 0.0, 0.01, 0.0);
         }

         mc.world.addParticle(ParticleTypes.field_11207, l.x, l.y + 0.1, l.z, 0.0, 0.06, 0.0);
         mc.world.addParticle(ParticleTypes.field_11207, l.x, l.y + 0.6, l.z, 0.0, 0.06, 0.0);
      }

      static Modules.ParticlesModule.Landing simulate(
         MinecraftClient mc, Vec3d start, Vec3d vel0, double grav, String label, int color, boolean own, long now
      ) {
         Vec3d pos = start;
         Vec3d vel = vel0;

         for (int i = 0; i < 300; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult hr = mc.world.raycast(new RaycastContext(pos, next, ShapeType.field_17558, FluidHandling.field_1348, mc.player));
            if (hr.getType() != Type.field_1333) {
               return new Modules.ParticlesModule.Landing(hr.getPos(), i + 1, label, color, now, own);
            }

            pos = next;
            vel = vel.multiply(0.99).add(0.0, -grav, 0.0);
            if (next.y < mc.world.getBottomY() - 10) {
               return null;
            }
         }

         return null;
      }

      static Modules.ParticlesModule.Landing aim(MinecraftClient mc, long now) {
         ClientPlayerEntity p = mc.player;
         ItemStack st = p.getMainHandStack();
         float pitchOff = 0.0F;
         float speed;
         float grav;
         if (st.isOf(Items.field_8634) || st.isOf(Items.field_8543) || st.isOf(Items.field_8803)) {
            speed = 1.5F;
            grav = 0.03F;
         } else if (!st.isOf(Items.field_8436) && !st.isOf(Items.field_8150)) {
            if (st.isOf(Items.field_8102) && p.isUsingItem() && p.getActiveItem().isOf(Items.field_8102)) {
               float pull = BowItem.getPullProgress(p.getItemUseTime());
               if (pull < 0.1F) {
                  return null;
               }

               speed = pull * 3.0F;
               grav = 0.05F;
            } else {
               if (!st.isOf(Items.field_8547) || !p.isUsingItem()) {
                  return null;
               }

               speed = 2.5F;
               grav = 0.05F;
            }
         } else {
            speed = 0.5F;
            grav = 0.05F;
            pitchOff = -20.0F;
         }

         double ry = Math.toRadians(p.getYaw());
         double rp = Math.toRadians(p.getPitch() + pitchOff);
         Vec3d vel = new Vec3d(-Math.sin(ry) * Math.cos(rp), -Math.sin(rp), Math.cos(ry) * Math.cos(rp)).multiply(speed);
         Vec3d pv = p.getVelocity();
         vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
         Vec3d pos = new Vec3d(p.getX(), p.getEyeY() - 0.1, p.getZ());
         return simulate(mc, pos, vel, grav, "Aim", Theme.rgb(Theme.a1()), true, now);
      }

      @Override
      public void renderOverlay(DrawContext ctx, MinecraftClient mc) {
         if (mc.player != null) {
            long now = System.currentTimeMillis();
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();

            for (Modules.ParticlesModule.Landing l : LIST) {
               double left = l.ticks() / 20.0 - (now - l.stamp()) / 1000.0;
               if (!(left < -0.3)) {
                  int[] p = Projector.project(l.pos().add(0.0, 0.5, 0.0));
                  if (p != null) {
                     String t1 = l.label();
                     String t2 = Modules.f("%.1fs", Math.max(0.0, left)) + "  " + Math.round(mc.player.getPos().distanceTo(l.pos())) + "m";
                     int w = Math.max(Gfx.tw(t1), Gfx.tw(t2)) + 14;
                     int h = 22;
                     int x = Math.max(2, Math.min(sw - w - 2, p[0] - w / 2));
                     int y = Math.max(2, Math.min(sh - h - 2, p[1] - h));
                     Gfx.glow(ctx, x, y, w, h, 6, l.color(), 0.6F);
                     Gfx.rrect(ctx, x, y, w, h, 6, Gfx.argb(592402, 0.82F), Gfx.argb(1183522, 0.7F));
                     Gfx.rborder(ctx, x, y, w, h, 6, 1, Gfx.argb(l.color(), 0.65F));
                     Gfx.rrect(ctx, x + 3, y + 4, 2, h - 8, 1, Gfx.argb(l.color(), 1.0F));
                     Gfx.text(ctx, t1, x + 9, y + 3, -1, false);
                     Gfx.text(ctx, t2, x + 9, y + 12, Gfx.argb(l.color(), 1.0F), false);
                  }
               }
            }
         }
      }

      public record Landing(Vec3d pos, int ticks, String label, int color, long stamp, boolean own) {
      }
   }

   static class PerfModule extends HudModule {
      PerfModule() {
         super("perf", "Performance Monitor", "Info", "FPS, 1% low, frame time, RAM, CPU and a frame graph", 0.13F, 0.3F, true, false);
      }

      String text(MinecraftClient mc) {
         return "FPS: "
            + mc.getCurrentFps()
            + "  (avg "
            + Tracker.avgFps
            + " | 1% "
            + Tracker.lowFps
            + ")\nFrame: "
            + Modules.f("%.1f ms", Tracker.frameMs)
            + "\nRAM: "
            + Tracker.usedRam()
            + "\nCPU: "
            + Modules.f("%.0f%%", Tracker.cpu);
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         int w = 100;

         for (String l : this.text(mc).split("\n")) {
            w = Math.max(w, Gfx.tw(l));
         }

         return w;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return 66;
      }

      @Override
      public void render(DrawContext ctx, MinecraftClient mc, int color, boolean preview) {
         String[] l = this.text(mc).split("\n");

         for (int i = 0; i < l.length; i++) {
            Gfx.text(ctx, l[i], 0, i * 10, color, this.cfg().shadow);
         }

         float[] fr = Tracker.recentFrames(50);
         int base = 64;

         for (int i = 0; i < 50; i++) {
            float ms = i < fr.length ? fr[i] : 8.0F;
            int h = Math.max(1, Math.min(22, Math.round(ms / 33.0F * 22.0F)));
            int col = Gfx.lerp(color & 0xFF000000 | 7113983, color & 0xFF000000 | 10513663, i / 49.0F);
            ctx.fill(i * 2, base - h, i * 2 + 2, base, Gfx.ga(col));
         }
      }
   }

   static class PotionModule extends HudModule {
      private static final Map<String, Integer> MAXD = new HashMap<>();

      PotionModule() {
         super("potion", "Potion Effects", "Gear", "Active status effects with timers", 0.88F, 0.02F, true, false);
         this.noContainer();
      }

      private static ItemStack iconFor(String id) {
         switch (id) {
            case "speed":
               return new ItemStack(Items.field_8479);
            case "strength":
               return new ItemStack(Items.field_8371);
            case "fire_resistance":
               return new ItemStack(Items.field_8135);
            case "night_vision":
               return new ItemStack(Items.field_8071);
            case "regeneration":
               return new ItemStack(Items.field_8070);
            case "resistance":
               return new ItemStack(Items.field_8523);
            case "invisibility":
               return new ItemStack(Items.field_8711);
            case "jump_boost":
               return new ItemStack(Items.field_8073);
            case "absorption":
               return new ItemStack(Items.field_8463);
            case "slowness":
               return new ItemStack(Items.field_8777);
            case "weakness":
            case "poison":
               return new ItemStack(Items.field_8680);
            case "haste":
               return new ItemStack(Items.field_8335);
            case "water_breathing":
               return new ItemStack(Items.field_8323);
            case "wither":
               return new ItemStack(Items.WITHER_SKELETON_SKULL);
            case "health_boost":
               return new ItemStack(Items.field_8279);
            case "saturation":
               return new ItemStack(Items.field_8176);
            case "glowing":
               return new ItemStack(Items.field_8601);
            case "levitation":
               return new ItemStack(Items.field_8815);
            case "luck":
               return new ItemStack(Items.field_8687);
            case "slow_falling":
               return new ItemStack(Items.field_8153);
            default:
               return new ItemStack(Items.field_8574);
         }
      }

      private static boolean spriteOk(MinecraftClient mc, Identifier id) {
         try {
            Sprite sp = mc.getGuiAtlasManager().getSprite(id);
            return sp != null && !sp.getContents().getId().equals(MissingSprite.getMissingSpriteId());
         } catch (Throwable var3) {
            return false;
         }
      }

      List<Modules.PotionModule.PRow> rows(MinecraftClient mc, boolean preview) {
         List<Modules.PotionModule.PRow> l = new ArrayList<>();
         if (mc.player != null) {
            if (MAXD.size() > 60) {
               MAXD.clear();
            }

            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
               if (Modules.FULLBRIGHT == null
                  || !Modules.FULLBRIGHT.cfg().enabled
                  || e.getDuration() <= 50000
                  || !e.getEffectType().equals(StatusEffects.field_5925)) {
                  String n = ((StatusEffect)e.getEffectType().comp_349()).getName().getString();
                  int amp = e.getAmplifier();
                  int dur = e.getDuration();
                  boolean inf = e.isInfinite();
                  float prog = 1.0F;
                  if (!inf) {
                     int max = MAXD.merge(n + amp, dur, Math::max);
                     prog = (float)dur / Math.max(1, max);
                  }

                  int sec = dur / 20;
                  String eidPath = "";
                  Sprite spr = null;

                  try {
                     Identifier eid = Registries.STATUS_EFFECT.getId((StatusEffect)e.getEffectType().comp_349());
                     if (eid != null) {
                        eidPath = eid.getPath();
                        spr = mc.getStatusEffectSpriteManager().getSprite(e.getEffectType());
                     }
                  } catch (Throwable var15) {
                  }

                  l.add(
                     new Modules.PotionModule.PRow(
                        n + (amp > 0 ? " " + Modules.roman(amp + 1) : ""),
                        inf ? "\u221e" : sec / 60 + ":" + String.format("%02d", sec % 60),
                        prog,
                        iconFor(eidPath),
                        spr
                     )
                  );
               }
            }
         }

         if (l.isEmpty() && preview) {
            l.add(new Modules.PotionModule.PRow("Speed II", "1:32", 0.7F, new ItemStack(Items.field_8479), null));
            l.add(new Modules.PotionModule.PRow("Night Vision", "\u221e", 1.0F, new ItemStack(Items.field_8071), null));
         }

         return l;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.rows(mc, p).isEmpty() ? 0 : 140;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         int n = this.rows(mc, p).size();
         return n == 0 ? 0 : CardUi.rows(n);
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         float al = (color >>> 24 & 0xFF) / 255.0F;
         List<Modules.PotionModule.PRow> l = this.rows(mc, preview);
         int w = 140;
         int a1 = Theme.rgb(Theme.a1());
         CardUi.panel(c, w, CardUi.rows(l.size()), al);
         CardUi.header(c, w, new ItemStack(Items.BREWING_STAND), "Potions", String.valueOf(l.size()), al);
         int i = 0;

         for (Modules.PotionModule.PRow r : l) {
            int y = 20 + i++ * 19;
            CardUi.row(c, w, y, r.sprite() != null ? ItemStack.EMPTY : r.icon(), r.name(), r.time(), 16777215, r.prog(), a1, al, this.cfg().shadow);
            if (r.sprite() != null) {
               c.drawSpriteStretched(RenderLayer::getGuiTextured, r.sprite(), 6, y, 12, 12);
            }
         }
      }

      private record PRow(String name, String time, float prog, ItemStack icon, Sprite sprite) {
      }
   }

   public static class TargetEspModule extends Modules.OverlayModule {
      public static final String[] STYLES = new String[]{"Brackets", "Orbit", "Glow"};
      public static LivingEntity locked;
      private LivingEntity glowEntity;
      private float glowFade;
      private float glowHp = 1.0F;
      private double glowPhase;
      private long glowLast;
      private String labelText = "";
      private LivingEntity labelEntity;
      private int labelHp10 = -1;
      private int labelFlags = -1;

      TargetEspModule() {
         super(
            "targetesp",
            "Target ESP",
            "Visual",
            "Highlights your target with corner brackets, a glowing orbit swirl or a neon glow aura. Invisible players are never shown. Right-click a player to lock / unlock.",
            true
         );
         this.optionLabel = "Disable right-click lock";
         this.optionLabel2 = "Use own color (ignore theme)";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 1.0F;
         s.val2 = 1.0F;
         s.scale = 1.0F;
         s.textColor = 16777215;
         s.borderColor = 4184319;
         s.option2 = true;
         return s;
      }

      public static void toggleLock(LivingEntity e) {
         if (locked == e) {
            locked = null;
            Notifications.push("Target ESP", "Unlocked", 16731501);
         } else {
            locked = e;
            Notifications.push("Target locked", e.getName().getString(), 16769613);
         }
      }

      private LivingEntity current(MinecraftClient mc) {
         if (locked != null) {
            if (!locked.isRemoved() && !locked.isDead() && mc.player != null && !(locked.distanceTo(mc.player) > 128.0F)) {
               return locked.isInvisible() ? null : locked;
            }

            locked = null;
         }

         return mc.targetedEntity instanceof PlayerEntity pe && pe != mc.player && pe.isAlive() && !pe.isInvisible() && !pe.isSpectator() ? pe : null;
      }

      private static void drawOrbit(
         DrawContext c, MinecraftClient mc, double x, double y, double z, double w, double h, float t, float k, ModuleSettings s, int rgb, float glow, int T
      ) {
         int TAIL = 24;
         int COMETS = 2;
         double R = Math.max(0.55, w * 1.0) * Math.max(0.5F, s.scale);
         Vec3d cam = mc.gameRenderer.getCamera().getPos();
         double cy = y + h * 0.5 + h * 0.1 * Math.sin(t * 0.9);
         double dCenter = (x - cam.x) * (x - cam.x)
            + (y - cam.y) * (y - cam.y)
            + (z - cam.z) * (z - cam.z);

         for (int j = 0; j < 2; j++) {
            double tilt = j == 0 ? 0.55 : -0.45;
            double head = t * 2.4 + j * Math.PI;
            int[] prev = null;
            double prevD = 0.0;

            for (int i = 0; i < 24; i++) {
               double a = head - i * 0.085;
               double px = x + R * Math.cos(a);
               double pz = z + R * Math.sin(a);
               double py = cy + tilt * R * Math.sin(a - j * 0.8) + h * 0.12 * Math.sin(a * 2.0 + j);
               int[] q = Projector.project(new Vec3d(px, py, pz));
               double d = (px - cam.x) * (px - cam.x)
                  + (py - cam.y) * (py - cam.y)
                  + (pz - cam.z) * (pz - cam.z);
               if (q != null && prev != null) {
                  float f = 1.0F - i / 24.0F;
                  float back = d > dCenter ? 0.5F : 1.0F;
                  int th = Math.max(1, Math.round((T + 2) * k * (0.35F + 0.65F * f)));
                  Gfx.line(c, prev[0], prev[1], q[0], q[1], th + 7, Gfx.argb(rgb, 0.14F * glow * f * back));
                  Gfx.line(c, prev[0], prev[1], q[0], q[1], th + 3, Gfx.argb(rgb, 0.3F * glow * f * back));
                  Gfx.line(c, prev[0], prev[1], q[0], q[1], th, Gfx.argb(16777215, 0.95F * f * f * back));
               }

               if (q != null && i == 0) {
                  int hs = Math.max(2, Math.round((T + 2) * k));
                  c.fill(q[0] - hs - 3, q[1] - hs - 3, q[0] + hs + 3, q[1] + hs + 3, Gfx.argb(rgb, 0.16F * glow));
                  c.fill(q[0] - hs, q[1] - hs, q[0] + hs, q[1] + hs, Gfx.argb(16777215, 0.95F));
               }

               prev = q;
            }
         }
      }

      private void resetGlow() {
         this.glowEntity = null;
         this.glowFade = 0.0F;
         this.glowLast = 0L;
         this.labelEntity = null;
      }

      private static int healthColor(float ratio) {
         ratio = Math.max(0.0F, Math.min(1.0F, ratio));
         int c = ratio < 0.5F ? Gfx.lerp(-53955, -11713, ratio * 2.0F) : Gfx.lerp(-11713, -12714118, (ratio - 0.5F) * 2.0F);
         return c & 16777215;
      }

      private void renderGlow(DrawContext c, MinecraftClient mc, ModuleSettings s) {
         long nowN = System.nanoTime();
         float dt = this.glowLast == 0L ? 0.0F : Math.min(0.1F, (float)(nowN - this.glowLast) / 1.0E9F);
         this.glowLast = nowN;
         LivingEntity target = this.current(mc);
         if (target != null) {
            if (this.glowEntity != target) {
               this.glowEntity = target;
               this.glowFade *= 0.35F;
            }

            this.glowFade = Math.min(1.0F, this.glowFade + dt / 0.16F);
         } else if (this.glowEntity != null) {
            this.glowFade = Math.max(0.0F, this.glowFade - dt / 0.28F);
            if (this.glowFade <= 0.0F || this.glowEntity.isRemoved() || !this.glowEntity.isAlive() || this.glowEntity.isInvisible()) {
               this.glowEntity = null;
               this.glowFade = 0.0F;
            }
         }

         LivingEntity e = this.glowEntity;
         if (e != null) {
            this.glowPhase = (this.glowPhase + dt * Math.max(0.2F, s.val2) * 2.2) % 6283.185307179586;
            float ratio = e.getMaxHealth() > 0.0F ? Math.max(0.0F, Math.min(1.0F, e.getHealth() / e.getMaxHealth())) : 1.0F;
            this.glowHp = this.glowHp + (ratio - this.glowHp) * (1.0F - (float)Math.exp(-dt * 8.0F));
            float td = mc.getRenderTickCounter().getTickDelta(false);
            double x = e.prevX + (e.getX() - e.prevX) * td;
            double y = e.prevY + (e.getY() - e.prevY) * td;
            double z = e.prevZ + (e.getZ() - e.prevZ) * td;
            double w = e.getWidth();
            double h = e.getHeight();
            int[] top = Projector.project(new Vec3d(x, y + h, z));
            int[] bot = Projector.project(new Vec3d(x, y, z));
            if (top != null && bot != null) {
               float hpx = Math.abs(bot[1] - top[1]);
               if (!(hpx < 6.0F)) {
                  int[] mid = Projector.project(new Vec3d(x, y + h * 0.5, z));
                  int[] px = Projector.project(new Vec3d(x + w * 0.5, y + h * 0.5, z));
                  int[] pz = Projector.project(new Vec3d(x, y + h * 0.5, z + w * 0.5));
                  float hw;
                  if (mid != null && px != null && pz != null) {
                     float dx = px[0] - mid[0];
                     float dz = pz[0] - mid[0];
                     hw = (float)Math.sqrt(dx * dx + dz * dz);
                  } else {
                     hw = hpx * 0.17F;
                  }

                  hw = Math.max(hw, hpx * 0.12F);
                  float fade = Gfx.ease(this.glowFade);
                  float intensity = Math.max(0.0F, Math.min(1.0F, s.val4));
                  float pulse = (float)(0.5 + 0.5 * Math.sin(this.glowPhase));
                  float pm = s.glowPulse ? 0.62F + 0.38F * pulse : 1.0F;
                  float spread = Math.max(4.0F, hpx * 0.07F)
                     * Math.max(0.3F, s.glowRadius)
                     * Math.max(0.5F, s.scale)
                     * (s.glowPulse ? 0.92F + 0.08F * pulse : 1.0F);
                  int col;
                  if (s.glowHealthColor) {
                     col = healthColor(this.glowHp);
                  } else {
                     int c1 = s.glowColor & 16777215;
                     int c2 = Gfx.lerp(0xFF000000 | c1, -7717377, 0.5F) & 16777215;
                     col = Gfx.lerp(0xFF000000 | c1, 0xFF000000 | c2, (float)(0.5 + 0.5 * Math.sin(this.glowPhase * 0.6))) & 16777215;
                  }

                  int edge = Gfx.lerp(0xFF000000 | col, -1, 0.4F) & 16777215;
                  int bw = Math.round(hw * 2.0F);
                  int bh = Math.round(hpx);
                  int bx = Math.round((top[0] + bot[0]) / 2.0F - hw);
                  int by = Math.min(top[1], bot[1]);
                  int sw = mc.getWindow().getScaledWidth();
                  int sh = mc.getWindow().getScaledHeight();
                  int pad = Math.round(spread) + 12;
                  if (bx + bw + pad >= 0 && bx - pad <= sw && by + bh + pad >= 0 && by - pad <= sh) {
                     int N = 8;

                     for (int i = 8; i >= 1; i--) {
                        float a = fade * intensity * pm * 0.085F * (float)Math.pow(1.0 - (i - 1) / 8.0, 1.5);
                        if (!(a < 0.004F)) {
                           int g = Math.max(1, Math.round(spread * i / 8.0F));
                           Gfx.rrect(c, bx - g, by - g, bw + 2 * g, bh + 2 * g, bw / 2 + g, Gfx.argb(col, a));
                        }
                     }

                     int T = Math.max(1, Math.min(6, s.lineW));
                     int hg = T + 2;
                     Gfx.rborder(c, bx - hg, by - hg, bw + 2 * hg, bh + 2 * hg, bw / 2 + hg, 2, Gfx.argb(col, fade * (0.15F + 0.25F * intensity)));
                     Gfx.rborder(c, bx - T, by - T, bw + 2 * T, bh + 2 * T, bw / 2 + T, T, Gfx.argb(edge, fade * (0.55F + 0.4F * pm)));
                     if ((s.glowName || s.glowHealthText) && !e.isInvisible()) {
                        int hp10 = Math.round(e.getHealth() * 10.0F);
                        int flags = (s.glowName ? 1 : 0) | (s.glowHealthText ? 2 : 0);
                        if (this.labelEntity != e || hp10 != this.labelHp10 || flags != this.labelFlags) {
                           this.labelEntity = e;
                           this.labelHp10 = hp10;
                           this.labelFlags = flags;
                           String name = e.getName().getString();
                           String hp = "\u2665 " + Modules.f("%.1f", e.getHealth());
                           this.labelText = flags == 3 ? name + "  " + hp : (flags == 1 ? name : hp);
                        }

                        int lw = Gfx.tw(this.labelText) + 14;
                        int lx = Math.round((top[0] + bot[0]) / 2.0F) - lw / 2;
                        int ly = by - Math.round(spread) - 20;
                        float prevA = Gfx.alpha;
                        Gfx.alpha = prevA * fade;

                        try {
                           Gfx.rrect(c, lx, ly, lw, 14, 7, Gfx.argb(592402, 0.82F), Gfx.argb(1183522, 0.72F));
                           Gfx.rborder(c, lx, ly, lw, 14, 7, 1, Gfx.argb(col, 0.7F));
                           Gfx.text(c, this.labelText, lx + 7, ly + 3, -1, false);
                        } finally {
                           Gfx.alpha = prevA;
                        }
                     }
                  }
               }
            }
         }
      }

      @Override
      public void renderOverlay(DrawContext c, MinecraftClient mc) {
         if (mc.player == null || mc.world == null) {
            this.resetGlow();
         } else if (mc.currentScreen != null) {
            this.glowLast = 0L;
         } else {
            ModuleSettings gs = this.cfg();
            if (Math.max(0, Math.min(STYLES.length - 1, Math.round(gs.val))) == 2) {
               this.renderGlow(c, mc, gs);
            } else {
               if (this.glowEntity != null) {
                  this.resetGlow();
               }

               LivingEntity e = this.current(mc);
               if (e != null) {
                  ModuleSettings s = this.cfg();
                  float td = mc.getRenderTickCounter().getTickDelta(false);
                  double x = e.prevX + (e.getX() - e.prevX) * td;
                  double y = e.prevY + (e.getY() - e.prevY) * td;
                  double z = e.prevZ + (e.getZ() - e.prevZ) * td;
                  double w = e.getWidth();
                  double h = e.getHeight();
                  long now = System.currentTimeMillis();
                  float t = (float)now / 1000.0F * Math.max(0.2F, s.val2);
                  int[] top = Projector.project(new Vec3d(x, y + h, z));
                  int[] bot = Projector.project(new Vec3d(x, y, z));
                  int[] mid = Projector.project(new Vec3d(x, y + h * 0.5, z));
                  float hpx = top != null && bot != null ? Math.abs(bot[1] - top[1]) : 60.0F;
                  float k = Math.max(0.6F, Math.min(1.6F, hpx / 170.0F)) * s.scale;
                  int T = Math.max(1, Math.min(8, s.lineW));
                  float glow = Math.max(0.0F, Math.min(1.0F, s.val4));
                  int brRgb = s.option2 ? s.textColor & 16777215 : Theme.rgb(Theme.a1());
                  if (s.option2) {
                     int var10000 = s.borderColor & 16777215;
                  } else {
                     Theme.rgb(Theme.a2());
                  }

                  if (s.option2) {
                     int var57 = 16777215;
                  } else {
                     int var58 = Gfx.lerp(0xFF000000 | Theme.rgb(Theme.a1()), -1, 0.7F) & 16777215;
                  }

                  int style = Math.max(0, Math.min(STYLES.length - 1, Math.round(s.val)));
                  if (style == 1) {
                     drawOrbit(c, mc, x, y, z, w, h, t, k, s, s.option2 ? s.textColor & 16777215 : 16777215, glow, T);
                  } else if (mid != null) {
                     double half = Math.max(9.0, hpx * 0.28 * s.scale) * (0.97 + 0.03 * Math.sin(t * 4.0F));
                     double ang = 0.2 * Math.sin(t * 1.6) - 0.15;
                     double cs = Math.cos(ang);
                     double sn = Math.sin(ang);
                     double arm = half * Math.max(0.2F, Math.min(1.0F, s.val3));
                     int th = Math.max(1, Math.round(T * k));

                     for (int sx = -1; sx <= 1; sx += 2) {
                        for (int sy = -1; sy <= 1; sy += 2) {
                           double lx = sx * half;
                           double ly = sy * half;
                           int cx0 = (int)Math.round(mid[0] + lx * cs - ly * sn);
                           int cy0 = (int)Math.round(mid[1] + lx * sn + ly * cs);
                           int ax = (int)Math.round(cx0 - sx * arm * cs);
                           int ay = (int)Math.round(cy0 - sx * arm * sn);
                           int bx = (int)Math.round(cx0 + sy * arm * sn);
                           int by = (int)Math.round(cy0 - sy * arm * cs);
                           Gfx.line(c, cx0, cy0, ax, ay, th + 4, Gfx.argb(brRgb, 0.32F * glow));
                           Gfx.line(c, cx0, cy0, bx, by, th + 4, Gfx.argb(brRgb, 0.32F * glow));
                           Gfx.line(c, cx0, cy0, ax, ay, th, Gfx.argb(brRgb, 1.0F));
                           Gfx.line(c, cx0, cy0, bx, by, th, Gfx.argb(brRgb, 1.0F));
                        }
                     }
                  }

                  int[] lp = e.isInvisible() ? null : Projector.project(new Vec3d(x, y + h + 0.35, z));
                  if (lp != null) {
                     String txt = e.getName().getString() + "  \u2665 " + Modules.f("%.1f", e.getHealth());
                     int lw = Gfx.tw(txt) + 14;
                     int lx = lp[0] - lw / 2;
                     int ly = lp[1] - 16;
                     Gfx.glow(c, lx, ly, lw, 14, 7, brRgb, 0.6F);
                     Gfx.rrect(c, lx, ly, lw, 14, 7, Gfx.argb(592402, 0.82F), Gfx.argb(1183522, 0.72F));
                     Gfx.rborder(c, lx, ly, lw, 14, 7, 1, Gfx.argb(brRgb, 0.65F));
                     Gfx.text(c, txt, lx + 7, ly + 3, -1, false);
                  }
               }
            }
         }
      }
   }

   static class TargetModule extends HudModule {
      private float shown = 1.0F;
      private float lag = 1.0F;
      private LivingEntity last;

      TargetModule() {
         super("target", "Target HUD", "Combat", "Target card: skin head, name, HP and an animated health bar", 0.37F, 0.63F, true, false);
         this.noContainer();
      }

      LivingEntity current(MinecraftClient mc) {
         return mc.targetedEntity instanceof PlayerEntity pe && pe != mc.player && pe.isAlive() && !pe.isInvisible() && !pe.isSpectator() ? pe : null;
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         return this.current(mc) == null && !p ? 0 : 140;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return this.current(mc) == null && !p ? 0 : 42;
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         LivingEntity t = this.current(mc);
         String name = t == null ? (mc.player != null ? mc.player.getName().getString() : "Xx_Dex_xX") : t.getName().getString();
         float hp = t == null ? 8.0F : t.getHealth();
         float max = t == null ? 20.0F : Math.max(1.0F, t.getMaxHealth());
         float pct = MathHelper.clamp(hp / max, 0.0F, 1.0F);
         if (t != this.last) {
            this.last = t;
            this.shown = pct;
            this.lag = pct;
         }

         this.shown = this.shown + (pct - this.shown) * 0.2F;
         if (this.lag < this.shown) {
            this.lag = this.shown;
         } else {
            this.lag = this.lag + (this.shown - this.lag) * 0.04F;
         }

         float al = (color >>> 24 & 0xFF) / 255.0F;
         int a1 = Theme.rgb(Theme.a1());
         int a2 = Theme.rgb(Theme.a2());
         int W = 140;
         int H = 42;
         Gfx.glow(c, 0, 0, 140, 42, 8, a1, 0.45F * al);
         Gfx.rrect(c, 0, 0, 140, 42, 8, Gfx.argb(0, 0.5F * al));
         Gfx.rborder(c, 0, 0, 140, 42, 8, 1, Gfx.argb(a1, 0.7F * al));
         AbstractClientPlayerEntity sp = (AbstractClientPlayerEntity)(t instanceof AbstractClientPlayerEntity ap ? ap : mc.player);
         if (sp != null) {
            PlayerSkinDrawer.draw(c, sp.getSkinTextures(), 8, 8, 22);
         }

         Gfx.rborder(c, 7, 7, 24, 24, 2, 1, Gfx.argb(16777215, 0.2F * al));
         Gfx.text(c, Widgets.fit(name, 95), 36, 10, color, this.cfg().shadow);
         Gfx.text(c, "HP / " + Modules.f("%.1f", hp), 36, 21, Gfx.argb(11186372, al), false);
         int bx = 8;
         int by = 34;
         int bw = 124;
         Gfx.rrect(c, bx, by, bw, 3, 1, Gfx.argb(0, 0.5F * al));
         Gfx.rrect(c, bx, by, Math.max(2, Math.round(bw * this.lag)), 3, 1, Gfx.argb(16777215, 0.3F * al));
         Gfx.rrect(c, bx, by, Math.max(2, Math.round(bw * this.shown)), 3, 1, Gfx.argb(a1, al), Gfx.argb(a2, al));
      }
   }

   static class ToggleModule extends TextModule {
      private final boolean sprint;
      private boolean applied;
      private boolean prev;

      ToggleModule(String id, String name, String desc, float x, float y, boolean sprint) {
         super(
            id,
            name,
            "Utility",
            desc,
            x,
            y,
            sprint ? "[Sprint Toggle: ON]" : "[Sneak Toggle: ON]",
            mc -> sprint
               ? (mc.player.isSprinting() ? "[Sprinting (Toggled)]" : "[Sprint Toggle: ON]")
               : (mc.player.isSneaking() ? "[Sneaking (Toggled)]" : "[Sneak Toggle: ON]")
         );
         this.sprint = sprint;
      }

      @Override
      public void tick(MinecraftClient mc) {
         if (mc.options != null) {
            SimpleOption<Boolean> opt = this.sprint ? mc.options.getSprintToggled() : mc.options.getSneakToggled();
            if (this.cfg().enabled) {
               if (!this.applied) {
                  this.prev = (Boolean)opt.getValue();
                  this.applied = true;
               }

               if (!(Boolean)opt.getValue()) {
                  opt.setValue(true);
               }
            } else if (this.applied) {
               opt.setValue(this.prev);
               this.applied = false;
            }
         }
      }
   }

   static class WatermarkModule extends HudModule {
      private static final String NAME = "DEX VISUAL";
      private static final Identifier LOGO = Identifier.of("dexvisual", "textures/logo.png");

      WatermarkModule() {
         super("watermark", "Watermark", "Info", "DEX VISUAL pill with ping and FPS (top-left)", 0.012F, 0.02F, true, true);
         this.noContainer();
         this.optionLabel = "Hide ping & FPS";
      }

      private String ms(MinecraftClient mc) {
         int p = Modules.ping(mc);
         return p < 0 ? "-- ms" : p + " ms";
      }

      private String fps(MinecraftClient mc) {
         return mc.getCurrentFps() + " FPS";
      }

      @Override
      public int width(MinecraftClient mc, boolean p) {
         int w = 29 + Gfx.waveWidth("DEX VISUAL", 1) + 8;
         if (!this.cfg().option) {
            w += 7 + Gfx.tw(this.ms(mc)) + 7 + Gfx.tw(this.fps(mc)) + 2;
         }

         return w;
      }

      @Override
      public int height(MinecraftClient mc, boolean p) {
         return 17;
      }

      @Override
      public void render(DrawContext c, MinecraftClient mc, int color, boolean preview) {
         float al = (color >>> 24 & 0xFF) / 255.0F;
         int w = this.width(mc, preview);
         int h = 17;
         int a1 = Theme.rgb(Theme.a1());
         int a2 = Theme.rgb(Theme.a2());
         Gfx.glow(c, 0, 0, w, h, 8, a1, 0.7F * al);
         Gfx.rrect(c, 0, 0, w, h, 8, Gfx.argb(592402, 0.82F * al), Gfx.argb(1183522, 0.7F * al));
         Gfx.rrect(c, 8, 1, Math.max(0, w - 16), 1, 0, Gfx.argb(16777215, 0.1F * al));
         Gfx.rborder(c, 0, 0, w, h, 8, 1, Gfx.argb(a1, 0.6F * al));
         c.drawTexture(RenderLayer::getGuiTextured, LOGO, 3, 3, 0.0F, 0.0F, 18, 11, 292, 184, 292, 184, Gfx.ga(Gfx.argb(16777215, al)));
         int x = 24;
         x += Gfx.waveText(c, "DEX VISUAL", x, 5, 1, a1, a2, al) + 7;
         if (!this.cfg().option) {
            int sep = Gfx.argb(16777215, 0.22F * al);
            c.fill(x - 4, 4, x - 3, 13, Gfx.ga(sep));
            String m = this.ms(mc);
            Gfx.text(c, m, x, 5, Gfx.argb(15264757, al), false);
            x += Gfx.tw(m) + 7;
            c.fill(x - 4, 4, x - 3, 13, Gfx.ga(sep));
            Gfx.text(c, this.fps(mc), x, 5, Gfx.argb(15264757, al), false);
         }
      }
   }

   public static class ZoomModule extends Modules.OverlayModule {
      ZoomModule() {
         super("zoom", "Zoom", "Overlay", "Hold the key to zoom in smoothly, scroll the wheel to change the zoom level");
         this.optionLabel = "Smooth (cinematic) camera while zooming";
         this.optionLabel2 = "Scroll wheel changes zoom level";
      }

      @Override
      public ModuleSettings defaults() {
         ModuleSettings s = super.defaults();
         s.val = 4.0F;
         s.option = true;
         s.option2 = true;
         return s;
      }
   }
}

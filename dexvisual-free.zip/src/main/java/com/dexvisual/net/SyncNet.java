package com.dexvisual.net;

import com.dexvisual.config.DexConfig;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload.Id;

public final class SyncNet {
   public static final String VERSION = FabricLoader.getInstance()
      .getModContainer("dexvisual")
      .map(c -> c.getMetadata().getVersion().getFriendlyString())
      .orElse("dev");
   public static final Map<UUID, Map<String, String>> REMOTE = new ConcurrentHashMap<>();
   private static long sendAt = 0L;
   private static long lastBroadcast = 0L;

   private SyncNet() {
   }

   public static void init() {
      PayloadTypeRegistry.playC2S().register(SyncNet.Payload.ID, SyncNet.Payload.CODEC);
      PayloadTypeRegistry.playS2C().register(SyncNet.Payload.ID, SyncNet.Payload.CODEC);
      ClientPlayNetworking.registerGlobalReceiver(SyncNet.Payload.ID, (payload, ctx) -> {
         byte[] d = payload.data();
         ctx.client().execute(() -> handle(d));
      });
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> {
         REMOTE.clear();
         sendAt = System.currentTimeMillis() + 1500L;
      });
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> {
         REMOTE.clear();
         sendAt = 0L;
         lastBroadcast = 0L;
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)mc -> {
         long now = System.currentTimeMillis();
         if (sendAt != 0L && now >= sendAt && mc.player != null && mc.getNetworkHandler() != null) {
            sendAt = 0L;
            lastBroadcast = now;
            send(mc);
         } else if (now - lastBroadcast > 8000L && mc.player != null && mc.getNetworkHandler() != null) {
            lastBroadcast = now;
            send(mc);
         }
      });
   }

   public static void changed() {
      sendAt = System.currentTimeMillis() + 400L;
   }

   public static boolean isDv(UUID id) {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player != null && mc.player.getUuid().equals(id) ? true : REMOTE.containsKey(id);
   }

   private static void send(MinecraftClient mc) {
      try {
         if (mc.player == null || mc.getNetworkHandler() == null) {
            return;
         }

         DexConfig cfg = DexConfig.get();
         StringBuilder sb = new StringBuilder();
         if (cfg.shareCosmetics && cfg.cosmeticsOn && cfg.cosmetics != null) {
            for (Entry<String, String> e : cfg.cosmetics.entrySet()) {
               sb.append(e.getKey()).append('=').append(e.getValue()).append(';');
            }
         }

         ByteArrayOutputStream bo = new ByteArrayOutputStream();
         DataOutputStream out = new DataOutputStream(bo);
         out.writeByte(1);
         UUID myId = mc.player.getUuid();
         out.writeLong(myId.getMostSignificantBits());
         out.writeLong(myId.getLeastSignificantBits());
         out.writeUTF(VERSION);
         out.writeUTF(sb.toString());
         mc.getNetworkHandler().sendPacket(new CustomPayloadC2SPacket(new SyncNet.Payload(bo.toByteArray())));
      } catch (Throwable var6) {
         System.err.println("[DexVisual] sync send failed: " + var6);
      }
   }

   private static void handle(byte[] d) {
      try {
         if (d == null || d.length < 1) {
            return;
         }

         DataInputStream in = new DataInputStream(new ByteArrayInputStream(d));
         int type = in.readUnsignedByte();
         if (type == 1 || type == 2) {
            if (d.length < 17) {
               return;
            }

            UUID id = new UUID(in.readLong(), in.readLong());
            String ver = in.readUTF();
            String sel = in.readUTF();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && mc.player.getUuid().equals(id)) {
               return;
            }

            if (!VERSION.equals(ver)) {
               REMOTE.remove(id);
               return;
            }

            Map<String, String> m = new LinkedHashMap<>();
            if (!sel.isEmpty()) {
               for (String part : sel.split(";")) {
                  int i = part.indexOf(61);
                  if (i > 0 && i < part.length() - 1) {
                     m.put(part.substring(0, i), part.substring(i + 1));
                  }
               }
            }

            REMOTE.put(id, m);
            if (sendAt == 0L && System.currentTimeMillis() - lastBroadcast > 3000L) {
               sendAt = System.currentTimeMillis() + 400L;
            }
         } else if (type == 3 && d.length >= 17) {
            REMOTE.remove(new UUID(in.readLong(), in.readLong()));
         }
      } catch (Throwable var13) {
         System.err.println("[DexVisual] sync read failed: " + var13);
      }
   }

   public record Payload(byte[] data) implements CustomPayload {
      public static final Id<SyncNet.Payload> ID = new Id(Identifier.of("dexvisual", "sync"));
      public static final PacketCodec<RegistryByteBuf, SyncNet.Payload> CODEC = PacketCodec.of((v, buf) -> buf.method_52983(v.data), buf -> {
         byte[] b = new byte[buf.readableBytes()];
         buf.method_52979(b);
         return new SyncNet.Payload(b);
      });

      public Id<? extends CustomPayload> getId() {
         return ID;
      }
   }
}

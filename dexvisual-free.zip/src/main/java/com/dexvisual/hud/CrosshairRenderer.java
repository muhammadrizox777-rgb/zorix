package com.dexvisual.hud;

import com.dexvisual.config.CrosshairSettings;
import com.dexvisual.config.DexConfig;
import com.dexvisual.gui.Theme;
import com.dexvisual.util.Gfx;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class CrosshairRenderer {
   private static float dyn = 0.0F;

   private CrosshairRenderer() {
   }

   public static void drawHud(DrawContext ctx, MinecraftClient mc) {
      if (mc.player != null && !mc.options.hudHidden && mc.currentScreen == null && mc.options.getPerspective().isFirstPerson()) {
         CrosshairSettings s = DexConfig.get().crosshair;
         float target = 0.0F;
         if (s.dynamic) {
            Vec3d v = mc.player.getVelocity();
            target = (float)Math.min(6.0, Math.hypot(v.x, v.z) * 24.0);
            if (!mc.player.isOnGround()) {
               target += 3.0F;
            }

            if (mc.player.isSprinting()) {
               target++;
            }
         }

         dyn = dyn + (target - dyn) * 0.25F;
         int cx = mc.getWindow().getScaledWidth() / 2 + s.offX;
         int cy = mc.getWindow().getScaledHeight() / 2 + s.offY;
         draw(ctx, cx, cy, s, false, dyn);
      }
   
   }

   public static int mainColor(CrosshairSettings s) {
      return DexConfig.get().themeSync && !s.ownColor ? Theme.rgb(Theme.a1()) : s.color;
   }

   public static void drawHitMarker(DrawContext c, int cx, int cy, CrosshairSettings s, float prog) {
      prog = Math.max(0.0F, Math.min(1.0F, prog));
      int col = Gfx.ga(Gfx.argb(s.hitColor, (1.0F - prog) * s.opacity));
      int d = 4 + Math.round(prog * 8.0F);

      for (int i = 0; i < 4; i++) {
         for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
               int x = cx + sx * (d + i);
               int y = cy + sy * (d + i);
               c.fill(x, y, x + 1, y + 1, col);
            }
         }
      }
   }

   public static void draw(DrawContext c, int cx, int cy, CrosshairSettings s, boolean hit, float extra) {
      int rgb = hit ? s.hitColor : mainColor(s);
      int col = Gfx.ga(Gfx.argb(rgb, s.opacity));
      int out = Gfx.ga(Gfx.argb(0, s.opacity * 0.85F));
      int g = Math.round(s.gap + extra);
      int len = Math.max(1, s.size);
      int t = Math.max(1, s.thickness);
      int ho = t / 2;
      List<int[]> r = new ArrayList<>();
      String st = s.style == null ? "CROSS" : s.style;
      switch (st) {
         case "PLUS":
            r.add(new int[]{cx - ho, cy - len, cx - ho + t, cy + len});
            r.add(new int[]{cx - len, cy - ho, cx + len, cy - ho + t});
            break;
         case "X":
            for (int i = 0; i < len; i++) {
               int o = g + i;
               r.add(new int[]{cx + o, cy + o, cx + o + t, cy + o + t});
               r.add(new int[]{cx - o - t, cy + o, cx - o, cy + o + t});
               r.add(new int[]{cx + o, cy - o - t, cx + o + t, cy - o});
               r.add(new int[]{cx - o - t, cy - o - t, cx - o, cy - o});
            }
            break;
         case "DOT":
            int d = Math.max(2, t);
            r.add(new int[]{cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d});
            break;
         case "CIRCLE":
         case "HALO":
            int rad = len + g;

            for (int deg = 0; deg < 360; deg += 3) {
               int x = cx + (int)Math.round(Math.cos(Math.toRadians(deg)) * rad);
               int y = cy + (int)Math.round(Math.sin(Math.toRadians(deg)) * rad);
               r.add(new int[]{x - ho, y - ho, x - ho + t, y - ho + t});
            }
            break;
         case "DIAMOND":
            int rad = len + g;

            for (int i = 0; i <= rad; i++) {
               r.add(new int[]{cx + i, cy - rad + i, cx + i + t, cy - rad + i + t});
               r.add(new int[]{cx + rad - i, cy + i, cx + rad - i + t, cy + i + t});
               r.add(new int[]{cx - i - t, cy + rad - i, cx - i, cy + rad - i + t});
               r.add(new int[]{cx - rad + i - t, cy - i - t, cx - rad + i, cy - i});
            }
            break;
         default:
            if (!st.equals("T")) {
               r.add(new int[]{cx - ho, cy - g - len, cx - ho + t, cy - g});
            }

            r.add(new int[]{cx - ho, cy + g, cx - ho + t, cy + g + len});
            r.add(new int[]{cx - g - len, cy - ho, cx - g, cy - ho + t});
            r.add(new int[]{cx + g, cy - ho, cx + g + len, cy - ho + t});
      }

      if ((s.dot || st.equals("HALO")) && !st.equals("DOT")) {
         int d = Math.max(2, t);
         r.add(new int[]{cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d});
      }

      if (s.glow) {
         int g1 = Gfx.ga(Gfx.argb(rgb, s.opacity * 0.16F));
         int g2 = Gfx.ga(Gfx.argb(rgb, s.opacity * 0.08F));

         for (int[] q : r) {
            c.fill(q[0] - 2, q[1] - 2, q[2] + 2, q[3] + 2, g2);
         }

         for (int[] q : r) {
            c.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, g1);
         }
      }

      if (s.outline) {
         for (int[] q : r) {
            c.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, out);
         }
      }

      for (int[] q : r) {
         c.fill(q[0], q[1], q[2], q[3], col);
      }
   }
}

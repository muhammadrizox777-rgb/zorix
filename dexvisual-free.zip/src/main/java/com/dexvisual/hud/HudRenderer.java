package com.dexvisual.hud;

import com.dexvisual.config.DexConfig;
import com.dexvisual.config.ModuleSettings;
import com.dexvisual.gui.Theme;
import com.dexvisual.module.HudModule;
import com.dexvisual.module.Modules;
import com.dexvisual.util.Gfx;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;

public final class HudRenderer {
   private static final Map<String, Float> PROGRESS = new HashMap<>();
   private static long lastNs;

   private HudRenderer() {
   }

   public static int[] box(HudModule m, MinecraftClient mc, boolean preview) {
      int cw = m.width(mc, preview);
      int ch = m.height(mc, preview);
      if (cw > 0 && ch > 0) {
         ModuleSettings s = m.cfg();
         int pad = m.container ? 5 : 0;
         int bw = cw + pad * 2;
         int bh = ch + pad * 2;
         int sw = mc.getWindow().getScaledWidth();
         int sh = mc.getWindow().getScaledHeight();
         int w = (int)Math.ceil(bw * s.scale);
         int h = (int)Math.ceil(bh * s.scale);
         int x = MathHelper.clamp(Math.round(s.x * sw), 0, Math.max(0, sw - w));
         int y = MathHelper.clamp(Math.round(s.y * sh), 0, Math.max(0, sh - h));
         return new int[]{x, y, w, h, bw, bh};
      } else {
         return null;
      }
   }

   public static void render(DrawContext ctx, MinecraftClient mc, boolean editor) {
      DexConfig cfg = DexConfig.get();
      long now = System.nanoTime();
      float dt = lastNs == 0L ? 0.016F : Math.min(0.1F, (float)(now - lastNs) / 1.0E9F);
      lastNs = now;

      for (HudModule m : Modules.ALL) {
         if (m.box) {
            ModuleSettings s = m.cfg();
            boolean on = s.enabled && (editor || cfg.hudVisible);
            float p = PROGRESS.getOrDefault(m.id, on ? 1.0F : 0.0F);
            float ghost = 1.0F;
            String anim = s.animation == null ? "FADE" : s.animation;
            if (editor) {
               p = 1.0F;
               ghost = s.enabled ? 1.0F : 0.28F;
            } else if (cfg.hudAnim && !Modules.optimizing() && !"NONE".equals(anim)) {
               float target = on ? 1.0F : 0.0F;
               p += (target - p) * Math.min(1.0F, dt * 9.0F * cfg.animSpeed);
               if (Math.abs(target - p) < 0.01F) {
                  p = target;
               }
            } else {
               p = on ? 1.0F : 0.0F;
            }

            PROGRESS.put(m.id, p);
            if (!(p <= 0.01F)) {
               int[] b = box(m, mc, editor);
               if (b != null) {
                  boolean animating = !editor && !"NONE".equals(anim);
                  float e = animating ? Gfx.ease(p) : 1.0F;
                  float slide = animating && "SLIDE".equals(anim) ? (1.0F - e) * 30.0F * (s.x < 0.5F ? -1.0F : 1.0F) : 0.0F;
                  float pop = animating && "POP".equals(anim) ? 0.78F + 0.22F * Gfx.easeBack(p) : 1.0F;
                  float a = s.opacity * ghost * (animating ? e : 1.0F);
                  drawBox(ctx, mc, m, b, s, cfg, a, slide, pop, editor);
               }
            }
         }
      }

      if (!editor && cfg.hudVisible) {
         for (HudModule mx : Modules.ALL) {
            if (!mx.box && mx.cfg().enabled) {
               mx.renderOverlay(ctx, mc);
            }
         }
      }
   
   }

   private static void drawBox(
      DrawContext ctx, MinecraftClient mc, HudModule m, int[] b, ModuleSettings s, DexConfig cfg, float a, float slide, float pop, boolean preview
   ) {
      int accent = cfg.themeSync && !s.ownColor ? Theme.rgb(Theme.a1()) : s.borderColor;
      int accent2 = cfg.themeSync && !s.ownColor ? Theme.rgb(Theme.a2()) : s.borderColor;
      MatrixStack ms = ctx.getMatrices();
      ms.push();
      ms.translate(b[0] + b[2] / 2.0F + slide, b[1] + b[3] / 2.0F, 0.0F);
      ms.scale(s.scale * pop, s.scale * pop, 1.0F);
      ms.translate(-b[4] / 2.0F, -b[5] / 2.0F, 0.0F);
      if (m.container) {
         int r = Math.max(0, s.radius);
         if (s.border) {
            Gfx.glow(ctx, 0, 0, b[4], b[5], r, accent, 0.55F * a);
         }

         if (s.background) {
            Gfx.glow(ctx, 0, 0, b[4], b[5], r, 0, 0.45F * a);
            Gfx.rrect(ctx, 0, 0, b[4], b[5], r, Gfx.argb(s.bgColor, s.bgOpacity * a * 1.25F), Gfx.argb(s.bgColor, s.bgOpacity * a * 0.7F));
            Gfx.rrect(ctx, r, 1, Math.max(0, b[4] - 2 * r), 1, 0, Gfx.argb(16777215, 0.12F * a));
         }

         if (s.border) {
            Gfx.rborder(ctx, 0, 0, b[4], b[5], r, s.borderWidth, Gfx.argb(accent, 0.5F * a));
            int segs = 10;
            int lw = Math.max(0, b[4] - 2 * r - 2);

            for (int i = 0; i < segs; i++) {
               int x0 = r + 1 + lw * i / segs;
               int x1 = r + 1 + lw * (i + 1) / segs;
               int col = Gfx.lerp(0xFF000000 | accent, 0xFF000000 | accent2, (float)i / (segs - 1));
               ctx.fill(x0, 0, x1, 1, Gfx.ga(col & 16777215 | (int)(255.0F * Math.min(1.0F, 0.9F * a)) << 24));
            }
         }
      }

      ms.translate(m.container ? 5.0F : 0.0F, m.container ? 5.0F : 0.0F, 0.0F);
      m.render(ctx, mc, Gfx.argb(s.textColor, a), preview);
      ms.pop();
   }

   public static void renderGhosts(DrawContext ctx, MinecraftClient mc) {
      DexConfig cfg = DexConfig.get();
      if (cfg.hudVisible) {
         for (HudModule m : Modules.ALL) {
            if (m.box) {
               ModuleSettings s = m.cfg();
               if (s.enabled && box(m, mc, false) == null) {
                  int[] b = box(m, mc, true);
                  if (b != null) {
                     drawBox(ctx, mc, m, b, s, cfg, s.opacity, 0.0F, 1.0F, true);
                  }
               }
            }
         }
      }
   }

   public static int[] boxOrPreview(HudModule m, MinecraftClient mc) {
      int[] b = box(m, mc, false);
      return b != null ? b : box(m, mc, true);
   }

   public static boolean drawPreview(DrawContext ctx, MinecraftClient mc, HudModule m, int ax, int ay, int aw, int ah) {
      if (!m.box) {
         return false;
      } else {
         int cw = m.width(mc, true);
         int ch = m.height(mc, true);
         if (cw > 0 && ch > 0) {
            ModuleSettings s = m.cfg();
            int pad = m.container ? 5 : 0;
            int bw = cw + pad * 2;
            int bh = ch + pad * 2;
            float sc = Math.max(0.05F, s.scale);
            int w = (int)Math.ceil(bw * sc);
            int h = (int)Math.ceil(bh * sc);
            float fit = Math.min(1.0F, Math.min((aw - 8.0F) / Math.max(1, w), (ah - 8.0F) / Math.max(1, h)));
            if (fit <= 0.05F) {
               return false;
            } else {
               int cx = ax + aw / 2;
               int cy = ay + ah / 2;
               MatrixStack ms = ctx.getMatrices();
               ms.push();
               ms.translate(cx, cy, 0.0F);
               ms.scale(fit, fit, 1.0F);
               ms.translate(-cx, -cy, 0.0F);
               int[] b = new int[]{cx - w / 2, cy - h / 2, w, h, bw, bh};
               float a = Math.max(0.2F, s.opacity) * (s.enabled ? 1.0F : 0.55F);
               drawBox(ctx, mc, m, b, s, DexConfig.get(), a, 0.0F, 1.0F, true);
               ms.pop();
               return true;
            }
         } else {
            return false;
         }
      }
   }
}

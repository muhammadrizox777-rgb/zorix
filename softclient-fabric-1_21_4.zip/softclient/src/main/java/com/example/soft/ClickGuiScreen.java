package com.example.soft;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int W = 110, H = 14, GAP = 10, TOP = 20;

    public ClickGuiScreen() { super(Text.literal("SoftClient")); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        List<String> cats = SoftClient.modules.categories();
        int totalW = cats.size() * W + (cats.size() - 1) * GAP;
        int x = (width - totalW) / 2;
        String hover = null;

        for (String cat : cats) {
            ctx.fill(x, TOP, x + W, TOP + H, 0xFF2B2B8F);
            ctx.drawCenteredTextWithShadow(textRenderer, cat, x + W / 2, TOP + 3, 0xFFFFFFFF);
            int y = TOP + H;
            for (Module m : SoftClient.modules.modules) {
                if (!m.category.equals(cat)) continue;
                boolean over = mouseX >= x && mouseX < x + W && mouseY >= y && mouseY < y + H;
                int bg = m.isEnabled() ? 0xFF1E8F3E : (over ? 0xFF444444 : 0xFF222222);
                ctx.fill(x, y, x + W, y + H, bg);
                ctx.drawTextWithShadow(textRenderer, m.name, x + 4, y + 3, 0xFFFFFFFF);
                if (over) hover = m.description;
                y += H;
            }
            x += W + GAP;
        }
        if (hover != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, hover, width / 2, height - 20, 0xFFFFFF55);
        }
        ctx.drawCenteredTextWithShadow(textRenderer, "Modulni yoqish/o'chirish uchun bosing, Esc - yopish",
                width / 2, height - 10, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<String> cats = SoftClient.modules.categories();
        int totalW = cats.size() * W + (cats.size() - 1) * GAP;
        int x = (width - totalW) / 2;
        for (String cat : cats) {
            int y = TOP + H;
            for (Module m : SoftClient.modules.modules) {
                if (!m.category.equals(cat)) continue;
                if (mx >= x && mx < x + W && my >= y && my < y + H) {
                    m.toggle();
                    return true;
                }
                y += H;
            }
            x += W + GAP;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}

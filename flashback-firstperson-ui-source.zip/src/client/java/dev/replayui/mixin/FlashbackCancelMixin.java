package dev.replayui.mixin;

import dev.replayui.UiTrackRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "com.moulberry.flashback.Flashback", remap = false)
public abstract class FlashbackCancelMixin {
    @Inject(method = "cancelRecordingReplay", at = @At("HEAD"), remap = false)
    private static void firstpersonui$discardCancelledTrack(CallbackInfo callbackInfo) {
        UiTrackRuntime.cancelRecording();
    }
}

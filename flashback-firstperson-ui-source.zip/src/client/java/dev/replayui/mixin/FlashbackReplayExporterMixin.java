package dev.replayui.mixin;

import dev.replayui.UiTrackRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;

@Mixin(targets = "com.moulberry.flashback.record.ReplayExporter", remap = false)
public abstract class FlashbackReplayExporterMixin {
    @Inject(method = "export", at = @At("TAIL"), remap = false)
    private static void firstpersonui$appendTrack(Path recordFolder, Path outputFile, String name,
                                                   CallbackInfo callbackInfo) {
        UiTrackRuntime.attachTrack(recordFolder, outputFile);
    }
}

package dev.replayui.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import dev.replayui.UiTrackPlayback;
import dev.replayui.UiTrackRuntime;

import java.util.function.Supplier;

@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {
    @Shadow @Final GuiRenderState renderState;

    @Invoker("executeDrawRange")
    protected abstract void firstpersonui$invokeExecuteDrawRange(
            Supplier<String> label,
            RenderTarget target,
            GpuBufferSlice fogBuffer,
            GpuBufferSlice dynamicTransforms,
            GpuBuffer indexBuffer,
            VertexFormat.IndexType indexType,
            int startIndex,
            int endIndex
    );

    @Inject(method = "render", at = @At("HEAD"))
    private void firstpersonui$prepareGui(GpuBufferSlice transform, CallbackInfo callbackInfo) {
        if (!UiTrackRuntime.beginCapturePass()) {
            UiTrackPlayback.appendOverlay(renderState);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void firstpersonui$finishGui(GpuBufferSlice transform, CallbackInfo callbackInfo) {
        UiTrackRuntime.finishCapturePass();
    }

    @Redirect(
            method = "draw",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/render/GuiRenderer;executeDrawRange(Ljava/util/function/Supplier;Lcom/mojang/blaze3d/pipeline/RenderTarget;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lcom/mojang/blaze3d/buffers/GpuBuffer;Lcom/mojang/blaze3d/vertex/VertexFormat$IndexType;II)V"
            )
    )
    private void firstpersonui$duplicateDrawForCapture(
            GuiRenderer renderer,
            Supplier<String> label,
            RenderTarget target,
            GpuBufferSlice fogBuffer,
            GpuBufferSlice dynamicTransforms,
            GpuBuffer indexBuffer,
            VertexFormat.IndexType indexType,
            int startIndex,
            int endIndex
    ) {
        GuiRendererMixin accessor = (GuiRendererMixin) (Object) renderer;
        accessor.firstpersonui$invokeExecuteDrawRange(
                label, target, fogBuffer, dynamicTransforms, indexBuffer, indexType, startIndex, endIndex
        );

        RenderTarget captureTarget = UiTrackRuntime.captureTarget();
        if (UiTrackRuntime.isCapturePassActive() && captureTarget != null && captureTarget != target) {
            accessor.firstpersonui$invokeExecuteDrawRange(
                    label, captureTarget, fogBuffer, dynamicTransforms, indexBuffer, indexType, startIndex, endIndex
            );
        }
    }
}

package dev.replayui.mixin;

import dev.replayui.UiTrackRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.file.Path;

@Mixin(targets = "com.moulberry.flashback.record.Recorder", remap = false)
public abstract class FlashbackRecorderMixin {
    @Inject(method = "finish", at = @At("TAIL"), remap = false)
    private void firstpersonui$finishTrack(CallbackInfoReturnable<Path> callbackInfo) {
        UiTrackRuntime.finishRecording(callbackInfo.getReturnValue());
    }
}

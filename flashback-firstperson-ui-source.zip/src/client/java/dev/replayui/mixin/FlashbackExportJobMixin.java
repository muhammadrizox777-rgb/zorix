package dev.replayui.mixin;

import dev.replayui.UiTrackPlayback;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Method;

@Mixin(targets = "com.moulberry.flashback.exporting.ExportJob", remap = false)
public abstract class FlashbackExportJobMixin {
    @Inject(method = "run", at = @At("HEAD"), remap = false)
    private void firstpersonui$beginExport(CallbackInfo callbackInfo) {
        UiTrackPlayback.beginExport();
    }

    @Inject(method = "doExport", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V",
            shift = At.Shift.BEFORE, remap = true), remap = false)
    private void firstpersonui$prepareFrame(CallbackInfo callbackInfo) {
        double relativeTick = ((Number) invokeNoArg(this, "getCurrentTickDouble")).doubleValue();
        Object settings = invokeNoArg(this, "getSettings");
        UiTrackPlayback.prepareFrame(readStartTick(settings) + relativeTick);
    }

    @Inject(method = "run", at = @At("TAIL"), remap = false)
    private void firstpersonui$endExport(CallbackInfo callbackInfo) {
        UiTrackPlayback.endExport();
    }

    private static int readStartTick(Object settings) {
        try {
            Method startTick = settings.getClass().getMethod("startTick");
            return ((Number) startTick.invoke(settings)).intValue();
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Flashback export settings no longer expose startTick().", exception);
        }
    }

    private static Object invokeNoArg(Object instance, String methodName) {
        try {
            Method method = instance.getClass().getMethod(methodName);
            return method.invoke(instance);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Flashback export API method " + methodName + "() was not found.", exception);
        }
    }
}

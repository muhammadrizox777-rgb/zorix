package dev.replayui;

import java.util.ArrayList;
import java.util.List;

public final class UiTrackManifest {
    public int version = 1;
    public int width;
    public int height;
    public List<Frame> frames = new ArrayList<>();

    public static final class Frame {
        public int tick;
        public String file;

        public Frame() {}

        public Frame(int tick, String file) {
            this.tick = tick;
            this.file = file;
        }
    }
}

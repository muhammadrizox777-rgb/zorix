package dev.replayui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.NativeImage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.CRC32C;
import org.lwjgl.system.MemoryUtil;

public final class UiTrackRuntime {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path TEMP_ROOT = FabricLoader.getInstance().getConfigDir()
            .resolve("firstperson-replay-ui").resolve("tracks");
    private static final ExecutorService IMAGE_WRITER = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "firstperson-ui-track-writer");
        thread.setDaemon(true);
        return thread;
    });
    private static final Map<Path, Path> FINISHED_TRACKS = new ConcurrentHashMap<>();

    private static Object activeRecorder;
    private static Session activeSession;
    private static TextureTarget captureTarget;
    private static RenderTarget previousTarget;
    private static boolean capturePassActive;
    private static long lastCaptureNanos;

    private UiTrackRuntime() {}

    public static boolean beginCapturePass() {
        if (!UiTrackConfig.current().captureGuiTrack || !FlashbackBridge.isLoaded()) {
            return false;
        }

        Object recorder = FlashbackBridge.recorder();
        if (recorder == null) {
            return false;
        }

        if (recorder != activeRecorder) {
            activeRecorder = recorder;
            activeSession = new Session(TEMP_ROOT.resolve(UUID.randomUUID().toString()));
            lastCaptureNanos = 0L;
        }

        if (activeSession == null) {
            return false;
        }

        long now = System.nanoTime();
        long interval = 1_000_000_000L / UiTrackConfig.current().captureFramesPerSecond;
        if (now - lastCaptureNanos < interval) {
            return false;
        }

        Minecraft minecraft = Minecraft.getInstance();
        previousTarget = minecraft.getMainRenderTarget();
        if (previousTarget == null) {
            return false;
        }

        try {
            Files.createDirectories(activeSession.directory.resolve("frames"));
            captureTarget = resizeOrCreate(captureTarget, previousTarget.width, previousTarget.height);
            RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(
                    captureTarget.getColorTexture(), 0, captureTarget.getDepthTexture(), 1.0);
            lastCaptureNanos = now;
            capturePassActive = true;
            return true;
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not start transparent UI capture pass.", exception);
            capturePassActive = false;
            return false;
        }
    }

    public static void finishCapturePass() {
        if (!capturePassActive || captureTarget == null || previousTarget == null) {
            return;
        }

        capturePassActive = false;
        RenderTarget screenTarget = captureTarget;
        RenderTarget gameTarget = previousTarget;
        Session captureSession = activeSession;
        previousTarget = null;

        try {
            int tick = FlashbackBridge.recordedTick(activeRecorder);
            if (tick < 0 && captureSession != null) {
                tick = captureSession.nextFallbackTick();
            }
            int capturedTick = tick;
            if (captureSession != null) {
                Screenshot.takeScreenshot(screenTarget, image -> queueImage(image, capturedTick, captureSession));
            }
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not finish transparent UI capture pass.", exception);
        }
    }

    public static boolean isCapturePassActive() {
        return capturePassActive;
    }

    public static RenderTarget captureTarget() {
        return captureTarget;
    }

    public static void finishRecording(Path recordFolder) {
        Session session = activeSession;
        if (session == null) {
            activeRecorder = null;
            return;
        }

        activeRecorder = null;
        activeSession = null;

        try {
            Future<?> flush = IMAGE_WRITER.submit(() -> {});
            flush.get();

            if (session.frames.isEmpty()) {
                deleteTree(session.directory);
                return;
            }

            session.frames.sort(Comparator.comparingInt(frame -> frame.tick));
            session.manifest.frames = new ArrayList<>(session.frames);
            Files.createDirectories(session.directory);
            Files.writeString(session.directory.resolve("manifest.json"), GSON.toJson(session.manifest));
            FINISHED_TRACKS.put(normalize(recordFolder), session.directory);
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not finish the UI track.", exception);
            deleteTree(session.directory);
        }
    }

    public static void cancelRecording() {
        Session session = activeSession;
        activeSession = null;
        activeRecorder = null;
        if (session != null) {
            session.cancelled = true;
            deleteTree(session.directory);
        }
    }

    public static void attachTrack(Path recordFolder, Path outputFile) {
        Path key = normalize(recordFolder);
        Path trackFolder = FINISHED_TRACKS.get(key);
        if (trackFolder == null || !Files.isRegularFile(outputFile)) {
            return;
        }

        try (FileSystem zip = FileSystems.newFileSystem(outputFile)) {
            Path zipRoot = zip.getPath("/ui-track");
            Path frameRoot = zipRoot.resolve("frames");
            Files.createDirectories(frameRoot);
            Files.copy(trackFolder.resolve("manifest.json"), zipRoot.resolve("manifest.json"),
                    StandardCopyOption.REPLACE_EXISTING);

            for (UiTrackManifest.Frame frame : readManifest(trackFolder.resolve("manifest.json")).frames) {
                Path source = trackFolder.resolve(frame.file);
                Path destination = zipRoot.resolve(frame.file);
                Files.createDirectories(destination.getParent());
                Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
            }

            int frameCount = readManifest(trackFolder.resolve("manifest.json")).frames.size();
            FINISHED_TRACKS.remove(key);
            deleteTree(trackFolder);
            FirstPersonReplayUiClient.LOGGER.info("Added {} UI frames to replay {}.",
                    frameCount, outputFile.getFileName());
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not add UI track to replay {}.", outputFile, exception);
        }
    }

    public static void discardTrack(Path recordFolder) {
        Path trackFolder = FINISHED_TRACKS.remove(normalize(recordFolder));
        if (trackFolder != null) {
            deleteTree(trackFolder);
        }
    }

    public static void shutdown() {
        if (captureTarget != null) {
            captureTarget.destroyBuffers();
            captureTarget = null;
        }
        IMAGE_WRITER.shutdown();
    }

    private static void queueImage(NativeImage image, int tick, Session session) {
        if (session.cancelled) {
            image.close();
            return;
        }

        int hash = imageHash(image);
        int index;
        synchronized (session) {
            if (session.hasLastImage && hash == session.lastImageHash) {
                image.close();
                return;
            }
            session.lastImageHash = hash;
            session.hasLastImage = true;
            index = session.frames.size();
            session.manifest.width = image.getWidth();
            session.manifest.height = image.getHeight();
            String file = "frames/frame-%06d.png".formatted(index);
            session.frames.add(new UiTrackManifest.Frame(tick, file));
        }

        Path imagePath = session.directory.resolve("frames/frame-%06d.png".formatted(index));
        IMAGE_WRITER.submit(() -> {
            try (image) {
                Files.createDirectories(imagePath.getParent());
                image.writeToFile(imagePath);
            } catch (IOException exception) {
                FirstPersonReplayUiClient.LOGGER.error("Could not write captured UI frame {}.", imagePath, exception);
            }
        });
    }

    private static int imageHash(NativeImage image) {
        int bytes = Math.multiplyExact(
                Math.multiplyExact(image.getWidth(), image.getHeight()),
                image.format().components()
        );
        CRC32C checksum = new CRC32C();
        checksum.update(MemoryUtil.memByteBuffer(image.getPointer(), bytes));
        return (int) checksum.getValue();
    }

    private static UiTrackManifest readManifest(Path path) throws IOException {
        return GSON.fromJson(Files.readString(path), UiTrackManifest.class);
    }

    private static TextureTarget resizeOrCreate(TextureTarget target, int width, int height) {
        if (target == null) {
            return new TextureTarget("first-person UI track", width, height, true);
        }
        if (target.width != width || target.height != height) {
            target.resize(width, height);
        }
        return target;
    }

    private static Path normalize(Path path) {
        return path.toAbsolutePath().normalize();
    }

    private static void deleteTree(Path root) {
        if (root == null || !Files.exists(root)) {
            return;
        }
        try (var paths = Files.walk(root)) {
            paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException ignored) {
                    // Best-effort cleanup for temporary capture data.
                }
            });
        } catch (IOException exception) {
            FirstPersonReplayUiClient.LOGGER.warn("Could not clean temporary UI-track folder {}.", root, exception);
        }
    }

    private static final class Session {
        private final Path directory;
        private final UiTrackManifest manifest = new UiTrackManifest();
        private final List<UiTrackManifest.Frame> frames = new ArrayList<>();
        private long fallbackStartNanos = System.nanoTime();
        private int lastImageHash;
        private boolean hasLastImage;
        private volatile boolean cancelled;

        private Session(Path directory) {
            this.directory = directory;
        }

        private int nextFallbackTick() {
            return (int) ((System.nanoTime() - fallbackStartNanos) / 50_000_000L);
        }
    }
}

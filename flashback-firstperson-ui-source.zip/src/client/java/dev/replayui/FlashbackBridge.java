package dev.replayui;

import net.minecraft.world.entity.Entity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

final class FlashbackBridge {
    private static final String FLASHBACK_CLASS = "com.moulberry.flashback.Flashback";
    private static boolean missingFieldLogged;

    private FlashbackBridge() {}

    static boolean isLoaded() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("flashback");
    }

    static Object recorder() {
        try {
            Class<?> flashback = Class.forName(FLASHBACK_CLASS);
            return flashback.getField("RECORDER").get(null);
        } catch (ReflectiveOperationException exception) {
            logCompatibilityIssue(exception);
            return null;
        }
    }

    static int recordedTick(Object recorder) {
        try {
            Field tick = recorder.getClass().getDeclaredField("writtenTicks");
            tick.setAccessible(true);
            return tick.getInt(recorder);
        } catch (ReflectiveOperationException exception) {
            logCompatibilityIssue(exception);
            return -1;
        }
    }

    static Entity spectatingPlayer() {
        try {
            Class<?> flashback = Class.forName(FLASHBACK_CLASS);
            Method getter = flashback.getMethod("getSpectatingPlayer");
            Object player = getter.invoke(null);
            return player instanceof Entity entity ? entity : null;
        } catch (ReflectiveOperationException exception) {
            logCompatibilityIssue(exception);
            return null;
        }
    }

    static Object replayServer() {
        try {
            return Class.forName(FLASHBACK_CLASS).getMethod("getReplayServer").invoke(null);
        } catch (ReflectiveOperationException exception) {
            logCompatibilityIssue(exception);
            return null;
        }
    }

    static double replayTick(Object replayServer) {
        if (replayServer == null) {
            return 0.0;
        }
        try {
            Method getter = replayServer.getClass().getMethod("getPartialReplayTick");
            return ((Number) getter.invoke(replayServer)).doubleValue();
        } catch (ReflectiveOperationException exception) {
            logCompatibilityIssue(exception);
            return 0.0;
        }
    }

    private static void logCompatibilityIssue(Exception exception) {
        if (!missingFieldLogged) {
            missingFieldLogged = true;
            FirstPersonReplayUiClient.LOGGER.error(
                    "Flashback 0.39.10 integration point was not found. Check the installed Flashback version.",
                    exception);
        }
    }
}

package dev.replayui;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class FirstPersonReplayUiClient implements ClientModInitializer {
    public static final String MOD_ID = "firstperson_replay_ui";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        UiTrackConfig.load();
        registerCommands();

        if (!FlashbackBridge.isLoaded()) {
            LOGGER.warn("Flashback was not found. Install Flashback 0.39.10 for Minecraft 1.21.11 to use replay capture.");
        } else {
            LOGGER.info("Flashback UI-track integration is enabled.");
        }
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("firstpersonui")
                        .then(ClientCommandManager.literal("toggle")
                                .executes(context -> {
                                    UiTrackConfig.current().renderGuiTrack =
                                            !UiTrackConfig.current().renderGuiTrack;
                                    UiTrackConfig.save();
                                    String state = UiTrackConfig.current().renderGuiTrack ? "yoqilgan" : "o‘chirilgan";
                                    context.getSource().sendFeedback(Component.literal(
                                            "Replay UI overlay " + state + ". Yangi eksportga ta’sir qiladi."));
                                    return 1;
                                }))
                        .then(ClientCommandManager.literal("status")
                                .executes(context -> {
                                    UiTrackConfig config = UiTrackConfig.current();
                                    context.getSource().sendFeedback(Component.literal(
                                            "UI capture: " + (config.captureGuiTrack ? "ON" : "OFF")
                                                    + " | export overlay: " + (config.renderGuiTrack ? "ON" : "OFF")
                                                    + " | first-person lock: " + (config.followRecordedPlayer ? "ON" : "OFF")));
                                    return 1;
                                }))));
    }
}

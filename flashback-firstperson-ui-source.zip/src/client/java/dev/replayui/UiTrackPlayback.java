package dev.replayui;

import com.google.gson.Gson;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class UiTrackPlayback {
    private static final Gson GSON = new Gson();
    private static final Identifier TEXTURE_ID =
            Identifier.fromNamespaceAndPath(FirstPersonReplayUiClient.MOD_ID, "recorded_ui");

    private static FileSystem replayFileSystem;
    private static UiTrackManifest manifest;
    private static UiTrackManifest.Frame currentFrame;
    private static DynamicTexture currentTexture;
    private static int imageWidth;
    private static int imageHeight;
    private static Object activeReplayServer;
    private static Entity originalCameraEntity;
    private static CameraType originalCameraType;
    private static boolean cameraStateSaved;
    private static boolean replayPlaybackStarted;
    private static boolean exportStarted;
    private static boolean missingPlayerLogged;

    private UiTrackPlayback() {}

    public static void beginExport() {
        Object server = FlashbackBridge.replayServer();
        if (server != null && (!replayPlaybackStarted || server != activeReplayServer)) {
            beginReplayPlayback(server);
        } else if (!cameraStateSaved) {
            saveCameraState();
        }
        if (replayFileSystem == null) {
            replayFileSystem = getReplayFileSystem();
            manifest = loadManifest(replayFileSystem);
        }
        releaseCurrentFrame();
        exportStarted = true;
        missingPlayerLogged = false;
    }

    public static void prepareFrame(double absoluteTick) {
        if (!exportStarted) {
            return;
        }

        if (UiTrackConfig.current().followRecordedPlayer) {
            enforceFirstPersonCamera();
        }
        if (!UiTrackConfig.current().renderGuiTrack) {
            releaseCurrentFrame();
            return;
        }

        UiTrackManifest.Frame frame = findFrame(absoluteTick);
        if (frame == null) {
            releaseCurrentFrame();
            return;
        }
        if (frame == currentFrame) {
            return;
        }

        uploadFrame(frame);
    }

    public static void appendOverlay(GuiRenderState renderState) {
        if (!exportStarted) {
            updateReplayPlayback();
        }
        if (!UiTrackConfig.current().renderGuiTrack || currentTexture == null) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        int guiWidth = minecraft.getWindow().getGuiScaledWidth();
        int guiHeight = minecraft.getWindow().getGuiScaledHeight();
        GuiGraphics graphics = new GuiGraphics(minecraft, renderState, guiWidth, guiHeight);
        graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_ID, 0, 0,
                0.0f, 0.0f, guiWidth, guiHeight, imageWidth, imageHeight);
    }

    public static void endExport() {
        if (!exportStarted) {
            return;
        }
        exportStarted = false;
        Object server = FlashbackBridge.replayServer();
        if (server == null) {
            endReplayPlayback();
        } else if (!replayPlaybackStarted || server != activeReplayServer) {
            beginReplayPlayback(server);
        }
    }

    private static void updateReplayPlayback() {
        Object server = FlashbackBridge.replayServer();
        if (server == null) {
            endReplayPlayback();
            return;
        }
        if (!replayPlaybackStarted || server != activeReplayServer) {
            endReplayPlayback();
            beginReplayPlayback(server);
        }

        if (UiTrackConfig.current().followRecordedPlayer) {
            enforceFirstPersonCamera();
        }
        if (UiTrackConfig.current().renderGuiTrack) {
            updateFrame(FlashbackBridge.replayTick(server));
        } else {
            releaseCurrentFrame();
        }
    }

    private static void beginReplayPlayback(Object server) {
        saveCameraState();
        activeReplayServer = server;
        replayPlaybackStarted = true;
        replayFileSystem = getReplayFileSystem();
        manifest = loadManifest(replayFileSystem);
        releaseCurrentFrame();
        missingPlayerLogged = false;
    }

    private static void endReplayPlayback() {
        if (!replayPlaybackStarted && !cameraStateSaved) {
            return;
        }
        restoreCameraState();
        releaseCurrentFrame();
        activeReplayServer = null;
        replayFileSystem = null;
        manifest = null;
        replayPlaybackStarted = false;
    }

    private static void updateFrame(double tick) {
        UiTrackManifest.Frame frame = findFrame(tick);
        if (frame == null) {
            releaseCurrentFrame();
        } else if (frame != currentFrame) {
            uploadFrame(frame);
        }
    }

    private static void saveCameraState() {
        if (cameraStateSaved) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        originalCameraEntity = minecraft.getCameraEntity();
        originalCameraType = minecraft.options.getCameraType();
        cameraStateSaved = true;
    }

    private static void restoreCameraState() {
        if (!cameraStateSaved) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (originalCameraType != null) {
            minecraft.options.setCameraType(originalCameraType);
        }
        if (originalCameraEntity != null) {
            minecraft.setCameraEntity(originalCameraEntity);
        }
        originalCameraEntity = null;
        originalCameraType = null;
        cameraStateSaved = false;
    }

    private static void releaseCurrentFrame() {
        if (currentTexture != null) {
            Minecraft.getInstance().getTextureManager().release(TEXTURE_ID);
        }
        currentTexture = null;
        currentFrame = null;
    }

    private static void enforceFirstPersonCamera() {
        Minecraft minecraft = Minecraft.getInstance();
        Entity recordedPlayer = FlashbackBridge.spectatingPlayer();
        if (recordedPlayer != null) {
            minecraft.setCameraEntity(recordedPlayer);
            minecraft.options.setCameraType(CameraType.FIRST_PERSON);
        } else if (!missingPlayerLogged) {
            missingPlayerLogged = true;
            FirstPersonReplayUiClient.LOGGER.warn(
                    "First-person lock needs a recorded player selected in Flashback's replay view.");
        }
    }

    private static UiTrackManifest.Frame findFrame(double tick) {
        if (manifest == null || manifest.frames == null || manifest.frames.isEmpty()) {
            return null;
        }
        int targetTick = (int) Math.floor(tick);
        List<UiTrackManifest.Frame> frames = manifest.frames;
        int low = 0;
        int high = frames.size();
        while (low < high) {
            int middle = (low + high) >>> 1;
            if (frames.get(middle).tick <= targetTick) {
                low = middle + 1;
            } else {
                high = middle;
            }
        }
        return low == 0 ? null : frames.get(low - 1);
    }

    private static void uploadFrame(UiTrackManifest.Frame frame) {
        if (replayFileSystem == null || frame.file == null) {
            return;
        }

        Path path = replayFileSystem.getPath("/ui-track").resolve(frame.file);
        if (!Files.isRegularFile(path)) {
            FirstPersonReplayUiClient.LOGGER.warn("Missing UI frame in replay: {}", frame.file);
            return;
        }

        try (InputStream input = Files.newInputStream(path)) {
            NativeImage image = NativeImage.read(input);
            DynamicTexture texture = new DynamicTexture(() -> "Flashback recorded UI", image);
            Minecraft.getInstance().getTextureManager().release(TEXTURE_ID);
            Minecraft.getInstance().getTextureManager().register(TEXTURE_ID, texture);
            currentTexture = texture;
            currentFrame = frame;
            imageWidth = image.getWidth();
            imageHeight = image.getHeight();
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not load recorded UI frame {}.", frame.file, exception);
        }
    }

    private static UiTrackManifest loadManifest(FileSystem fileSystem) {
        if (fileSystem == null) {
            return null;
        }
        Path path = fileSystem.getPath("/ui-track/manifest.json");
        if (!Files.isRegularFile(path)) {
            return null;
        }
        try {
            return GSON.fromJson(Files.readString(path), UiTrackManifest.class);
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not read replay UI-track manifest.", exception);
            return null;
        }
    }

    private static FileSystem getReplayFileSystem() {
        try {
            Object replayServer = FlashbackBridge.replayServer();
            if (replayServer == null) {
                return null;
            }
            Field field = replayServer.getClass().getDeclaredField("playbackFileSystem");
            field.setAccessible(true);
            Object value = field.get(replayServer);
            return value instanceof FileSystem fileSystem ? fileSystem : null;
        } catch (ReflectiveOperationException exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not locate the active Flashback replay archive.", exception);
            return null;
        }
    }
}

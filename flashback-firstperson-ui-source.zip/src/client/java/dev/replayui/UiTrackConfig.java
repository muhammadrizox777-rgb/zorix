package dev.replayui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class UiTrackConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir()
            .resolve("firstperson-replay-ui.json");
    private static UiTrackConfig current = new UiTrackConfig();

    public boolean captureGuiTrack = true;
    public boolean renderGuiTrack = true;
    public boolean followRecordedPlayer = true;
    public int captureFramesPerSecond = 20;

    private UiTrackConfig() {}

    public static UiTrackConfig current() {
        return current;
    }

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
        }

        try {
            UiTrackConfig loaded = GSON.fromJson(Files.readString(CONFIG_PATH), UiTrackConfig.class);
            if (loaded != null) {
                loaded.captureFramesPerSecond = Math.max(1, Math.min(20, loaded.captureFramesPerSecond));
                current = loaded;
            }
        } catch (Exception exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not read UI-track config at {}", CONFIG_PATH, exception);
        }
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(current));
        } catch (IOException exception) {
            FirstPersonReplayUiClient.LOGGER.error("Could not save UI-track config at {}", CONFIG_PATH, exception);
        }
    }
}

# First-Person Replay UI

A client-side Fabric add-on for Flashback on Minecraft 1.21.11. It records a transparent UI track alongside a Flashback replay, so inventory and container screens can be included in replay playback and export without recording the game with shaders enabled.

## Features

- Captures the rendered interface separately from the world, up to 20 frames per second.
- Stores UI frames in the replay archive as `ui-track/`.
- Adds the recorded UI frame to Flashback replay rendering and video export.
- Can request first-person replay export from the player Flashback is currently spectating.
- Provides `/firstpersonui toggle` and `/firstpersonui status`.

## Requirements

- Minecraft 1.21.11
- Fabric Loader 0.20.1 or newer
- Fabric API
- Flashback 0.39.10 or newer

Install the mod with Flashback in the `mods` folder. The add-on does not include Flashback; install Flashback separately.

## Configuration

The file `config/firstperson-replay-ui.json` controls UI capture, replay rendering, recorded-player following, and the capture frame rate. The default frame rate is 20 FPS, capped at 20.

## Build

Run `./gradlew build` from this directory. The distributable JAR is written to `build/libs/`.

## Limitations

This is an add-on, not a standalone replacement for Flashback. It relies on Flashback's replay recording and export APIs and is intended to be tested with the stated game and mod versions. UI capture is sampled; very brief screen changes may not appear if they occur between captured frames.

## License

MIT. Flashback is a separate project and is not included or redistributed here.
